"""Repeat standalone worker diagnostics without publishing benchmark evidence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]


def fixture_hashes():
    return {name: hashlib.sha256((ROOT / 'benchmarks' / name).read_bytes()).hexdigest()
        for name in ('import-probe.mjs', 'provider.mjs', 'profile.json')}


def configuration(kind):
    if kind == 'reuse':
        return {'sessions': 4, 'rounds': 50, 'input_bytes': 56, 'instructions_bytes': 0,
            'watch': True, 'idle_seconds': [1]}, ['default', 'zero', 'short']
    if kind == 'long':
        return {'sessions': 4, 'rounds': 100, 'input_bytes': 56, 'instructions_bytes': 0,
            'watch': True, 'idle_seconds': [2, 31]}, ['default', 'short']
    return {'sessions': 64, 'rounds': 1, 'input_bytes': 65536, 'instructions_bytes': 262144,
        'watch': True, 'idle_seconds': [2, 31]}, ['default', 'short']


def run(args):
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', args.label) or args.repeats < 1:
        raise ValueError('Use a simple label and a positive repeat count')
    if list(output.glob(args.label + '-*')):
        raise FileExistsError('Trial label already exists: ' + args.label)
    image = subprocess.check_output(['docker', 'image', 'inspect', args.image, '--format', '{{.Id}}'], text=True).strip()
    profile = json.loads((ROOT / 'benchmarks/profile.json').read_text())
    limits = profile['resources']
    base = ['docker', 'run', '--rm', '--init', '--network', 'none', '--cap-drop', 'ALL',
        '--security-opt', 'no-new-privileges', '--cpus', str(limits['cpus']),
        '--memory', str(limits['memory_bytes']), '--memory-swap', str(limits['memory_swap_bytes']),
        '--pids-limit', str(limits['pids_limit']), '--mount',
        f'type=bind,src={ROOT / "benchmarks"},dst=/app/benchmarks,readonly', '--entrypoint', 'node', image]
    options, names = configuration(args.kind)
    names = args.policies or names
    if len(set(names)) != len(names):
        raise ValueError('Each retention policy can occur only once')
    policies = {'default': {'contextRetentionMs': 600000, 'documentRetentionMs': 600000},
        'zero': {'contextRetentionMs': 0, 'documentRetentionMs': 0},
        'short': {'contextRetentionMs': 30000, 'documentRetentionMs': 30000},
        'documents': {'contextRetentionMs': 600000, 'documentRetentionMs': 30000}}
    fixtures = fixture_hashes()
    manifest = {'image': image, 'kind': args.kind, 'diagnostic_only': True,
        'probe_sha256': fixtures['import-probe.mjs'], 'fixture_sha256': fixtures,
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'runs': []}
    for repeat in range(1, args.repeats + 1):
        order = names[(repeat - 1) % len(names):] + names[:(repeat - 1) % len(names)]
        for policy in order:
            if fixture_hashes() != fixtures:
                raise RuntimeError('Diagnostic fixture changed during the trial series')
            label = f'{args.label}-{policy}-{repeat}'
            name = 'harness-worker-probe-' + uuid.uuid4().hex[:12]
            command = base[:2] + ['--name', name] + base[2:] + (['--expose-gc'] if args.kind == 'retained' else []) + [
                '/app/benchmarks/import-probe.mjs', '/app', 'retention', json.dumps({**options, **policies[policy]})]
            entry = {'label': label, 'command': command, 'started_at': time.time(),
                'host_load': Path('/proc/loadavg').read_text().strip(), 'host_cpu_count': os.cpu_count()}
            print('START', label, flush=True)
            with (output / f'{label}.json').open('x') as stdout, (output / f'{label}.stderr.log').open('x') as stderr:
                try:
                    status = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=180).returncode
                except subprocess.TimeoutExpired:
                    status = 124
                finally:
                    # --rm handles normal exit; interruption can leave the container running.
                    subprocess.run(['docker', 'rm', '--force', name],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            if fixture_hashes() != fixtures:
                raise RuntimeError('Diagnostic fixture changed during measurement')
            entry.update(exit_code=status, elapsed_seconds=time.time() - entry['started_at'],
                sha256=hashlib.sha256((output / f'{label}.json').read_bytes()).hexdigest())
            manifest['runs'].append(entry)
            (output / f'{args.label}-runs.json').write_text(json.dumps(manifest, indent=2) + '\n')
            print('END', label, status, flush=True)
            if status:
                raise RuntimeError('Diagnostic failed: ' + label)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True)
    parser.add_argument('--kind', choices=('reuse', 'retained', 'natural', 'long'), required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--policies', nargs='+', choices=('default', 'zero', 'short', 'documents'))
    parser.add_argument('--output', type=Path, default=ROOT / '.bench-results/investigation')
    run(parser.parse_args())
