// Diagnostic only. Compare public snapshot formatting and assert equal outputs.
// Usage: node --expose-gc benchmarks/snapshot-probe.mjs ROOT BASELINE_VIEW ITERATIONS REPEATS [CANDIDATE_VIEW]
// Defaults: ITERATIONS 500, REPEATS 7, CANDIDATE_VIEW ROOT/adapter/view.mjs.
// Keep the saved baseline outside the source tree. Both modules use current protocol limits.
// Repeats alternate the run order. Output is JSON; it is not end-to-end latency.
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve(process.argv[2] ?? process.cwd());
const baselinePath = process.argv[3];
if (!baselinePath) throw Error('Supply the saved baseline view module path');
const candidatePath = process.argv[6] ?? `${root}/adapter/view.mjs`;
const iterations = Number(process.argv[4] ?? 500), repeats = Number(process.argv[5] ?? 7);
const protocol = pathToFileURL(`${root}/adapter/protocol.mjs`).href;
async function loadView(path) {
  const source = (await readFile(path, 'utf8')).replace("'./protocol.mjs'", JSON.stringify(protocol));
  return import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
}
const before = await loadView(baselinePath), after = await loadView(candidatePath);

function checkPreviews() {
  // Buffer conversion replaces unpaired surrogates in public text.
  let seed = 104729;
  const units = ['a', '\0', '"', '\\', '\n', 'λ', '世', '😀', '\ud800', '\udc00'];
  for (let count = 0; count < 300; count++) {
    let value = '';
    for (let index = 0; index < count; index++) {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      value += units[seed % units.length];
    }
    for (const limit of [0, 1, 2, 3, 4, 5, 7, 19, 64, 256, 8192]) {
      assert.deepEqual(after.preview(value, limit), before.preview(value, limit));
    }
  }
}

function task(number) {
  return [
    { id: number * 4 + 1, kind: 'pi.user', model: [{ role: 'user', content: 'Run the controlled tool and report the result.' }] },
    { id: number * 4 + 2, kind: 'pi.assistant', model: [{ role: 'assistant', content: [{ type: 'toolCall', name: 'bash',
      arguments: { command: "python3 -c \"print('benchmark tool output ' * 2048)\"" } }] }] },
    { id: number * 4 + 3, kind: 'pi.tool-result', model: [{ role: 'toolResult', toolName: 'bash',
      content: [{ type: 'text', text: 'benchmark tool output '.repeat(2048) }] }] },
    { id: number * 4 + 4, kind: 'pi.assistant', model: [{ role: 'assistant',
      content: [{ type: 'text', text: 'Synthetic benchmark answer. '.repeat(76).slice(0, 2048) }] }] },
  ];
}

function measure(fixture, name, render, repeat) {
  globalThis.gc?.();
  const cpu = process.cpuUsage(), start = performance.now();
  for (let index = 0; index < iterations; index++) render(fixture.metadata, fixture.view);
  return { fixture: fixture.name, version: name, repeat, iterations,
    wall_ms: performance.now() - start, cpu_us: process.cpuUsage(cpu) };
}

const metadata = { session_id: 'probe', name: 'Probe', parent_session_id: null, workspace: '/tmp', provider: 'openai',
  model: 'gpt-5.6-luna', instructions: '', schema_version: 1, tools: ['read', 'write', 'edit', 'bash'] };
const cases = [
  { name: 'one_task', metadata, view: { entries: task(0), docs: {} } },
  { name: 'fifty_tasks', metadata, view: { entries: Array.from({ length: 50 }, (_, index) => task(index)).flat(), docs: {} } },
  { name: 'large_configuration', metadata: { ...metadata, instructions: 'x'.repeat(262144) }, view: { entries: task(0), docs: {} } },
];
const rows = [];
checkPreviews();
for (const fixture of cases) {
  assert.deepEqual(after.snapshot(fixture.metadata, fixture.view), before.snapshot(fixture.metadata, fixture.view));
  for (let index = 0; index < 50; index++) {
    before.snapshot(fixture.metadata, fixture.view); after.snapshot(fixture.metadata, fixture.view);
  }
  for (let repeat = 0; repeat < repeats; repeat++) {
    const versions = [['baseline', before.snapshot], ['candidate', after.snapshot]];
    if (repeat % 2) versions.reverse();
    for (const [name, render] of versions) rows.push(measure(fixture, name, render, repeat));
  }
}
console.log(JSON.stringify({ schema: 1, kind: 'snapshot_diagnostic', node: process.version,
  notes: [
    'Same public snapshot values asserted before timing.',
    'Representative synthetic entries, no Pi/storage/editor work.',
    'This is serialization work, not end-to-end task latency.',
  ], rows }, null, 2));
