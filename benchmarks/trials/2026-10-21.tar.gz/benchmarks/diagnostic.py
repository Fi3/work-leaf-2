"""Run bounded diagnostic load without changing or publishing capacity-v1 evidence."""
import argparse
import concurrent.futures
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import workload


def process_samples():
    result = []
    ticks = os.sysconf('SC_CLK_TCK')
    for directory in Path('/proc').iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            arguments = (directory / 'cmdline').read_bytes().split(b'\0')
            if not arguments[0]:
                continue
            command = Path(os.fsdecode(arguments[0])).name
            if any(b'/adapter/worker.mjs' in item for item in arguments):
                role = 'worker'
            elif command == 'harness':
                role = 'server' if b'serve' in arguments else 'client'
            elif command == 'nvim':
                role = 'editor'
            elif int(directory.name) == os.getpid():
                role = 'driver'
            elif command in ('docker-init', 'tini'):
                role = 'init'
            else:
                role = 'tool'
            memory = workload.counters(directory / 'smaps_rollup')
            stat = (directory / 'stat').read_text().rsplit(')', 1)[1].split()
            result.append({'pid': int(directory.name), 'role': role, 'command': command,
                'start_ticks': int(stat[19]), 'cpu_usec': (int(stat[11]) + int(stat[12])) * 1_000_000 // ticks,
                'waited_children_cpu_usec': (int(stat[13]) + int(stat[14])) * 1_000_000 // ticks,
                **{name: memory.get(field, 0) * 1024 for name, field in (
                    ('rss_bytes', 'Rss:'), ('pss_bytes', 'Pss:'), ('private_dirty_bytes', 'Private_Dirty:'),
                    ('shared_clean_bytes', 'Shared_Clean:'), ('anonymous_bytes', 'Anonymous:'))}})
        except (OSError, ValueError):
            continue
    return result


class Monitor(workload.Monitor):
    def __init__(self, profile):
        super().__init__(profile)
        self.error = None

    def sample(self):
        try:
            super().sample()
        except Exception as error:
            self.error = self.error or f'{type(error).__name__}: {error}'
            raise

    def record_sample(self):
        cpu = workload.counters(workload.CGROUP / 'cpu.stat')
        events = workload.counters(workload.CGROUP / 'memory.events')
        value = {'elapsed_seconds': round(time.monotonic() - self.started, 3), 'monotonic_seconds': time.monotonic(), 'phase': self.phase,
            'cpu_usec': cpu['usage_usec'], 'cpu_throttled_usec': cpu.get('throttled_usec', 0),
            'memory_bytes': int((workload.CGROUP / 'memory.current').read_text()),
            'memory_peak_bytes': int((workload.CGROUP / 'memory.peak').read_text()),
            'memory_stat': workload.counters(workload.CGROUP / 'memory.stat'),
            'memory_events': events, 'processes': process_samples()}
        self.samples.append(value)
        workload.emit('diagnostic_sample', **value)
        if events.get('oom_kill', 0) > self.initial_events.get('oom_kill', 0):
            self.exhausted.set()


def bounded_load(sessions, tasks, phase):
    def run(index):
        with contextlib.closing(workload.Rpc(workload.WORK / 'control.sock', timeout=25)) as client:
            return [workload.task(client, f'load{index}', f'{phase}-{index}-{task}',
                'Run the benchmark tool and give the synthetic answer.') for task in range(tasks)]
    started = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=sessions) as pool:
        summary = workload.latency_summary([value for group in pool.map(run, range(sessions)) for value in group])
    return {'phase': phase, 'elapsed_seconds': time.monotonic() - started, **summary}


def worker_command(sequence, operation):
    workload.write_json(workload.WORK / 'diagnostic-control.json', {'sequence': sequence, 'operation': operation})
    deadline = time.monotonic() + 15
    path = workload.WORK / 'diagnostic-ack.json'
    while time.monotonic() < deadline:
        if path.exists():
            acknowledgment = json.loads(path.read_text())
            if acknowledgment.get('sequence') == sequence:
                if acknowledgment.get('error'):
                    raise RuntimeError(acknowledgment['error'])
                return
        time.sleep(.05)
    raise TimeoutError(f'Worker diagnostic command did not finish: {operation}')


def prepare(profile, args):
    workload.WORK.mkdir(exist_ok=True)
    for name in ('state', 'project'):
        (workload.WORK / name).mkdir(mode=0o700, exist_ok=True)
    workload.write_json(workload.WORK / 'config.json', {'provider': profile['provider'], 'model': profile['model'],
        'node_path': '/usr/local/bin/node', 'worker_path': '/app/adapter/worker.mjs',
        'state_dir': str(workload.WORK / 'state'), 'socket_path': str(workload.WORK / 'control.sock')})
    environment = dict(os.environ, OPENAI_API_KEY='sk-benchmark-synthetic',
        HARNESS_DIAGNOSTIC_DIRECTORY=str(workload.WORK),
        HARNESS_DIAGNOSTIC_CPU_PROFILE='1' if args.cpu_profile else '0',
        HARNESS_DIAGNOSTIC_TOOL_TIMING='1' if args.tool_timing else '0',
        NODE_OPTIONS='--import=/app/benchmarks/provider.mjs --import=/app/benchmarks/diagnostic-worker.mjs '
            f"--max-old-space-size={profile['node_max_old_space_mib']}")
    return environment


def run(args, profile, monitor, children):
    server = subprocess.Popen(['/app/target/release/harness', 'serve', '--config', str(workload.WORK / 'config.json')],
        env=prepare(profile, args), stdout=sys.stderr, stderr=sys.stderr)
    children.append(server)
    workload.wait_server(server)
    with contextlib.closing(workload.Rpc(workload.WORK / 'control.sock')) as client:
        for index in range(args.sessions):
            workload.create(client, f'load{index}')
    workload.write_json(workload.WORK / 'editor-control.json', {'session': 'load0', 'visible': True})
    editor = subprocess.Popen(['nvim', '--headless', '-u', 'NONE', '-c', 'luafile /app/benchmarks/editor.lua'],
        stdout=sys.stderr, stderr=sys.stderr)
    children.append(editor)
    workload.wait_editor(editor)
    monitor.stage('idle')
    time.sleep(profile['idle_seconds'])
    stages = []
    for index in range(args.rounds):
        monitor.stage(f'long-{index + 1}')
        stages.append(bounded_load(args.sessions, args.tasks_per_session, monitor.phase))
        workload.emit('diagnostic_stage', **stages[-1])
        if monitor.exhausted.is_set():
            raise RuntimeError('Bounded diagnostic workload exceeded container memory')
    if args.mode == 'retention':
        # Keep the existing selected watch. Other sessions have no editor watch.
        workload.write_json(workload.WORK / 'editor-control.json', {'session': 'load0', 'visible': False})
        monitor.stage('idle-after-activity')
        time.sleep(args.retention_seconds)
        monitor.sample()
    if args.force_gc:
        monitor.stage('forced-gc-diagnostic')
        worker_command(1, 'collect_garbage')
        monitor.sample()
    workload.write_json(workload.WORK / 'editor-control.json', {'session': 'load0', 'visible': True, 'history': True})
    time.sleep(1)
    monitor.stage('resume-after-idle' if args.mode == 'retention' else 'resume')
    stages.append(bounded_load(args.sessions, 1, monitor.phase))
    workload.emit('diagnostic_stage', **stages[-1])
    monitor.stage('diagnostic-finish')
    worker_command(2, 'finish')
    if editor.poll() is not None:
        raise RuntimeError('Editor exited during diagnostic load')
    return stages, json.loads((workload.WORK / 'editor-metrics.json').read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('long', 'retention'), default='long')
    parser.add_argument('--sessions', type=int, choices=range(1, 5), default=4)
    parser.add_argument('--tasks-per-session', type=int, default=100)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--retention-seconds', type=int, default=660)
    parser.add_argument('--cpu-profile', action='store_true')
    parser.add_argument('--tool-timing', action='store_true', help='Observe the public Node execution environment boundary')
    parser.add_argument('--force-gc', action='store_true', help='Add a distinct forced-GC observation after the natural idle period')
    args = parser.parse_args()
    if min(args.tasks_per_session, args.rounds) < 1 or args.retention_seconds <= 600:
        parser.error('Task and round counts must be positive; retention observation must exceed 600 seconds')
    profile = json.loads((workload.ROOT / 'benchmarks/profile.json').read_text())
    workload.verify_limits(profile)
    monitor = Monitor(profile)
    children, stages, editor, failure = [], [], None, None
    monitor.thread.start()
    try:
        stages, editor = run(args, profile, monitor, children)
    except Exception as error:
        failure = f'{type(error).__name__}: {error}'
    finally:
        monitor.done.set()
        monitor.thread.join(timeout=2)
        try:
            monitor.sample()
        except Exception as error:
            failure = failure or f'Final resource sample failed: {type(error).__name__}: {error}'
        finally:
            for child in reversed(children):
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
    if monitor.error:
        failure = failure or f'Resource sampling failed: {monitor.error}'
    path = workload.WORK / 'worker-metrics.jsonl'
    worker = [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
    if any(record.get('type') == 'diagnostic_error' for record in worker):
        failure = failure or 'The worker diagnostic observer reported an error'
    workload.emit('diagnostic_result', diagnostic_only=True, accepted_capacity_evidence=False,
        completed=failure is None and not monitor.exhausted.is_set(), error=failure,
        settings=vars(args), profile=profile, measurements=monitor.samples, stages=stages, editor=editor, worker=worker,
        accounting_notes=[
            'Cgroup totals include the diagnostic driver, model fixture, tools, editor, clients, file cache, and kernel memory.',
            'Process CPU uses /proc clock ticks; tools that exit between samples can be absent.',
            'Waited child CPU is separate and must not be added to live child CPU without lifetime accounting.',
            'RSS, PSS, V8 heap, and cgroup memory use different accounting methods.',
            'The worker observers and stream wrapper add work; compare these runs only with equal diagnostics.',
            'Provider service time includes fixed stream delays, consumer scheduling, and backpressure.',
            'Optional tool timings cover NodeExecutionEnv.exec, including process startup and output delivery.',
            'Task duration includes provider, tools, storage, adapter, server, and driver time. It is not pure harness overhead.',
            'Forced garbage collection is separate from natural retention and cannot establish normal RSS savings.'])
    return 0 if failure is None and not monitor.exhausted.is_set() else 1


if __name__ == '__main__':
    sys.exit(main())
