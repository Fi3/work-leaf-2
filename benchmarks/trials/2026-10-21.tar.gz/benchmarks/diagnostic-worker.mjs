// Diagnostic observers add work. Do not load them in capacity-v1 measurements.
import { closeSync, existsSync, openSync, readFileSync, renameSync, writeFileSync, writeSync } from 'node:fs';
import { PerformanceObserver, performance } from 'node:perf_hooks';
import { getHeapSpaceStatistics, getHeapStatistics } from 'node:v8';

const directory = process.env.HARNESS_DIAGNOSTIC_DIRECTORY;
if (!directory) throw Error('HARNESS_DIAGNOSTIC_DIRECTORY is required');
const output = openSync(`${directory}/worker-metrics.jsonl`, 'a', 0o600);
const started = performance.now();
const gc = { count: 0, duration_ms: 0 };
let requestSequence = 0, commandSequence = 0, controlling = false, inspector;
let profiling = false, observationError;

function emit(type, value = {}) {
  if (observationError) return;
  try {
    writeSync(output, `${JSON.stringify({ type, elapsed_seconds: (performance.now() - started) / 1000,
      monotonic_seconds: Number(process.hrtime.bigint()) / 1e9, ...value })}\n`);
  } catch (error) {
    observationError = `Worker metrics write failed (${error.code ?? error.name})`;
    process.exitCode = 1;
    // A failed observer invalidates this diagnostic without replacing a tool result.
    try { process.stderr.write(`${observationError}\n`); } catch {}
  }
}

function sample(reason) {
  emit('worker_sample', { reason, memory: process.memoryUsage(), heap: getHeapStatistics(),
    spaces: getHeapSpaceStatistics(), cpu: process.cpuUsage(), gc: { ...gc } });
}

const observer = new PerformanceObserver(list => {
  for (const event of list.getEntries()) { gc.count++; gc.duration_ms += event.duration; }
});
observer.observe({ entryTypes: ['gc'] });

async function inspectorCommand(method) {
  if (!inspector) {
    const { Session } = await import('node:inspector/promises');
    inspector = new Session(); inspector.connect();
  }
  return inspector.post(method);
}

if (process.env.HARNESS_DIAGNOSTIC_CPU_PROFILE === '1') {
  await inspectorCommand('Profiler.enable');
  await inspectorCommand('Profiler.start');
  profiling = true;
}

if (process.env.HARNESS_DIAGNOSTIC_TOOL_TIMING === '1') {
  const { NodeExecutionEnv } = await import('@earendil-works/pi-durable/env/node');
  const execute = NodeExecutionEnv.prototype.exec;
  let sequence = 0;
  NodeExecutionEnv.prototype.exec = async function (...args) {
    const id = ++sequence, start = performance.now();
    const startedMonotonic = Number(process.hrtime.bigint()) / 1e9;
    let result;
    try { result = await execute.apply(this, args); return result; }
    finally {
      // Log only the public outcome. Commands, output, and error messages stay private.
      emit('tool_execution', { id, started_monotonic_seconds: startedMonotonic,
        duration_ms: performance.now() - start, status: result === undefined ? 'rejected' : result.ok ? 'complete' : 'error',
        exit_code: result?.ok ? result.value.exitCode : null, error_code: result?.ok === false ? result.error.code : null });
    }
  };
}

async function control() {
  const path = `${directory}/diagnostic-control.json`;
  if (controlling || !existsSync(path)) return;
  const command = JSON.parse(readFileSync(path));
  if (command.sequence <= commandSequence) return;
  controlling = true;
  try {
    if (command.operation === 'collect_garbage') {
      sample('before_forced_gc');
      await inspectorCommand('HeapProfiler.collectGarbage');
      sample('after_forced_gc');
    } else if (command.operation === 'finish' && profiling) {
      const { profile } = await inspectorCommand('Profiler.stop');
      writeFileSync(`${directory}/worker.cpuprofile`, JSON.stringify(profile));
      profiling = false;
    }
    commandSequence = command.sequence;
    writeFileSync(`${directory}/diagnostic-ack.tmp`, JSON.stringify({ sequence: commandSequence, error: observationError ?? null }));
    renameSync(`${directory}/diagnostic-ack.tmp`, `${directory}/diagnostic-ack.json`);
  } finally { controlling = false; }
}

const provider = globalThis.fetch;
globalThis.fetch = async (input, options = {}) => {
  const id = ++requestSequence, start = performance.now();
  const bodyBytes = Buffer.byteLength(options.body ?? '');
  const response = await provider(input, options);
  const preparation = performance.now() - start;
  const reader = response.body.getReader();
  let first, last, bytes = 0, chunks = 0, finished = false;
  function finish(status) {
    if (finished) return;
    finished = true;
    emit('provider_request', { id, status, request_bytes: bodyBytes, response_bytes: bytes, chunks,
      preparation_ms: preparation, service_ms: performance.now() - start, first_chunk_ms: first === undefined ? null : first - start,
      last_chunk_ms: last === undefined ? null : last - start });
  }
  const stream = new ReadableStream({
    async pull(controller) {
      try {
        const item = await reader.read();
        if (item.done) { finish('complete'); controller.close(); reader.releaseLock(); return; }
        last = performance.now(); first ??= last;
        bytes += item.value.byteLength; chunks++;
        controller.enqueue(item.value);
      } catch (error) { finish('error'); controller.error(error); reader.releaseLock(); }
    },
    async cancel(reason) {
      finish('cancelled');
      try { await reader.cancel(reason); } finally { reader.releaseLock(); }
    },
  });
  return new Response(stream, { status: response.status, statusText: response.statusText, headers: response.headers });
};

sample('preload');
const timer = setInterval(() => {
  sample('interval');
  void control().catch(error => emit('diagnostic_error', { message: error.message }));
}, 1000);
timer.unref();
process.once('exit', () => {
  sample('exit'); clearInterval(timer); observer.disconnect(); inspector?.disconnect(); closeSync(output);
});
