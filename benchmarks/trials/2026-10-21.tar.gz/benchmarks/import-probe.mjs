// Diagnostic only. This does not change capacity-v1 or publish accepted evidence.
// Usage: node --expose-gc benchmarks/import-probe.mjs ROOT MODE OPTIONS_JSON
// MODE imports measures cumulative module loads, application startup, and SDK loads.
// MODE retention runs real Pi and tools with benchmarks/provider.mjs model replies.
// Options: sessions (16), rounds (1), input_bytes (65536), instructions_bytes (0),
// watch (false), idle_seconds ([5,60,550]); delays are sequential, in seconds.
// contextRetentionMs and documentRetentionMs override only this diagnostic Harness.
// Output includes RSS/PSS, V8 heap, CPU time, and loaded source-byte counts.
// --expose-gc adds forced-GC samples; omit it to observe ordinary allocation.
// Run in an isolated container with the fixed limits. Never use real state paths.
import { mkdtemp, rm, mkdir } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { registerHooks } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import { getHeapStatistics, getHeapSpaceStatistics } from 'node:v8';

const root = resolve(process.argv[2] ?? process.cwd());
const mode = process.argv[3] ?? 'imports';
const options = JSON.parse(process.argv[4] ?? '{}');
const loaded = new Map(), rows = [];
const hook = registerHooks({
  load(url, context, nextLoad) {
    const result = nextLoad(url, context);
    if (url.startsWith('file:')) loaded.set(url, typeof result.source === 'string'
      ? Buffer.byteLength(result.source) : result.source?.byteLength ?? null);
    return result;
  },
});

function sample() {
  const rollup = {};
  for (const line of readFileSync('/proc/self/smaps_rollup', 'utf8').split('\n')) {
    const match = line.match(/^([A-Za-z_]+):\s+(\d+)\s+kB$/);
    if (match) rollup[match[1]] = Number(match[2]) * 1024;
  }
  return { memory: process.memoryUsage(), smaps_bytes: rollup,
    heap: getHeapStatistics(), heap_spaces: getHeapSpaceStatistics() };
}

function loadGroups() {
  const groups = {};
  for (const [url, bytes] of loaded) {
    const path = fileURLToPath(url);
    let group = 'application';
    if (path.includes('/node_modules/')) {
      const name = path.slice(path.lastIndexOf('/node_modules/') + 14).split('/');
      group = name[0].startsWith('@') ? name.slice(0, 2).join('/') : name[0];
    }
    groups[group] ??= { files: 0, source_bytes: 0 };
    groups[group].files++;
    groups[group].source_bytes += bytes ?? 0;
  }
  return groups;
}

async function checkpoint(name, operation = async () => {}, extra = {}) {
  const cpu = process.cpuUsage(), start = performance.now();
  await operation();
  await delay(20);
  const elapsed = performance.now() - start, cost = process.cpuUsage(cpu), before = sample();
  if (globalThis.gc) {
    globalThis.gc(); await delay(20); globalThis.gc();
  }
  rows.push({ name, ...extra, wall_ms: elapsed, cpu_us: cost, before_gc: before,
    after_gc: globalThis.gc ? sample() : null, loaded: loadGroups() });
  process.stderr.write(`Checkpoint ${name}\n`);
}

async function openDiagnosticApplication(openApplication, config) {
  const { Harness } = await import('@earendil-works/pi-durable');
  const open = Harness.open;
  const settings = {};
  for (const key of ['contextRetentionMs', 'documentRetentionMs']) {
    if (options[key] !== undefined) settings[key] = options[key];
  }
  if (Object.keys(settings).length) {
    Harness.open = (storage, config, ...args) => open(storage,
      { ...config, settings: { ...config.settings, ...settings } }, ...args);
  }
  try { return await openApplication(config); }
  finally { Harness.open = open; }
}

async function createSessions(call, directory, count) {
  for (let index = 0; index < count; index++) {
    const session_id = `probe_${index}`;
    await call('session.create', { session_id, workspace: join(directory, 'project') });
    if (options.instructions_bytes) {
      await call('session.configure', { session_id,
        instructions: `${session_id} ${'x'.repeat(options.instructions_bytes)}`.slice(0, options.instructions_bytes) });
    }
  }
}

async function runTasks(call, count, round) {
  for (let offset = 0; offset < count; offset += 4) {
    await Promise.all(Array.from({ length: Math.min(4, count - offset) }, async (_, index) => {
      const session_id = `probe_${offset + index}`, request_id = `task_${round}`;
      const bytes = options.input_bytes ?? 65536;
      await call('input.submit', { session_id, request_id,
        text: `${session_id} ${request_id} ${'t'.repeat(bytes)}`.slice(0, bytes), context: [] });
      const result = await call('submission.wait', { session_id, request_id, timeout_ms: 30000 });
      if (result.status !== 'done') throw Error('Diagnostic task did not complete');
    }));
  }
}

async function retention(app, directory) {
  await import(pathToFileURL(join(root, 'benchmarks/provider.mjs')));
  let callId = 0;
  const call = (method, params) => app.dispatch(method, params, String(++callId), () => {});
  const sessions = options.sessions ?? 16, rounds = options.rounds ?? 1;
  await checkpoint('sessions_created', () => createSessions(call, directory, sessions));
  let watchId;
  if (options.watch) {
    const watch = await call('session.watch', { session_id: 'probe_0' });
    watchId = watch.result.watch_id; watch.start();
  }
  for (let round = 0; round < rounds; round++) {
    await checkpoint(`tasks_${round}`, () => runTasks(call, sessions, round), { sessions, round });
  }
  for (const seconds of options.idle_seconds ?? [5, 60, 550]) {
    await checkpoint(`idle_${seconds}s`, () => delay(seconds * 1000));
  }
  if (watchId) await call('session.unwatch', { watch_id: watchId });
  await checkpoint('watch_released');
  await checkpoint('resume', () => runTasks(call, Math.min(sessions, 4), rounds));
  await checkpoint('reload', async () => {
    await call('session.get', { session_id: 'probe_0' });
    const result = await call('submission.get', { session_id: 'probe_0', request_id: `task_${rounds - 1}` });
    if (result.status !== 'done') throw Error('Stored outcome lost');
  });
}

let app, directory;
try {
  globalThis.fetch = async () => { throw Error('Diagnostic network access is disabled'); };
  await checkpoint('node');
  if (mode === 'imports') {
    await checkpoint('durable_import', () => import('@earendil-works/pi-durable'));
    await checkpoint('provider_catalog_import', () => import('@earendil-works/pi-ai/providers/all'));
  }
  let adapter;
  await checkpoint('adapter_import', async () => { adapter = await import(pathToFileURL(join(root, 'adapter/pi.mjs'))); });
  directory = await mkdtemp(join(tmpdir(), 'harness-resource-probe-'));
  await mkdir(join(directory, 'project'));
  const config = { state_dir: directory, provider: mode === 'retention' ? 'openai' : 'faux',
    model: mode === 'retention' ? 'gpt-5.6-luna' : 'test', instructions: '' };
  if (mode === 'retention') process.env.OPENAI_API_KEY = 'sk-benchmark-synthetic';
  await checkpoint('application_open', async () => { app = await openDiagnosticApplication(adapter.openApplication, config); });
  if (mode === 'imports') {
    await checkpoint('openai_api_import', () => import('@earendil-works/pi-ai/api/openai-responses'));
    await checkpoint('anthropic_api_import', () => import('@earendil-works/pi-ai/api/anthropic-messages'));
  } else if (mode === 'retention') await retention(app, directory);
  else throw Error('Unknown diagnostic mode');
  await checkpoint('application_closed', async () => { await app.close(); app = undefined; });
  console.log(JSON.stringify({ schema: 1, kind: 'worker_memory_diagnostic', node: process.version, mode, options,
    notes: [
      'Standalone Node worker diagnostic; excludes Rust, editor, driver and container file cache.',
      'Module load hooks and explicit GC change timing and allocator state; not the standard benchmark.',
      'Heap and process RSS/PSS are separate measures.',
      'SDK load stages accumulate in the same process.',
    ], rows }, null, 2));
} finally {
  hook.deregister();
  await app?.close();
  if (directory) await rm(directory, { recursive: true, force: true });
}
