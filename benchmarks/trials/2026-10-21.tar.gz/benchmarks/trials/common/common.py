"""Separate diagnostic: retained-session tool tasks with local streamed model data."""
import argparse
import http.server
import json
import math
import os
import pathlib
import queue
import socket
import subprocess
import sys
import threading
import time
WORK = pathlib.Path('/work')
ANSWER = ('Synthetic benchmark answer. ' * math.ceil(2048 / 28))[:2048]
COMMAND = 'python3 -c "print(\'benchmark tool output \' * 256)"'
TOOL_OUTPUT = 'benchmark tool output ' * 256 + '\n'
PROMPT = 'Run the benchmark tool and give the synthetic answer.'
CGROUP = pathlib.Path('/sys/fs/cgroup')
records = []
samples = []
monitor_errors = []
phase = 'startup'
started = time.monotonic()
stop = threading.Event()

def counters(path):
    return {a[0].rstrip(':'): int(a[1]) for line in path.read_text().splitlines() if len((a := line.split())) >= 2 and a[1].isdigit()}

def sample():
    procs = []
    for d in pathlib.Path('/proc').iterdir():
        if not d.name.isdigit():
            continue
        try:
            cmd = (d / 'cmdline').read_bytes().split(b'\x00')
            if not cmd or not cmd[0]:
                continue
            memory = counters(d / 'smaps_rollup')
            stat = (d / 'stat').read_text().split(') ', 1)[1].split()
            name = cmd[0].decode(errors='replace')
            role = 'driver' if int(d.name) == os.getpid() else 'worker' if any((b'worker.mjs' in c for c in cmd)) else 'editor' if 'nvim' in name else 'harness' if any((s in name for s in ['jcode', 'peri', 'harness'])) else 'tool'
            procs.append(dict(pid=int(d.name), role=role, rss_bytes=memory.get('Rss', 0) * 1024, pss_bytes=memory.get('Pss', 0) * 1024, cpu_seconds=sum((int(stat[i]) for i in [11, 12])) / os.sysconf('SC_CLK_TCK'), waited_child_cpu_seconds=sum((int(stat[i]) for i in [13, 14])) / os.sysconf('SC_CLK_TCK')))
        except (OSError, ValueError):
            pass
    samples.append(dict(t=time.monotonic() - started, phase=phase, memory_bytes=int((CGROUP / 'memory.current').read_text()), memory_peak_bytes=int((CGROUP / 'memory.peak').read_text()), cpu=counters(CGROUP / 'cpu.stat'), memory_stat=counters(CGROUP / 'memory.stat'), processes=procs))

def monitor():
    while not stop.is_set():
        try:
            sample()
        except Exception as error:
            monitor_errors.append(f'{type(error).__name__}: {error}')
            return
        stop.wait(0.1)

def text_content(value):
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ''.join((text_content(x) for x in value))
    if isinstance(value, dict):
        return text_content(value.get('text', value.get('content', value.get('output', ''))))
    return ''

def decide(body):
    messages = body.get('messages', [])
    last = messages[-1] if messages else {}
    result = None
    if isinstance(last.get('content'), list):
        items = [x for x in last['content'] if x.get('type') == 'tool_result']
        if items:
            result = items[-1].get('content')
    if result is not None:
        text = text_content(result)
        return (False, text)
    names = [x.get('name', '') for x in body.get('tools', [])]
    tool = next((name for name in names if name.lower() == 'bash'), None)
    return (tool, None)

def auxiliary_kind(body):
    system = text_content(body.get('system', ''))
    if '<prediction_directive>' in system:
        return 'peri_input_prediction'
    if system.startswith('You are a memory extraction assistant.'):
        return 'jcode_memory_extraction'
    raise RuntimeError('Unknown auxiliary model request')


def anthropic_events(body, ident, tool, answer):

    def event(kind, **fields):
        return (kind, dict(type=kind, **fields))
    events = [event('message_start', message=dict(id=ident, type='message', role='assistant', content=[], model=body['model'], stop_reason=None, stop_sequence=None, usage={'input_tokens': math.ceil(len(json.dumps(body['messages']).encode()) / 4), 'output_tokens': 0}))]
    block = dict(type='tool_use', id='call_' + ident, name=tool, input={}) if tool else dict(type='text', text='')
    events += [event('content_block_start', index=0, content_block=block)]
    if tool:
        events += [event('content_block_delta', index=0, delta=dict(type='input_json_delta', partial_json=json.dumps({'command': COMMAND})))]
    else:
        events.extend((event('content_block_delta', index=0, delta=dict(type='text_delta', text=answer[i:i + 64])) for i in range(0, len(answer), 64)))
    events += [event('content_block_stop', index=0), event('message_delta', delta={'stop_reason': 'tool_use' if tool else 'end_turn', 'stop_sequence': None}, usage={'output_tokens': 32 if tool else math.ceil(len(answer) / 4)}), event('message_stop')]
    return events

class Mock(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'

    def log_message(self, *args):
        pass

    def do_POST(self):
        start = time.monotonic()
        try:
            body = json.loads(self.rfile.read(int(self.headers['content-length'])))
            tool, result = decide(body)
            if tool and (not (WORK / 'tool-names.json').exists()):
                (WORK / 'tool-names.json').write_text(json.dumps([x['name'] for x in body.get('tools', [])]))
            auxiliary = auxiliary_kind(body) if tool is None and result is None else None
            ident = 'common_' + str(len(records) + 1)
            record = dict(t=start - started, path=self.path, auxiliary=auxiliary, tool=tool or None, request_bytes=int(self.headers['content-length']), result_bytes=None if result is None else len(result.encode()), result_contains_output=None if result is None else TOOL_OUTPUT.rstrip('\n') in result, result_prefix=None if result is None else result[:200], result_suffix=None if result is None else result[-200:])
            if auxiliary and sum(bool(r.get('auxiliary')) for r in records) < 6:
                record['system_prompt'] = text_content(body.get('system', ''))[:6000]
                record['last_prompt'] = text_content(body.get('messages', [{}])[-1].get('content', ''))[-6000:]
            records.append(record)
            if not self.path.endswith('/messages'):
                raise RuntimeError('Unexpected endpoint ' + self.path)
            events = anthropic_events(body, ident, tool, '' if auxiliary else ANSWER)
            record['event_count'] = len(events)
            record['scheduled_delay_seconds'] = len(events) * 0.003
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Connection', 'close')
            self.end_headers()
            for kind, data in events:
                data = data if isinstance(data, str) else json.dumps(data, separators=(',', ':'))
                self.wfile.write(((f'event: {kind}\n' if kind else '') + f'data: {data}\n\n').encode())
                self.wfile.flush()
                time.sleep(0.003)
            record['duration_seconds'] = time.monotonic() - start
        except Exception as error:
            records.append(dict(error=str(error), path=self.path))
            self.send_error(500, str(error))

class Acp:

    def __init__(self, process):
        self.process = process
        self.responses = queue.Queue()
        self.seq = 0
        threading.Thread(target=self.read, daemon=True).start()

    def read(self):
        for line in self.process.stdout:
            try:
                value = json.loads(line)
                if value.get('method') == 'session/request_permission':
                    opts = value['params']['options']
                    chosen = next((o for o in opts if o.get('kind') == 'allow_once'), opts[0])
                    self.send(dict(jsonrpc='2.0', id=value['id'], result={'outcome': {'outcome': 'selected', 'optionId': chosen['optionId']}}))
                elif 'id' in value:
                    self.responses.put(value)
            except Exception as error:
                self.responses.put({'error': str(error)})
        self.responses.put({'error': 'ACP process exited'})

    def send(self, value):
        self.process.stdin.write(json.dumps(value) + '\n')
        self.process.stdin.flush()

    def request(self, method, params):
        self.seq += 1
        self.send(dict(jsonrpc='2.0', id=self.seq, method=method, params=params))
        value = self.responses.get(timeout=30)
        if 'error' in value:
            raise RuntimeError(str(value))
        return value['result']

def debug(command, session=None):
    with socket.socket(socket.AF_UNIX) as connection:
        connection.settimeout(30)
        connection.connect('/work/run/bench-debug.sock')
        req = dict(type='debug_command', id=1, command=command)
        if session:
            req['session_id'] = session
        connection.sendall((json.dumps(req) + '\n').encode())
        stream = connection.makefile()
        for line in stream:
            value = json.loads(line)
            if value.get('type') == 'debug_response' or 'ok' in value:
                if not value.get('ok'):
                    raise RuntimeError(str(value))
                return value.get('output', '')
    raise RuntimeError('Debug connection ended')

def spawn(command, environment, children, stream=False):
    with (WORK / 'harness.stderr').open('a') as errors:
        process = subprocess.Popen(command, env=environment, stdin=subprocess.PIPE if stream else subprocess.DEVNULL, stdout=subprocess.PIPE if stream else errors, stderr=errors, text=stream, bufsize=1 if stream else -1)
    children.append(process)
    return process

def launch(which, port, children):
    environment = dict(os.environ)
    project = WORK / 'project'
    project.mkdir(parents=True, exist_ok=True)
    if which == 'peri':
        settings = {'config': {'active_alias': 'sonnet', 'providers': [{'id': 'llm-mock', 'type': 'anthropic', 'apiKey': 'mock-key', 'baseUrl': f'http://127.0.0.1:{port}', 'models': {x: 'claude-sonnet-4-6' for x in ['fable', 'opus', 'sonnet', 'haiku']}}], 'profiles': {x: {'provider': 'llm-mock', 'model': 'claude-sonnet-4-6', 'effort': 'low'} for x in ['fable', 'opus', 'sonnet', 'haiku']}}}
        (WORK / 'peri-settings.json').write_text(json.dumps(settings))
        environment.update(ANTHROPIC_API_KEY='mock-key', ANTHROPIC_BASE_URL=f'http://127.0.0.1:{port}')
        p = spawn(['/comparison/peri/bin/peri-linux-x86_64', '--config-file', '/work/peri-settings.json', '--settings', json.dumps(settings), '--db-path', '/work/peri.db', 'acp', '--cwd', str(project)], environment, children, stream=True)
        client = Acp(p)
        client.request('initialize', {'protocolVersion': 1, 'clientCapabilities': {}, 'clientInfo': {'name': 'resource-diagnostic', 'version': '1'}})
        session = client.request('session/new', {'cwd': str(project), 'mcpServers': []})['sessionId']

        def submit(index):
            answer = client.request('session/prompt', {'sessionId': session, 'prompt': [{'type': 'text', 'text': PROMPT}]})
            if answer.get('stopReason') != 'end_turn':
                raise RuntimeError(str(answer))
        return submit
    if which == 'jcode':
        (WORK / 'run').mkdir(exist_ok=True)
        environment.update(JCODE_HOME='/work/jcode', JCODE_RUNTIME_DIR='/work/run', JCODE_TEMP_SERVER='1', JCODE_SERVER_OWNER_PID=str(os.getpid()), JCODE_NO_TELEMETRY='1', JCODE_DEBUG_CONTROL='1', ANTHROPIC_API_KEY='mock-key', ANTHROPIC_BASE_URL=f'http://127.0.0.1:{port}', JCODE_ANTHROPIC_AUTH='header')
        p = spawn(['/comparison/jcode/bin/jcode-linux-x86_64', '--no-update', '--no-selfdev', '--provider', 'anthropic-api', '--model', 'claude-sonnet-4-6', 'serve', '--socket', '/work/run/bench.sock'], environment, children)
        deadline = time.monotonic() + 20
        while not pathlib.Path('/work/run/bench-debug.sock').exists():
            if p.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError('jcode did not start')
            time.sleep(0.05)
        session = json.loads(debug('create_session:' + str(project)))['session_id']
        return lambda index: debug('message:' + PROMPT, session)
    sys.path.insert(0, '/app/tests/fixtures')
    from rpc import Rpc
    config = {'provider': 'anthropic', 'model': 'claude-sonnet-4-6', 'node_path': '/usr/local/bin/node', 'worker_path': '/app/adapter/worker.mjs', 'state_dir': '/work/state', 'socket_path': '/work/control.sock'}
    (WORK / 'config.json').write_text(json.dumps(config))
    environment.update(ANTHROPIC_API_KEY='sk-benchmark-synthetic', NODE_OPTIONS='--import=/diagnostic/redirect.mjs --max-old-space-size=1024', COMMON_MOCK_PORT=str(port))
    p = spawn(['/app/target/release/harness', 'serve', '--config', '/work/config.json'], environment, children)
    deadline = time.monotonic() + 20
    while True:
        try:
            client = Rpc('/work/control.sock')
            if client.request('system.hello', {'api_version': 1})['ready']:
                break
        except (OSError, ConnectionError):
            pass
        if p.poll() is not None or time.monotonic() > deadline:
            raise RuntimeError('work-leaf did not start')
        time.sleep(0.05)
    client.request('session.create', {'session_id': 'common', 'workspace': str(project)})

    def submit(index):
        req = f'common-{index}'
        client.request('input.submit', {'session_id': 'common', 'request_id': req, 'text': PROMPT, 'context': []})
        result = client.request('submission.wait', {'session_id': 'common', 'request_id': req, 'timeout_ms': 20000})
        if result['status'] != 'done':
            raise RuntimeError(str(result))
    return submit

def main():
    global phase
    parser = argparse.ArgumentParser()
    parser.add_argument('harness', choices=['peri', 'jcode', 'work-leaf'])
    parser.add_argument('--tasks', type=int, default=50)
    parser.add_argument('--output', default='/out/result.json')
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    if args.tasks < 1:
        parser.error('Task count must be positive')
    WORK.mkdir(exist_ok=True)
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 3457), Mock)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()
    children = []
    durations = []
    failure = None
    try:
        submit = launch(args.harness, 3457, children)
        phase = 'idle'
        sample()
        time.sleep(0 if args.smoke else 1)
        phase = 'load'
        sample()
        for index in range(args.tasks):
            start = time.monotonic()
            submit(index)
            durations.append(time.monotonic() - start)
        sample()
        phase = 'after'
        sample()
        time.sleep(0 if args.smoke else 5)
        if any('error' in record for record in records):
            raise RuntimeError('The model fixture rejected a request; see records')
        tools = [r for r in records if r.get('tool')]
        results = [r for r in records if r.get('result_bytes') is not None]
        if len(tools) != args.tasks or len(results) != args.tasks:
            raise RuntimeError(f'Turn counts differ: tools={len(tools)} results={len(results)} tasks={args.tasks}')
        if not all((r['result_contains_output'] for r in results)):
            raise RuntimeError('At least one harness did not return the complete expected tool output')
    except Exception as error:
        failure = str(error)
    finally:
        stop.set()
        monitor_thread.join(timeout=2)
        try:
            sample()
        except Exception as error:
            monitor_errors.append(f'{type(error).__name__}: {error}')
        finally:
            for child in reversed(children):
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
            server.shutdown()
            server.server_close()
        if monitor_errors:
            failure = failure or 'Resource sampling failed: ' + monitor_errors[0]
        value = dict(schema=1, harness=args.harness, tasks_requested=args.tasks, tasks_completed=len(durations), task_seconds=durations, failure=failure, monitor_errors=monitor_errors, answer_bytes=len(ANSWER), command=COMMAND, expected_tool_output_bytes=len(TOOL_OUTPUT), sample_interval_ms=100, records=records, samples=samples, limits={p: (CGROUP / p).read_text().strip() for p in ['cpu.max', 'memory.max', 'memory.swap.max', 'pids.max']})
        value['tool_names'] = json.loads((WORK / 'tool-names.json').read_text()) if (WORK / 'tool-names.json').exists() else []
        pathlib.Path(args.output).write_text(json.dumps(value, indent=2) + '\n')
        print(json.dumps({k: v for k, v in value.items() if k not in ['samples', 'records', 'task_seconds', 'tool_names']}), flush=True)
        if failure:
            print((WORK / 'harness.stderr').read_text()[-6000:], file=sys.stderr)
    return int(failure is not None)
if __name__ == '__main__':
    sys.exit(main())
