"""Download and verify pinned comparison binaries outside the application tree."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import urllib.request


def sha256(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def prepare(destination):
    manifest = json.loads(Path(__file__).with_name('releases.json').read_text())
    for release in manifest['releases']:
        archive = destination / 'downloads' / (release['name'] + '.tar.gz')
        archive.parent.mkdir(parents=True, exist_ok=True)
        if not archive.exists():
            urllib.request.urlretrieve(release['url'], archive)
        if sha256(archive) != release['archive_sha256']:
            raise ValueError(f'Archive checksum differs: {archive}')
        with tarfile.open(archive) as source:
            for binary in release['binaries']:
                target = destination / binary['path']
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(target.name) as member:
                    target.write_bytes(member.read())
                if sha256(target) != binary['sha256'] or target.stat().st_size != binary['bytes']:
                    raise ValueError(f'Binary checksum or size differs: {target}')
                target.chmod(0o755)
        print(f"Verified {release['name']} {release['version']}", flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    prepare(args.destination.resolve())
