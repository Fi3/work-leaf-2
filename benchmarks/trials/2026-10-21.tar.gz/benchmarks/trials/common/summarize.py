import json, pathlib, re, statistics, sys
root = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else pathlib.Path(__file__).resolve().parents[3] / '.bench-results/investigation/comparison'
label = sys.argv[1] if len(sys.argv) > 1 else 'common'
results = []
for p in sorted(root.glob(label + '-*.json')):
    if not re.fullmatch(re.escape(label) + r'-(work-leaf|jcode|peri)-[0-9]+\.json', p.name):
        continue
    d = json.loads(p.read_text())
    if 'samples' not in d:
        continue
    phases = {name: [s for s in d['samples'] if s['phase'] == name] for name in ['idle', 'load', 'after']}
    fixture_errors = sum('error' in record for record in d['records'])
    r = {'run': p.stem, 'harness': d['harness'], 'fixture_errors': fixture_errors, 'failure': d['failure'] or (f'{fixture_errors} model fixture errors' if fixture_errors else None), 'tasks': d['tasks_completed'], 'task_p50_ms': statistics.median(d['task_seconds']) * 1000 if d['task_seconds'] else None, 'task_p95_ms': sorted(d['task_seconds'])[int((len(d['task_seconds']) - 1) * 0.95)] * 1000 if d['task_seconds'] else None, 'task_seconds': sum(d['task_seconds'])}
    for name, ss in phases.items():
        if not ss:
            continue

        def app(s, key):
            return sum((v[key] for v in s['processes'] if v['role'] != 'driver'))
        r[name] = {'app_pss_peak_mib': max((app(s, 'pss_bytes') for s in ss)) / 2 ** 20, 'app_rss_peak_mib': max((app(s, 'rss_bytes') for s in ss)) / 2 ** 20, 'cgroup_peak_mib': max((s['memory_bytes'] for s in ss)) / 2 ** 20, 'driver_pss_peak_mib': max((sum((v['pss_bytes'] for v in s['processes'] if v['role'] == 'driver')) for s in ss)) / 2 ** 20, 'cgroup_anon_last_mib': ss[-1]['memory_stat'].get('anon', 0) / 2 ** 20, 'cgroup_file_last_mib': ss[-1]['memory_stat'].get('file', 0) / 2 ** 20, 'cpu_seconds': (ss[-1]['cpu']['usage_usec'] - ss[0]['cpu']['usage_usec']) / 1000000.0, 'throttle_seconds': (ss[-1]['cpu'].get('throttled_usec', 0) - ss[0]['cpu'].get('throttled_usec', 0)) / 1000000.0, 'duration_seconds': ss[-1]['t'] - ss[0]['t']}
        driver_cpu = [sum(v['cpu_seconds'] for v in sample['processes'] if v['role'] == 'driver') for sample in [ss[0], ss[-1]]]
        r[name]['application_cpu_seconds_estimate'] = r[name]['cpu_seconds'] - (driver_cpu[1] - driver_cpu[0])
    results.append(r)
summary = {}
for name in sorted({r['harness'] for r in results}):
    rows = [r for r in results if r['harness'] == name and (not r['failure'])]

    def stats(v):
        return {'median': statistics.median(v), 'min': min(v), 'max': max(v)} if v else None
    summary[name] = {metric: stats([r[metric] for r in rows]) for metric in ['task_seconds', 'task_p50_ms', 'task_p95_ms']}
    summary[name]['successful_runs'] = len(rows)
    summary[name]['failed_runs'] = sum(r['harness'] == name and bool(r['failure']) for r in results)
    summary[name]['load'] = {metric: stats([r['load'][metric] for r in rows]) for metric in ['app_pss_peak_mib', 'app_rss_peak_mib', 'cgroup_peak_mib', 'driver_pss_peak_mib', 'cpu_seconds', 'application_cpu_seconds_estimate', 'throttle_seconds']}
print(json.dumps({'cpu_note': 'Application CPU is cgroup CPU minus driver own-process ticks. It includes tools and has tick/sampling error; waited-child ticks are not summed.', 'runs': results, 'summary': summary}, indent=2))
