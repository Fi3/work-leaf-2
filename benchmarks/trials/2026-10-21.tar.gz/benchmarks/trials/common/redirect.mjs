const originalFetch = globalThis.fetch;
globalThis.fetch = (input, init = {}) => {
  const url = String(typeof input === 'string' || input instanceof URL ? input : input.url);
  if (!url.startsWith('https://api.anthropic.com/v1/messages')) throw Error(`Unexpected comparison URL: ${url}`);
  return originalFetch(`http://127.0.0.1:${process.env.COMMON_MOCK_PORT}/v1/messages`, init);
};
