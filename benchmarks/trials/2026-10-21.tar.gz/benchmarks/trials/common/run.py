"""Measure one retained session with 50 tools and answers; omit the editor."""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def fixture_hashes():
    return {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
            for name in ('common.py', 'redirect.mjs', 'releases.json')}


def runtime_hashes(runtime, selected):
    releases = json.loads((HERE / 'releases.json').read_text())['releases']
    hashes = {}
    for release in releases:
        if selected and release['name'] != selected:
            continue
        for binary in release['binaries']:
            path = runtime / binary['path']
            with path.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            if digest != binary['sha256'] or path.stat().st_size != binary['bytes']:
                raise ValueError(f'Comparison binary differs from its pinned release: {path}')
            hashes[binary['path']] = digest
    return hashes


def run(args):
    output = args.output.resolve()
    runtime = args.runtime.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', args.label):
        raise ValueError('Use only letters, numbers, periods, underscores, and hyphens in the label')
    if min(args.rounds, args.tasks) < 1:
        raise ValueError('Task and repeat counts must be positive')
    existing = sorted(output.glob(args.label + '-*'))
    if existing:
        raise FileExistsError(f'Trial label already exists: {existing[0]}')
    image = json.loads(subprocess.check_output(['docker', 'image', 'inspect', args.image]))[0]['Id']
    binaries = runtime_hashes(runtime, args.only)
    fixtures = fixture_hashes()
    manifest = {
        'label': args.label, 'image': args.image, 'image_id': image,
        'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'fixture_sha256': fixtures, 'runtime_sha256': binaries,
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'runs': [],
    }
    for repetition in range(args.rounds):
        names = ['work-leaf', 'jcode', 'peri']
        names = [args.only] if args.only else names[repetition % 3:] + names[:repetition % 3]
        for name in names:
            if fixture_hashes() != fixtures or runtime_hashes(runtime, args.only) != binaries:
                raise RuntimeError('Comparison inputs changed during the trial series')
            stem = f'{args.label}-{name}-{repetition + 1}'
            container = f'harness-comparison-{name}-' + uuid.uuid4().hex[:12]
            command = [
                'docker', 'run', '--rm', '--name', container,
                '--network', 'none', '--cpus', '2', '--memory', '512m', '--memory-swap', '512m',
                '--pids-limit', '256',
                '--mount', f'type=bind,src={runtime},dst=/comparison,readonly',
                '--mount', f'type=bind,src={HERE},dst=/diagnostic,readonly',
                '--mount', f'type=bind,src={output},dst=/out', '--entrypoint', 'python3', image,
                '/diagnostic/common.py', name, '--tasks', str(args.tasks),
                '--output', f'/out/{stem}.json',
            ]
            context = {
                'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'host_loadavg': Path('/proc/loadavg').read_text().strip(),
                'host_cpu_count': os.cpu_count(),
                'running_containers': subprocess.check_output(
                    ['docker', 'ps', '--format', '{{.Names}}'], text=True).splitlines(),
            }
            print('START', stem, flush=True)
            with (output / (stem + '.log')).open('x') as log:
                try:
                    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
                    exit_code = result.returncode
                except subprocess.TimeoutExpired:
                    log.write('\nComparison timed out after 180 seconds.\n')
                    log.flush()
                    exit_code = 124
                finally:
                    subprocess.run(['docker', 'rm', '--force', container],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            if fixture_hashes() != fixtures or runtime_hashes(runtime, args.only) != binaries:
                raise RuntimeError('Comparison inputs changed during measurement')
            manifest['runs'].append({'stem': stem, 'exit_code': exit_code, 'command': command, 'host_context': context})
            (output / (args.label + '-runs.json')).write_text(json.dumps(manifest, indent=2) + '\n')
            print('END', stem, 'exit', exit_code, flush=True)
            if exit_code:
                print((output / (stem + '.log')).read_text()[-4000:], flush=True)
                raise SystemExit(exit_code)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / '.bench-results/investigation/comparison')
    parser.add_argument('--label', default='common')
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--tasks', type=int, default=50)
    parser.add_argument('--only', choices=['work-leaf', 'jcode', 'peri'])
    run(parser.parse_args())
