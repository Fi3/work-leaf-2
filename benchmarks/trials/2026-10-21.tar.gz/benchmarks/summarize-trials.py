"""Summarize comparable trial files and retain the identity of every input."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]


def read_record(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest()}, json.loads(data)


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def load_runner():
    spec = importlib.util.spec_from_file_location('benchmark_runner', ROOT / 'scripts/bench.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def distribution(values):
    return {'count': len(values), 'median': statistics.median(values),
        'minimum': min(values), 'maximum': max(values), 'range': max(values) - min(values)}


def accepted_origins():
    origins = {}
    for path in sorted((ROOT / 'benchmarks/results').glob('*.json')):
        identity, result = read_record(path)
        if result.get('completed') is True and result.get('source_fingerprint'):
            origins.setdefault(result.get('docker_image_id'), []).append({**identity,
                'source_fingerprint': result['source_fingerprint'], 'profile_sha256': result.get('profile_sha256'),
                'canonical_profile_sha256': canonical_hash(result.get('profile'))})
    return origins


def phase_metrics(result, resources, phase):
    resource = resources.get(phase)
    if not resource:
        return None, 'Fewer than two resource samples with distinct times'
    metrics = {'peak_sampled_memory_mib': resource['peak_sampled_memory_bytes'] / 1048576,
        'mean_cpu_cores': resource['mean_cpu_cores'], 'sampled_seconds': resource['sampled_seconds'],
        'cpu_throttled_seconds': resource['cpu_throttled_seconds']}
    if phase == 'idle':
        return metrics, None
    matches = [stage for stage in result.get('stages', []) if stage.get('phase') == phase]
    if len(matches) != 1:
        return None, f'Expected one completed stage result; found {len(matches)}'
    stage = matches[0]
    if type(stage.get('completed_tasks')) is not int or stage['completed_tasks'] <= 0:
        return None, 'Stage has no positive completed task count'
    latencies = [stage.get(name) for name in ('p50_ms', 'p95_ms', 'p99_ms')]
    if not all(finite(value) for value in latencies) or latencies != sorted(latencies):
        return None, 'Stage latency percentiles are missing or invalid'
    metrics.update({name: stage[name] for name in ('completed_tasks', 'p50_ms', 'p95_ms', 'p99_ms')})
    metrics['tasks_per_nominal_load_second'] = stage['completed_tasks'] / result['profile']['load_seconds']
    return metrics, None


def trial_record(path, result, identity, runner, phases):
    profile = result.get('profile')
    if not isinstance(profile, dict) or result.get('docker_limits') != profile.get('resources'):
        raise ValueError(f'{path}: missing profile or Docker limits differ from the profile')
    if not isinstance(result.get('docker_image_id'), str):
        raise ValueError(f'{path}: missing Docker image identity')
    resources = runner.resource_summary(result.get('measurements', []))
    if resources != result.get('resources_by_phase'):
        raise ValueError(f'{path}: recorded resource summary differs from raw samples')
    metrics, exclusions = {}, []
    for phase in phases:
        values, reason = phase_metrics(result, resources, phase)
        if reason:
            exclusions.append({'phase': phase, 'reason': reason})
        else:
            metrics[phase] = values
    required_stages = phases[1:]
    complete_stages = [stage.get('phase') for stage in result.get('stages', [])] == required_stages
    exhaustion = result.get('exhaustion', {})
    sampled_oom = runner.capacity_event_delta(result.get('measurements', []), 'oom')
    sampled_kills = runner.capacity_event_delta(result.get('measurements', []), 'oom_kill')
    count = result.get('capacity_completed_sessions')
    verified = (result.get('completed') is True and complete_stages and not exclusions
        and exhaustion.get('observed') is True and exhaustion.get('phase') == 'capacity'
        and exhaustion.get('reason') == 'memory_limit' and sampled_oom > 0 and sampled_kills > 0
        and exhaustion.get('oom_delta') == sampled_oom and exhaustion.get('oom_kill_delta') == sampled_kills
        and type(count) is int and count >= 0)
    capacity = {'verified': verified, 'reported_completed_sessions': count}
    if not verified:
        capacity['exclusion_reason'] = result.get('error') or 'Complete capacity exhaustion evidence is absent or inconsistent'
    return {**identity, 'label': result.get('trial_label', path.stem), 'started_at': result.get('started_at'),
        'docker_image_id': result['docker_image_id'], 'reported_source_fingerprint': result.get('source_fingerprint'),
        'run_completed': result.get('completed'), 'run_error': result.get('error'),
        'normal_phases': metrics, 'phase_exclusions': exclusions, 'capacity': capacity}


def summarize(paths, manifests=None):
    runner, origins = load_runner(), accepted_origins()
    groups, profile, seen_labels, seen_hashes = {}, None, set(), set()
    for path in paths:
        identity, result = read_record(path)
        if profile is None:
            profile = result.get('profile')
        if result.get('profile') != profile:
            raise ValueError(f'{path}: profile differs from the other input trials')
        if not isinstance(profile, dict) or not finite(profile.get('load_seconds')) or profile['load_seconds'] <= 0:
            raise ValueError(f'{path}: profile has no positive load duration')
        phases = ['idle', *[f'load-{count}' for count in profile['concurrent_sessions']], 'hidden-editor']
        trial = trial_record(path, result, identity, runner, phases)
        if trial['label'] in seen_labels or identity['sha256'] in seen_hashes:
            raise ValueError(f'{path}: duplicate trial label or raw file contents')
        seen_labels.add(trial['label']); seen_hashes.add(identity['sha256'])
        group = re.sub(r'-[1-9][0-9]*$', '', trial['label'])
        groups.setdefault(group, {'trials': []})['trials'].append(trial)
    if not groups:
        raise ValueError('At least one trial file is required')
    for name, group in groups.items():
        trials = group['trials']
        images = {trial['docker_image_id'] for trial in trials}
        if len(images) != 1:
            raise ValueError(f'{name}: trials within a group use different Docker images')
        image = next(iter(images))
        group['docker_image_id'] = image
        group['accepted_image_origins'] = [origin for origin in origins.get(image, [])
            if origin['canonical_profile_sha256'] == canonical_hash(profile)]
        if name in (manifests or {}):
            identity, manifest = read_record(manifests[name])
            if manifest.get('docker_image_id') != image:
                raise ValueError(f'{name}: manifest Docker image does not match the trials')
            group['manifest'] = {**identity, 'contents': manifest}
        group['source_provenance_missing'] = (not group['accepted_image_origins'] and 'manifest' not in group
            and not all(trial['reported_source_fingerprint'] for trial in trials))
        group['normal_phases'] = {}
        for phase in phases:
            observations = [trial['normal_phases'][phase] for trial in trials if phase in trial['normal_phases']]
            group['normal_phases'][phase] = {metric: distribution([value[metric] for value in observations])
                for metric in observations[0]} if observations else {}
        capacities = [trial['capacity']['reported_completed_sessions'] for trial in trials if trial['capacity']['verified']]
        group['verified_capacity_completed_sessions'] = distribution(capacities) if capacities else None
        group['capacity_excluded_trials'] = [trial['label'] for trial in trials if not trial['capacity']['verified']]
    extra = set(manifests or {}) - set(groups)
    if extra:
        raise ValueError(f'Manifest groups have no input trials: {sorted(extra)}')
    return {'schema': 1, 'diagnostic_only': True, 'accepted_capacity_evidence': False,
        'canonical_profile_sha256': canonical_hash(profile), 'profile': profile, 'groups': groups,
        'notes': [
            'Normal-stage results remain included when a later capacity phase fails; each exclusion is listed.',
            'Group distributions describe per-run values; latency percentiles are not pooled task percentiles.',
            'Task rates use the nominal profile duration. In-flight tasks finish after its deadline; exact stage wall time is absent.',
            'Sampled resource duration excludes phase edges and must not be used as exact task-stage duration.',
            'Capacity summaries include only runs with complete sampled allocation-failure and kill evidence.',
            'Accepted image origins map image identity to prior source evidence without changing raw trial files.',
            'Trial files and optional manifests retain SHA-256 hashes. This summary is not accepted benchmark push evidence.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', type=Path, nargs='+')
    parser.add_argument('--manifest', action='append', default=[], metavar='GROUP=PATH')
    args = parser.parse_args()
    manifests = {}
    for value in args.manifest:
        name, separator, path = value.partition('=')
        if not separator or not name or not path or name in manifests:
            parser.error('--manifest requires a unique GROUP=PATH')
        manifests[name] = Path(path)
    print(json.dumps(summarize(args.paths, manifests), indent=2))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f'Cannot summarize trials: {error}', file=sys.stderr)
        sys.exit(1)
