"""Repeat immutable images with the unchanged capacity profile; never publish."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def run(args):
    spec = importlib.util.spec_from_file_location('benchmark_runner', ROOT / 'scripts/bench.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    profile = json.loads((ROOT / 'benchmarks/profile.json').read_text())
    images = {}
    for value in args.images:
        label, separator, image = value.partition('=')
        if not separator or not re.fullmatch(r'[A-Za-z0-9_.-]+', label) or label in images:
            raise ValueError('Use unique LABEL=IMAGE arguments')
        images[label] = subprocess.check_output(['docker', 'image', 'inspect', image, '--format', '{{.Id}}'], text=True).strip()
        embedded = subprocess.check_output(['docker', 'run', '--rm', '--network', 'none',
            '--entrypoint', 'cat', images[label], '/app/benchmarks/profile.json'], text=True)
        if json.loads(embedded) != profile:
            raise ValueError('Image profile differs from the working profile: ' + label)
    if args.repeats < 1:
        raise ValueError('Repeat count must be positive')
    args.output.mkdir(parents=True, exist_ok=True)
    for label in images:
        if list(args.output.glob(label + '-*')):
            raise FileExistsError('Trial label already exists: ' + label)
    labels = list(images)
    for repeat in range(1, args.repeats + 1):
        order = labels[(repeat - 1) % len(labels):] + labels[:(repeat - 1) % len(labels)]
        for group in order:
            label = f'{group}-{repeat}'
            started = time.time()
            host = {'kernel': platform.release(), 'machine': platform.machine(), 'cpu_count': os.cpu_count(),
                'loadavg': Path('/proc/loadavg').read_text().strip(),
                'running_containers': subprocess.check_output(['docker', 'ps', '--format', '{{.Names}}'], text=True).splitlines()}
            print('START', label, flush=True)
            result = runner.run_container(images[group], profile, args.output, label)
            result.update(trial_label=label, profile=profile, host=host,
                runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                started_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started)), elapsed_seconds=time.time() - started)
            (args.output / f'{label}.json').write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'label': label, 'completed': result['completed'], 'error': result['error'],
                'capacity_completed_sessions': result['capacity_completed_sessions']}), flush=True)
            # A failed capacity phase does not erase earlier normal-load evidence.


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('images', nargs='+', metavar='LABEL=IMAGE')
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--output', type=Path, default=ROOT / '.bench-results/investigation')
    run(parser.parse_args())
