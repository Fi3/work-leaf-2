# Performance

Read this document when you change resource limits, execution load, transcript
retention, or the benchmark. [ARCHITECTURE.md](ARCHITECTURE.md) explains component
ownership. [README.md](README.md) gives the required runtimes and normal checks.

## Resource policy

Share one server and Pi worker across sessions. Keep saved history in SQLite and
load display data when required. Bound protocol records, queues, and editor
history. Replace pending progress with the latest state. Preserve exact outcomes
in storage instead of retaining every progress update in each client.

| Resource | Current control |
| --- | --- |
| Public snapshot | At most 512 KiB and 50 recent entries. |
| Entry or live-tool text preview | At most 8 KiB, with explicit truncation. |
| Loaded editor history | At most 200 entries and 1 MiB of text, identifiers, and kinds, plus the current snapshot. |
| Hidden transcript display | Release text, highlights, and loaded history. Preserve draft and submission state. |
| Generated buffer undo | Disabled for transcript and sidebar buffers. Prompt undo remains enabled. |
| Progress writes | No text write for unchanged output; replace only changed lines. Hidden chats do not format progress. |
| Connected clients and active sessions | At most 32 clients and four active sessions. |
| Slow watch | Keep the newest pending snapshot. Other unsent output has a 4 MiB limit per client. |
| Idle server | Wait for descriptor readiness or the next deadline. |

These limits bound particular data, not total process memory. Pi can retain a
complete active context behind a small snapshot. The selected hidden session
still has a watch for live state and stop controls. Pi releases idle task context
after ten minutes and unused documents after 30 seconds. This releases cache
references; JavaScript garbage collection and the memory allocator control when
resident memory falls.
The Node worker and loaded provider code remain resident. Tools can allocate
additional memory.

## When to run the benchmark

Run the resource benchmark when a human completes a pull request for review, or
when the user explicitly requests a measurement. Do not add it to the normal
release gate or run it after every change. The first baseline for this work is
explicitly authorized.

Complete normal correctness checks first. Stage each new source or documentation
file, or use `git add -N PATH`, so the benchmark can include it. Then run:

```sh
python3 scripts/bench.py --publish
```

The runner builds and measures an isolated Docker image from a source snapshot.
It requires Docker with Linux cgroup version 2. A cgroup is a Linux process group
with shared resource accounting and limits. The fixed profile is in
[benchmarks/profile.json](benchmarks/profile.json):

| Setting | Value |
| --- | --- |
| Platform | Linux AMD64. |
| CPU quota | Two CPU cores. |
| Memory | 512 MiB. |
| Swap | Disabled. |
| Process limit | 256. |
| Network during measurement | Disabled. |

Image preparation can download the exact runtimes and locked dependencies.
Measurement makes no paid model call. A local substitute supplies model stream
data through the provider SDK. The workload still uses the real server, Pi
storage and scheduler, Bash tools, and Neovim interface.
Neovim runs without a terminal display. This measures plugin work and buffer
changes, but excludes terminal screen rendering. The benchmark sets the Node
old-generation heap ceiling to 1 GiB so that the 512 MiB container limit can
stop the workload before a smaller V8 heap limit. This setting applies only to
the benchmark.

The runner samples every 500 milliseconds. It measures five seconds of idle
time, then ten seconds each with one, two, and four active sessions. The capacity
phase follows a further ten-second run with the editor transcript hidden and a
history reload after reopening. It adds sessions in batches of four, with
256 KiB of instructions and 64 KiB of input per session, until memory is
exhausted. It records CPU and memory for the complete container and samples
individual processes where available. The capacity phase must observe an
out-of-memory allocation failure and kill reported by the cgroup. A timeout, model error, or normal
application limit is not proof of memory exhaustion.

Keep normal-load results separate from the final exhaustion result. Capacity
depends on the fixed synthetic instructions, input size, and retention time.
It does not establish a universal maximum chat count or predict paid-model
latency. Reaching the ten-minute timeout or the 10,000-session test ceiling
without a memory failure produces an incomplete result.

## Evidence and push checks

The source fingerprint is a SHA-256 hash of the measured file names, modes, and
contents. It includes all files listed in the Git index, including documentation,
and uses their current working-tree contents. Untracked files must first be
staged or added with `git add -N`. Only `.bench-results/` and
`benchmarks/results/` are excluded, so storing results does not change the
measured source identity.

Local results are stored under `.bench-results/`. Reviewable baseline results
are also stored under `benchmarks/results/` when `--publish` is used. Omit that
option for a local trial. Each result uses its source fingerprint as
the file name and records the profile hash, complete profile, Docker image ID,
actual limits, measurements, and exhaustion evidence. Source or profile changes
require a new result; an evidence-only commit does not.

Install the local Git warning once in each clone:

```sh
sh scripts/install-hooks.sh
```

The installer preserves existing hooks. If another hooks directory or enabled
hook exists, it explains how to call `.githooks/pre-push` from that hook.

Before a push, the hook checks each outgoing ref tip against its benchmark
evidence. It checks the pushed commit, not an unrelated working tree or `HEAD`.
A missing or invalid result prints a warning and asks through the terminal:

```text
Push these unmeasured changes? Type yes to continue:
```

Only the exact answer `yes` permits that unmeasured push. Without a terminal,
the hook refuses the push. The hook does not run the benchmark itself. A local
Git hook is a review reminder and can be bypassed with Git's normal hook controls.

Inspect the evidence independently with:

```sh
python3 scripts/bench-evidence.py fingerprint
python3 scripts/bench-evidence.py validate
python3 scripts/bench-evidence.py validate --ref COMMIT
```

## Compare results

Compare the same profile and workload. Record source and image identity beside
the values. Check steady load, peak memory, CPU time and throttling, completed
tasks, the 50th, 95th, and 99th percentile task durations, and the
last successful load before exhaustion. A lower server RSS alone is not enough
if the worker, editor, or tools consume more memory.

The resource summary reports each phase over its first and last samples. Mean
CPU cores is CPU time divided by that elapsed time; `1.0` means one fully used
core. The sampled memory peak can miss a short allocation between samples.
Use the recorded cgroup `memory_peak_bytes` for the whole-container peak.

RSS is resident memory for one process; shared pages can appear in several
processes. PSS divides shared pages among those processes. Container accounting
also includes memory such as file cache. Released JavaScript or Lua objects do
not guarantee an immediate RSS decrease, so use repeated bounded workloads and
observe retention as well as peaks.

## Resource investigation: 2026-10-21

The investigation keeps Pi, the shared worker, and the existing storage and
editor architecture. The first accepted baseline remains
[1d1ae9a](benchmarks/results/1d1ae9a4246cbc06cc54e7c2701309bd30433b3ffb20d54fcc137248177aba87.json).
Investigation trials are separate from accepted push evidence. Summaries:
[standard.json](benchmarks/trials/2026-10-21/standard.json), [imports.json](benchmarks/trials/2026-10-21/imports.json),
[formatting.json](benchmarks/trials/2026-10-21/formatting.json), [caches.json](benchmarks/trials/2026-10-21/caches.json),
[long-session.json](benchmarks/trials/2026-10-21/long-session.json),
[cpu-profile.json](benchmarks/trials/2026-10-21/cpu-profile.json), and
[common.json](benchmarks/trials/2026-10-21/common.json).
The [manifest](benchmarks/trials/2026-10-21/manifest.json) maps original paths
to compressed raw records, source copies, image identities, and SHA-256 hashes.
The [check report](benchmarks/trials/2026-10-21/checks.json) records correctness checks.
Unless stated otherwise, repeated results give the median and minimum–maximum
range. These ranges describe the trials; they are not confidence intervals.

### What the measurements include

The unchanged `capacity-v1` profile measures the Rust server, shared Node/Pi
worker, RPC client, headless Neovim, tools, Python driver, and monitor. The model
substitute runs in the worker; its parsing, events, and stream delays are workload
costs. Cgroup memory also includes charged file cache and kernel memory.

Process and container memory cannot be subtracted to assign ownership. In the
first accepted idle result, median worker RSS was 86.75 MiB and PSS was
85.23 MiB, while the sampled container peak was 57.62 MiB. A process can map
resident pages charged to another cgroup. The kernel describes this in its
[memory ownership rules](https://docs.kernel.org/admin-guide/cgroup-v2.html#memory-ownership).
The diagnostics record process RSS/PSS, anonymous memory, and cgroup
`memory.stat` separately. They do not identify the owner of every shared page.

The standard sampler groups server and RPC client together, and driver, init,
and tools together. Diagnostics separate these roles. Short tools can escape
sampling. Worker CPU for reaped children estimates their cost; adding live-child
samples would count some work twice. RSS/PSS include resident code, shared libraries,
heap, and stacks; they do not isolate one of these costs.

Task duration runs from before `input.submit` until `submission.wait` returns.
It includes stream waits, SDKs, Pi scheduling, tools, storage, adapter, routing,
and driver work. Each standard task has a five-event tool stream and a 36-event
answer stream, with a scheduled 3 ms delay per event. Service intervals overlap;
subtracting unrelated medians does not measure pure harness overhead.

Standard stages reuse chats, combining concurrency with growing history and
startup costs. Tasks finish after the ten-second admission period; counts divided
by ten are only nominal rates. Resource summaries exclude unsampled edges. The
hidden-editor phase includes reopening and history reads. Headless Neovim excludes
terminal drawing; the sidebar is not open. Short stages and 500 ms samples do
not establish long-session stability or capture every allocation peak.

### Repeatability before changes

Three runs repeated each existing image. `First` means the image from
`1d1ae9a4246cbc06cc54e7c2701309bd30433b3ffb20d54fcc137248177aba87`;
`Current` means the image from
`ca5e93d3064cf97e124338a9c7038f4d73b0d9f4a936388bc625ab4a5aa57292`.
These runs precede the candidate changes. Memory below is sampled cgroup peak;
CPU is mean cores during the sampled interval.

| Stage | First memory, MiB | Current memory, MiB | First CPU, cores | Current CPU, cores |
| --- | ---: | ---: | ---: | ---: |
| Idle | 62.72 (61.82–63.40) | 62.28 (61.34–62.90) | 0.0097 (0.0084–0.0103) | 0.0079 (0.0053–0.0085) |
| One chat | 131.14 (127.53–136.39) | 133.46 (130.05–134.41) | 0.404 (0.330–0.404) | 0.330 (0.257–0.395) |
| Two chats | 136.82 (134.25–137.86) | 138.01 (131.68–140.51) | 0.570 (0.526–0.574) | 0.518 (0.387–0.560) |
| Four chats | 163.65 (160.27–163.87) | 164.62 (162.60–165.16) | 0.761 (0.761–0.781) | 0.776 (0.756–0.820) |
| Hidden editor | 166.31 (164.29–176.70) | 170.06 (169.69–171.16) | 0.317 (0.312–0.319) | 0.327 (0.254–0.362) |

| Stage | First completed tasks | Current completed tasks | First task p95, ms | Current task p95, ms |
| --- | ---: | ---: | ---: | ---: |
| One chat | 56 (56–60) | 60 (56–64) | 208.14 (199.08–213.88) | 198.37 (171.99–208.26) |
| Two chats | 107 (105–111) | 111 (105–124) | 218.74 (197.98–220.78) | 219.97 (177.39–221.65) |
| Four chats | 204 (184–206) | 194 (192–196) | 226.69 (215.21–287.31) | 247.07 (229.81–253.87) |
| Hidden editor | 58 (51–58) | 58 (56–61) | 205.30 (196.88–207.71) | 204.27 (196.00–208.51) |

The four-chat memory ranges overlap. CPU and task durations also vary. These
repeats do not establish that the earlier 158.17 and 161.53 MiB observations
represent a regression. Verified capacity was 312 retained sessions (308–328)
for First, and 344 (328–360) for two verified Current runs. `current-1` completed
normal stages but lost complete exhaustion evidence when its container died.
Its normal stages remain included; its capacity is excluded. The original
356-session result is an observation, not a fixed limit. Only four sessions
are active during capacity testing.

### Final paired standard trials

Three further runs per image alternated order: before/after, after/before,
before/after. `Before` is Current above; `After` adds both formatting changes
and 30-second unused-document retention. The image and application-file hashes
are in the trial manifest. The embedded profile was checked against the unchanged
host profile before measurement. No diagnostic observer was loaded.

| Stage | Before memory, MiB | After memory, MiB | Before CPU, cores | After CPU, cores |
| --- | ---: | ---: | ---: | ---: |
| Idle | 57.70 (56.23–57.84) | 54.75 (53.77–56.09) | 0.006 (0.005–0.006) | 0.007 (0.005–0.011) |
| One chat | 121.98 (120.27–134.70) | 121.22 (120.21–122.68) | 0.293 (0.253–0.355) | 0.292 (0.254–0.381) |
| Two chats | 133.16 (131.33–140.20) | 135.79 (126.20–137.82) | 0.383 (0.376–0.410) | 0.406 (0.370–0.491) |
| Four chats | 158.80 (154.67–171.70) | 157.97 (151.95–165.50) | 0.643 (0.643–0.708) | 0.641 (0.625–0.736) |
| Hidden editor | 161.77 (160.86–168.86) | 161.98 (157.07–164.15) | 0.224 (0.204–0.340) | 0.261 (0.203–0.336) |

| Stage | Before tasks | After tasks | Before task p95, ms | After task p95, ms |
| --- | ---: | ---: | ---: | ---: |
| One chat | 62 (58–64) | 63 (57–64) | 181.80 (164.80–206.49) | 170.41 (169.07–225.78) |
| Two chats | 120 (119–125) | 121 (111–124) | 198.75 (172.64–199.26) | 180.47 (178.33–205.57) |
| Four chats | 216 (212–222) | 224 (201–228) | 216.41 (204.35–233.83) | 195.89 (191.81–226.79) |
| Hidden editor | 63 (56–63) | 60 (57–64) | 185.04 (171.25–200.39) | 198.49 (163.94–216.27) |

At four chats, median sampled memory changed from 158.80 to 157.97 MiB
(−0.83 MiB, −0.52%), and mean CPU from 0.6434 to 0.6407 cores (−0.43%).
The ranges overlap. Task count and duration ranges also overlap. These trials
do not establish a whole-application active-load saving. The lower idle cgroup
peak is an observation; the data do not identify its cause or establish a
general 2.95 MiB saving. Both before and after measurements differ from the
earlier batch, reinforcing the need for nearby repeated controls.

Verified capacity was 328 sessions (312–344, two runs) before and 340
(324–352, three runs) after. `paired-before-2` reported 348 sessions but lacked
complete sampled exhaustion evidence; only its normal stages are included.
The verified capacity ranges overlap. There is no proven capacity increase.

All six runs applied two cores, 512 MiB, no swap, and no external network.
No normal stage was throttled. Start host load averages were 2.86–3.89 on
32 logical CPUs. CPU placement was not fixed and another unrelated container
stack remained active. These are controlled container limits, not an exclusive host.

### Worker startup and provider loading

Three processes ran the same import sequence with forced garbage collection
after each stage. Collection releases unreachable JavaScript objects; stage CPU
excludes this forced collection. These worker measurements use a 268 MiB V8 heap
limit. Imports accumulate; later differences depend on what is already loaded.

| Stage | Retained heap, MiB | PSS, MiB | Stage CPU, ms |
| --- | ---: | ---: | ---: |
| Node and probe | 4.48 (4.48–4.48) | 46.49 (46.33–46.51) | 2.47 (2.45–2.48) |
| Pi Durable import | 12.32 (12.32–12.32) | 77.46 (77.40–77.99) | 187.74 (185.49–193.48) |
| Provider catalogs | 14.93 (14.92–14.93) | 80.41 (79.85–80.89) | 39.91 (39.46–40.03) |
| Application adapter import | 16.38 (16.37–16.38) | 82.54 (82.32–83.41) | 28.53 (28.10–29.93) |
| Application open | 16.81 (16.80–16.81) | 84.21 (84.10–85.20) | 10.03 (9.97–10.20) |
| OpenAI API import | 21.54 (21.54–21.54) | 94.04 (93.34–94.28) | 87.37 (87.17–95.54) |
| Anthropic API import | 23.83 (23.83–23.83) | 97.08 (96.14–97.36) | 32.66 (32.34–35.09) |
| Application close | 23.73 (23.72–23.73) | 97.07 (96.14–97.36) | 1.16 (1.11–1.20) |

The first sample includes diagnostic imports, not bare Node startup CPU.
Catalogs and wrappers load at startup; heavy SDKs are already deferred. Closing
the application does not unload modules. Source-file bytes do not measure memory
ownership. The Pi Durable stage also loads Chord and schema-library code. The
adapter-import increment includes Pi tool, environment, and storage modules;
it is not a measurement of application adapter code alone.
The runner recorded its image tag and raw hashes, but no historical
probe hash; the later probe extension left its import branch unchanged.

### Two local formatting changes

The first change uses one snapshot-size loop, preserving removal order and the
public limit while removing repeated complete JSON checks. The second encodes
only the required UTF-8 prefix for an 8 KiB preview. Unicode boundaries,
replacement of isolated surrogates, and truncation remain unchanged. Neither
change adds a cache or changes ownership.

Seven repetitions alternated order, with 500 snapshots per measurement,
collection before each block, and output equality checked before timing.
Values are CPU milliseconds per 500 snapshots. The preview comparison adds
that change to the snapshot-loop candidate.

| Change and fixture | Before CPU, ms | After CPU, ms | Median change |
| --- | ---: | ---: | ---: |
| Snapshot loop: one task | 18.04 (15.08–21.14) | 12.46 (9.96–15.24) | −30.9% |
| Snapshot loop: 50 tasks | 140.99 (129.82–197.22) | 91.20 (87.86–119.20) | −35.3% |
| Snapshot loop: 256 KiB settings | 319.55 (314.75–326.22) | 91.31 (83.69–98.70) | −71.4% |
| Preview: one task | 13.08 (10.93–18.18) | 8.63 (8.51–11.32) | −34.0% |
| Preview: 50 tasks | 109.05 (87.46–155.51) | 74.54 (64.59–93.34) | −31.6% |
| Preview: 256 KiB settings | 100.29 (93.99–102.93) | 92.68 (77.17–94.55) | −7.6% |

These results come from the raw `snapshot-micro.json` and `preview-micro.json`
trials in the evidence archive. They exclude Pi, storage, tools, and editor work.
They establish reduced local formatting cost, not those percentages of total
CPU or task duration. Both small changes are retained; the full release gate passed.

### Cache lifetime experiments

The 33 trials compared default retention, zero retention, both caches at
30 seconds, and documents alone at 30 seconds. Default retention is ten minutes
for both idle context and unused documents. Document-only retention keeps the
ten-minute context limit. Each workload and setting had three runs. Trials used
two cores, 512 MiB, and a 268 MiB V8 heap limit, unlike the standard benchmark's
1 GiB old-generation ceiling. Worker CPU excludes tool children.

The six document-only trials ran later, not interleaved with the matching
default trials. They used the same immutable image, probe, workload, and resource
limits. Host conditions could differ over time. The earlier comparisons changed
both caches together and cannot divide their savings between the two caches.

Four sessions completed 200 tasks in each reuse trial without forced collection.
Thirty-second timers normally do not expire during this short active load.
There were three runs per setting.

| Retention | Worker CPU, ms/task | Worker PSS after load, MiB | Four-task resume, ms |
| --- | ---: | ---: | ---: |
| Default, ten minutes | 22.63 (22.12–23.44) | 136.52 (132.33–138.30) | 204.29 (203.69–210.46) |
| Zero | 27.44 (26.42–28.26) | 139.10 (136.67–140.13) | 212.53 (209.74–230.53) |
| Both thirty seconds | 22.08 (21.74–22.35) | 137.81 (130.66–139.52) | 201.35 (200.32–210.07) |

Zero retention is rejected: median worker CPU increased 21.3%, with no
consistent memory benefit. Thirty-second and default CPU ranges overlap; their
small median difference does not establish a CPU saving.

A separate workload retained 64 sessions, each with 256 KiB instructions and
64 KiB input, then idled for 33 seconds. One watch stayed active until before
resume. With forced collection at every checkpoint, median post-idle heap was
80.97 MiB with defaults and 41.53 MiB with short retention: 39.44 MiB less
reachable heap. Post-idle PSS was 161.98 (159.60–163.07) versus
131.05 (130.35–131.50) MiB. Forced collection does not prove natural RSS savings.

Three natural runs per setting repeated that workload without forced collection.
Resume means four concurrent tasks after watch release, before explicit reload.

| Retention | PSS after idle, MiB | PSS after resume, MiB | Heap after resume, MiB | Resume, ms |
| --- | ---: | ---: | ---: | ---: |
| Default | 162.09 (160.01–162.18) | 175.06 (172.47–175.95) | 83.76 (83.75–85.50) | 227.17 (216.86–242.86) |
| Both thirty seconds | 160.57 (159.80–161.45) | 146.54 (145.96–146.71) | 49.50 (49.31–49.51) | 236.37 (224.44–243.39) |
| Documents only | 159.68 (156.89–162.04) | 158.75 (156.61–159.08) | 70.51 (68.67–70.51) | 236.29 (223.85–239.39) |

Immediate post-idle ranges overlap. After resumed work, the combined policy
used 28.52 MiB less median PSS than default; document-only retention used
16.30 MiB less. These are separate observations. Expiry need not return resident
memory at exactly 30 seconds. Batch duration includes a 20 ms checkpoint pause
and is not individual task latency. These are worker-only results for the same
retained data, not total application savings.

Nine more trials tested longer histories without forced collection. Four
sessions each completed 100 tasks, idled for 33 seconds, then resumed with one
task each. Normal Pi compaction stayed enabled; active context need not contain
all 100 tasks. The prior final receipt remained available after resumed work.

| Retention | PSS after idle, MiB | PSS after resume, MiB | Resume, ms | Resume CPU, ms/task |
| --- | ---: | ---: | ---: | ---: |
| Default | 110.14 (109.44–118.14) | 124.52 (124.34–132.97) | 222.75 (221.65–265.14) | 29.87 (29.45–41.36) |
| Both thirty seconds | 116.22 (115.32–117.14) | 136.50 (135.65–137.68) | 244.20 (219.34–267.24) | 35.77 (32.80–43.73) |
| Documents only | 117.11 (116.99–119.04) | 132.11 (131.86–134.09) | 226.59 (215.10–304.80) | 29.27 (28.36–49.63) |

The combined 30-second policy is rejected. After long-history resume, its
median PSS was 11.98 MiB higher than default, with no overlap in those PSS
ranges. Median resume CPU was 19.7% higher, although CPU and duration ranges
overlap. Resuming all four long histories differs from resuming four of the
64 large idle sessions. Only one resumed batch was measured; the trials do not
establish how long the additional allocation remains.

The table below measures PSS changes within each run, from the final idle
sample through watch release and the four resumed tasks.

| Workload | Default PSS change, MiB | Both thirty seconds, MiB | Documents only, MiB |
| --- | ---: | ---: | ---: |
| 64 large sessions | +12.97 (+12.46–+13.77) | −14.03 (−15.49–−13.09) | −0.60 (−3.29–−0.27) |
| Four long histories | +14.83 (+14.38–+14.91) | +20.33 (+20.28–+20.54) | +15.01 (+14.87–+15.05) |

The retained change sets document retention to 30 seconds. It used less PSS
after resumed work in the 64-session workload. Its long-history PSS increase
was close to default, while its higher absolute PSS was already present before
resume. Resume CPU and duration ranges overlap default in both workloads.
These results support keeping the context cache. They do not prove a CPU saving
or immediate memory return. The later, separate trial order limits causal conclusions. An
integration test uses real expiry timers and public APIs to check exact saved
history and outcomes, metadata changes, duplicate receipts, and targeted stops.

### Longer sessions and ten-minute retention

One separate run on Current completed three rounds of 400 tasks across the same
four chats, then hid the transcript for 660 seconds. Its watch remained active;
the other chats had no editor watch. Heap, collection, and stream observers add
work, so this is not another standard repeat.

| Round | Elapsed seconds | Task p95, ms | Sampled cgroup peak, MiB |
| --- | ---: | ---: | ---: |
| 1 | 19.275 | 244.487 | 173.320 |
| 2 | 20.955 | 248.602 | 201.930 |
| 3 | 20.047 | 242.369 | 227.184 |

Cgroup file memory rose from 0.648 to 65.027 MiB across active work. The last
active sample also had 149.371 MiB anonymous and 8.742 MiB kernel memory.
The counters are read separately; the evidence does not assign file cache to
SQLite, tools, or diagnostic files. Of 42.537 sampled active CPU seconds,
the worker used 27.62 (64.93%) and reaped tools 12.26 (28.82%). Editor, driver,
server, and RPC client used 1.09, 0.65, 0.57, and 0.33 seconds respectively.

The 2,464 provider requests carried 1,204.12 MiB of input; the largest was
1,008,076 bytes. The 56 additional text requests were not classified. Median
fixture preparation was 0.774 ms per request. V8 allocated 10,566,135,048 bytes
from preload to before forced collection, including 1,185,849,640 during aligned
natural idle samples: cumulative allocation, not retained memory or task-only work.

Natural idle reduced cgroup memory from 204.699 to 172.598 MiB and worker
`smaps_rollup` RSS from 163.078 to 118.426 MiB. After 30 idle seconds, worker
RSS stayed within 117.992–119.477 MiB and heap within 28.365–29.149 MiB.
The driver grew by 16 MiB because it retained samples. Idle used 0.012710 cores;
driver and editor polling dominated it. Worker CPU was 0.34 seconds in that
659.801-second sampled interval. The editor reported 712 transcript changes
and zero transcript undo blocks. Four resumed tasks completed in 0.199 seconds.

A separate forced collection reduced worker-reported heap from 28.923 to
26.696 MiB. It also loaded the inspector. It neither proves natural savings
nor isolates the ten-minute timer. This run shows stability within the stated
idle ranges and successful resume; it does not prove indefinite stability.

### Worker CPU and tool execution

A V8 profile used the formatting candidate, four chats, 200 tasks in 9.192
seconds, and four resumed tasks. It added a public tool timing wrapper. The
active interval spans the first provider request through the last initial stream,
excluding startup and some task edges. Self samples identify the function
executing at that instant; caller and callee weights are not added together.

| Source | Non-idle self-sample weight, ms | Share |
| --- | ---: | ---: |
| Pi Durable, Pi AI, and Chord | 1,689.08 | 47.90% |
| OpenAI SDK | 590.25 | 16.74% |
| Node runtime | 499.54 | 14.17% |
| Native or unattributed | 252.69 | 7.17% |
| Synthetic provider | 245.28 | 6.96% |
| Garbage collector | 178.38 | 5.06% |
| Application adapter | 47.24 | 1.34% |
| Diagnostic observers | 13.21 | 0.37% |
| Other dependencies | 10.56 | 0.30% |

The largest functions were Pi's SQLite transaction callback (16.77%), OpenAI's
request JSON encoder (12.86%), Node process creation (7.73%), collection (5.06%),
and Pi's SQLite statement callback (3.71%). These are main-thread sample weights,
not CPU seconds; native waits and other runtime threads prevent that conversion.
Aligned process samples recorded 6.259 cgroup CPU seconds, including 4.27 worker
and 1.70 reaped-tool seconds. Tool duration across 204 successful calls was
10.478 ms median and 24.771 ms p95, including startup, output, and cleanup.
Median provider service was 17.040 ms for tool streams and 129.770 ms for text.
Those intervals include pacing and overlap across chats. They do not isolate
pure harness overhead. The adapter is a small sampled share in this workload.

### Reproduced common workload

Three serial runs per harness used one retained session, 50 sequential tasks,
Linux AMD64, two CPU cores, 512 MiB, no swap, and no external network. All used
the same local Anthropic Messages substitute, model name, API-key method, actual
Bash/Python command, 5,633-byte tool output, and 2,048-byte answer. Answers used
64-byte chunks with 3 ms scheduled event delays. Application memory includes
the harness and its tools; the common driver and model substitute are separate.

| Harness | Sampled PSS peak, MiB | Sampled RSS peak, MiB | Estimated CPU, seconds | Time for 50 tasks, seconds |
| --- | ---: | ---: | ---: | ---: |
| Our formatting candidate | 125.45 (124.88–127.76) | 130.85 (130.06–133.13) | 3.260 (1.769–3.284) | 9.13 (7.98–9.14) |
| jcode v0.99.0 | 63.49 (62.13–64.26) | 68.77 (67.45–69.92) | 1.413 (1.405–2.899) | 12.64 (12.63–13.65) |
| peri 3.17.0 | 115.40 (109.03–117.24) | 116.34 (112.91–118.16) | 3.242 (1.588–3.446) | 8.79 (7.55–8.90) |

Our median PSS was 10.05 MiB above peri and 61.96 MiB above jcode. CPU ranges
overlap and do not establish a stable ranking. Median task p95 was 199.61,
260.33, and 197.21 ms respectively. All 450 main tasks completed with complete
tool output and no fixture errors. The fixture emitted the same answer text;
these trials did not independently compare each exported final answer string.
jcode also made four memory-extraction calls per run; peri made 50 next-input
prediction calls. Their prompts permit empty responses when there is no useful
result. The fixture leaves both features enabled but does not measure costs of
nonempty auxiliary results. Request traffic was 19.57, 24.92, and
34.35 MiB respectively. Main streams scheduled 6.45 seconds of waits per run;
auxiliary calls increase this to 6.51 for jcode and 7.20 for peri. Scheduled
waits cannot simply be subtracted from elapsed time.

The test used our Rust server and shared worker, jcode's server control
interface, and peri's ACP interface. Storage and normal tools stayed enabled.
It excludes the editor, multiple active sessions, terminal drawing, OAuth
refresh, recovery, and cancellation comparisons. It is a common execution path,
not proof of complete feature parity. Our image contained both formatting
changes and default Pi retention, before the 30-second policy.

The standard 45,057-byte tool result exceeded competitor output limits in
compatibility probes: jcode returned about 30,116 bytes and peri about 9,610.
The common diagnostic therefore used smaller output for all three. The standard
benchmark did not change. All returned the complete 5,633-byte command output;
serialized tool-result text was 5,633 bytes for our application, 5,770 for jcode,
and 5,677 for peri because their wrappers add text.
Process and cgroup samples were taken every 100 ms.
CPU estimates subtract driver CPU ticks from cgroup CPU, including short tools
without adding child counters twice. Median cgroup CPU was 3.910, 1.833, and
4.072 seconds; no run was throttled. The 32-logical-CPU host had start load
averages of 3.03–4.75, and CPU placement was not fixed.

Median cgroup peaks were 97.52, 44.42, and 128.72 MiB; driver PSS peaks were
21.15, 23.27, and 23.95 MiB. Cgroup peaks below process PSS are consistent with
shared pages charged elsewhere, but individual page ownership was not traced.
Use the stated accounting method, not an interchangeable memory column.
The old sampler ignored per-process read errors, so these cannot be counted
afterward. The saved trials contain all expected main processes at each load
sample, no logged monitor exceptions, and no sample gap above 112 ms.

A later check ran the final document-retention image three times with this same
common workload. All 150 tasks passed with no fixture or monitor error. Median
PSS peak was 127.16 MiB (121.70–128.17), RSS 132.22 (123.96–133.53), estimated
application CPU 1.763 seconds (1.757–1.948), and time for 50 tasks 7.99 seconds
(7.98–8.11). Median task p95 was 170.83 ms (170.02–175.78). These runs were not
interleaved with the saved competitor runs and are not pooled with the table.
This workload finishes before document expiry. Its CPU difference from the
earlier batch cannot be attributed to that setting. The final runner also
checks fixture and binary hashes and rejects resource-sampling failures.

The first nine runs, label `common`, are rejected. Their fixture returned HTTP
500 for auxiliary calls: 12 errors per jcode run and 182–183 per peri run.
Main tasks passed, but retries distorted resource use. Raw failed trials remain
preserved. The corrected `common-v2` matrix accepts only the two observed
auxiliary request types and fails on unknown requests. The table uses only it.

### Published claims and reproduction limits

jcode's README reports 32.9 MB for one headless session and about 6.4 MB per
additional session. Its script samples Linux process-tree PSS one second after
completed turns, not active peaks. Defaults are five real-model turns at
1, 5, 10, and 20 sessions, with different default models for jcode and Pi.
Its Pi comparison starts one RPC process per session with persistence disabled.
The README row has no binary revision or raw-result link. The separate website
claim of 3.5 MB per additional session names v0.92.14. Neither published claim
is reproduced here. See the [README](https://github.com/1jehuang/jcode#benches),
[pinned script](https://github.com/1jehuang/jcode/blob/28d51019f7fdd30bbde69d40c87d59536314bd46/scripts/bench_headless_memory.py),
and [website](https://jcode.sh/).

The published peri 3.17.0 result is 54.7 MB mean and 71.7 MB peak. It uses
100 ms process-tree RSS samples on 18-core Apple Silicon macOS. It selects the
median-elapsed-time run of three, not median memory. Its 100 mocked tool turns
have about 4 KiB response text, no stream delay, and small tool output. The mock
and sampler are outside the measured tree. Its Pi workload has 133 generated turns (135 script entries) to allow extra
compaction requests. These methods differ from our
standard profile and common diagnostic. Both projects label bytes divided by
1024 squared as MB; these displayed units are MiB. See the
[benchmark](https://github.com/KonghaYao/harness-perf-benchmark) and
[pinned method](https://github.com/KonghaYao/harness-perf-benchmark/blob/e89a895a27a6634bded08f93c886b1a70bb15d63/docs/perf-compare.md).

[Common-run sources](benchmarks/trials/common/) pin official release URLs,
revisions, licenses, and archive/binary hashes. `prepare.py` verifies downloads;
`run.py` runs three serial repetitions and refuses to overwrite a label.
Downloaded upstream text remains unchanged in [dev-docs/performance/](dev-docs/performance/);
[catalog.json](dev-docs/catalog.json) records source checksums and licenses.

### Retained changes and remaining costs

Retain the two formatting changes and 30-second document retention through Pi's
public setting. Keep ten-minute context retention. Reject zero retention, the
combined 30-second policy, and the invalid first common matrix. Keep provider
loading as implemented: heavy SDKs are already deferred. No provider, authentication
method, storage path, recovery operation, receipt, cancellation rule, draft
protection, or editor focus behavior is removed to improve the measurements.
Pi remains the single owner of execution state and cache lifetime.

Keeping this architecture keeps Node's runtime, Pi and provider module code,
active model context, SQLite operations, and process creation for real tools.
Serialized requests grow with retained model context; small display previews
do not bound that context. Required metadata and conversation handles also
remain resident for each loaded session. The adapter keeps a metadata view for
listing, routing, and configuration; Pi keeps execution context and stored
documents. The watched session also retains its Pi view. Public snapshots and
provider requests represent different subsets of that data. Removing one of
these representations requires a replacement for its current interface.
The evidence does not divide every byte among Pi, SDKs,
allocator capacity, and the adapter. It does not establish that all repeated
serialization or stored data is unnecessary duplication.

Estimate of further savings, explicitly an inference: additional adapter changes
are likely to give limited whole-application gains in this workload because
the adapter has a small sampled CPU share and a modest startup increment.
Larger gains would require measured changes to repeated Pi/storage/SDK work,
runtime retention, or the amount of necessary context. Those changes need
correctness and provider coverage before adoption. The common test supports
memory use near peri for one session, with a clear gap to jcode. It does not
support a numeric forecast for closing that gap while keeping Pi and all
required features.

### Repeat the diagnostics

Use separate output labels. The runners refuse to overwrite an existing label.
`python3 benchmarks/repeat-trials.py BEFORE=IMAGE AFTER=IMAGE` repeats immutable images
three times with the unchanged standard profile. It checks the embedded profile,
alternates order, and preserves incomplete capacity runs for separate review.
`benchmarks/summarize-trials.py` verifies and summarizes the resulting JSON files.
Candidate manifests identify the changed application files relative to the base
image. These trials do not publish accepted push evidence.

For cache tests, use `python3 benchmarks/worker-trials.py --image IMAGE --kind natural
--label LABEL --policies default documents`. The `long` kind tests resumed
histories; `retained` adds forced collection; `reuse` tests short active work.
Each kind repeats each selected policy three times. The standalone import and
formatting probes describe their arguments in their source headers.

`benchmarks/diagnostic.py` runs inside the constrained image. It uses bounded
task counts, optional CPU and tool observers, and a separate retention phase.
The archived commands record the exact settings of the long-session and CPU
tests. For common comparisons, `benchmarks/trials/common/prepare.py` verifies
the pinned release downloads; `run.py` measures the common workload and
`summarize.py` reports its trials. These comparison binaries are diagnostic
tools, not application dependencies.

Raw records use gzip compression. Decompress them before passing them to a
summary tool; their byte hashes must match the original hashes in the manifest.
Keep tests with forced collection or observers separate from the standard and
common workloads.
