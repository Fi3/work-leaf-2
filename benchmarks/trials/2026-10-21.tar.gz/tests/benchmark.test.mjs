import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, readFile, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import test from 'node:test';

const execute = promisify(execFile);
const root = fileURLToPath(new URL('..', import.meta.url));
const profile = JSON.parse(await readFile(new URL('../benchmarks/profile.json', import.meta.url)));
const runProvider = program => execute(process.execPath,
  ['--import', './benchmarks/provider.mjs', '--input-type=module', '--eval', program],
  { cwd: root, timeout: 15000, env: { ...process.env, OPENAI_API_KEY: 'sk-benchmark-synthetic' } });

test('benchmark provider rejects other endpoints, credentials, models, and response modes', async () => {
  await runProvider(`
    import assert from 'node:assert/strict';
    import { readFile } from 'node:fs/promises';
    const profile = JSON.parse(await readFile('./benchmarks/profile.json'));
    const endpoint = 'https://api.openai.com/v1/responses';
    const headers = { authorization: 'Bearer sk-benchmark-synthetic' };
    const body = { model: profile.model, stream: true, input: [], tools: [] };
    for (const [url, requestHeaders, requestBody] of [
      ['https://example.invalid/', headers, body],
      [endpoint, { authorization: 'Bearer wrong-key' }, body],
      [endpoint, {}, body],
      [endpoint, headers, { ...body, model: 'unexpected-model' }],
      [endpoint, headers, { ...body, stream: false }],
    ]) {
      await assert.rejects(fetch(url, { method: 'POST', headers: requestHeaders, body: JSON.stringify(requestBody) }),
        /Benchmark permits only|Unexpected benchmark model request/);
    }
  `);
});

test('benchmark simulator completes successive real Pi tool runs with fixed-size stored answers', async () => {
  const { stdout } = await runProvider(`
    import assert from 'node:assert/strict';
    import { mkdtemp, mkdir, readFile, rm } from 'node:fs/promises';
    import { tmpdir } from 'node:os';
    import { join } from 'node:path';
    import { openApplication } from './adapter/pi.mjs';
    const profile = JSON.parse(await readFile('./benchmarks/profile.json'));
    const directory = await mkdtemp(join(tmpdir(), 'harness-benchmark-test-'));
    const workspace = join(directory, 'work'), state = join(directory, 'state');
    await mkdir(workspace); await mkdir(state);
    const requests = [], provider = globalThis.fetch;
    globalThis.fetch = (url, options) => { requests.push(JSON.parse(options.body)); return provider(url, options); };
    let app;
    try {
      app = await openApplication({ state_dir: state, provider: profile.provider, model: profile.model });
      let sequence = 0;
      const call = (method, params) => app.dispatch(method, params, 'test-' + ++sequence);
      await call('session.create', { session_id: 'chat', workspace });
      for (const request_id of ['first', 'next']) {
        await call('input.submit', { session_id: 'chat', request_id, text: 'Run the benchmark tool.', context: [] });
        const result = await call('submission.wait', { session_id: 'chat', request_id, timeout_ms: 5000 });
        assert.equal(result.status, 'done');
        const answer = await call('entry.read', { session_id: 'chat', entry_id: result.answer_entry_id });
        assert.equal(Buffer.byteLength(answer.text), profile.simulated_output_bytes);
        assert.ok(answer.text.startsWith('Synthetic benchmark answer. '));
        assert.equal(answer.end, true);
      }
      assert.equal(requests.length, 4, 'Each turn requests one tool and one answer');
      for (const index of [1, 3]) {
        assert.equal(requests[index].input.at(-1).type, 'function_call_output');
        assert.ok(JSON.stringify(requests[index].input.at(-1)).includes('benchmark tool output'));
      }
      const snapshot = (await call('session.get', { session_id: 'chat' })).snapshot;
      assert.equal(snapshot.state, 'idle'); assert.equal(snapshot.error, null);
      assert.equal(snapshot.entries.filter(entry => entry.kind === 'tool').length, 2);
      assert.ok(!JSON.stringify(snapshot).includes('sk-benchmark-synthetic'));
      console.log(JSON.stringify({ requests: requests.length, completed: 2 }));
    } finally { await app?.close(); await rm(directory, { recursive: true, force: true }); }
  `);
  assert.deepEqual(JSON.parse(stdout), { requests: 4, completed: 2 });
});

test('diagnostic observer preserves fixture streams and records separate collection and CPU data', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'harness-diagnostic-test-'));
  try {
    await execute(process.execPath, ['--import', './benchmarks/provider.mjs',
      '--import', './benchmarks/diagnostic-worker.mjs', '--input-type=module', '--eval', `
      import assert from 'node:assert/strict';
      import { readFile, rename, writeFile } from 'node:fs/promises';
      import { setTimeout as delay } from 'node:timers/promises';
      const directory = process.env.HARNESS_DIAGNOSTIC_DIRECTORY;
      const profile = JSON.parse(await readFile('./benchmarks/profile.json'));
      const request = tools => fetch('https://api.openai.com/v1/responses', {
        method: 'POST', headers: { authorization: 'Bearer sk-benchmark-synthetic' },
        body: JSON.stringify({ model: profile.model, stream: true, input: [], tools }),
      });
      const answer = await request([]);
      assert.equal(answer.status, 200);
      assert.equal(answer.headers.get('content-type'), 'text/event-stream');
      const text = await answer.text();
      assert.ok(text.includes('response.completed'));
      assert.ok(text.includes('Synthetic benchmark answer.'));
      const tool = await request([{ name: 'bash' }]);
      assert.ok((await tool.text()).includes('benchmark tool output'));
      const cancelled = await request([]);
      await cancelled.body.cancel();
      const { NodeExecutionEnv } = await import('@earendil-works/pi-durable/env/node');
      const { BACKGROUND_CONTEXT: context } = await import('@earendil-works/chord/context');
      const environment = new NodeExecutionEnv({ cwd: directory, shellEnv: { HARNESS_DIAGNOSTIC_TEST: 'diagnostic-tool-output' } });
      let output = '';
      const result = await environment.exec('printf "$HARNESS_DIAGNOSTIC_TEST"; exit 7', {
        onOutput(text, callbackContext) { assert.equal(callbackContext, context); output += text; },
      }, context);
      assert.deepEqual(result, { ok: true, value: { exitCode: 7 } });
      assert.equal(output, 'diagnostic-tool-output');
      const failed = await environment.exec([], undefined, context);
      assert.equal(failed.ok, false);
      assert.equal(failed.error.code, 'spawn_error');
      const error = Error('private-diagnostic-error');
      await assert.rejects(environment.exec('true', undefined, { get abortSignal() { throw error; } }), value => value === error);
      await environment.cleanup(context);
      for (const [sequence, operation] of [[1, 'collect_garbage'], [2, 'finish']]) {
        await writeFile(directory + '/diagnostic-control.tmp', JSON.stringify({ sequence, operation }));
        await rename(directory + '/diagnostic-control.tmp', directory + '/diagnostic-control.json');
        let acknowledged = false;
        for (let index = 0; index < 120 && !acknowledged; index++) {
          await delay(50);
          try { acknowledged = JSON.parse(await readFile(directory + '/diagnostic-ack.json')).sequence === sequence; } catch {}
        }
        assert.ok(acknowledged, operation + ' must finish');
      }
    `], { cwd: root, timeout: 15000, env: { ...process.env,
      HARNESS_DIAGNOSTIC_DIRECTORY: directory, HARNESS_DIAGNOSTIC_CPU_PROFILE: '1', HARNESS_DIAGNOSTIC_TOOL_TIMING: '1' } });
    const records = (await readFile(join(directory, 'worker-metrics.jsonl'), 'utf8')).trim().split('\n').map(JSON.parse);
    const requests = records.filter(record => record.type === 'provider_request');
    assert.deepEqual(requests.map(request => request.status), ['complete', 'complete', 'cancelled']);
    assert.deepEqual(requests.slice(0, 2).map(request => request.chunks), [36, 5]);
    const executions = records.filter(record => record.type === 'tool_execution');
    assert.deepEqual(executions.map(record => record.status), ['complete', 'error', 'rejected']);
    assert.equal(executions[0].exit_code, 7);
    assert.equal(executions[1].error_code, 'spawn_error');
    assert.ok(executions.every(record => record.duration_ms >= 0 && record.monotonic_seconds >= record.started_monotonic_seconds));
    assert.ok(!JSON.stringify(executions).includes('diagnostic-tool-output'));
    assert.ok(!JSON.stringify(executions).includes('private-diagnostic-error'));
    for (const request of requests.slice(0, 2)) {
      assert.ok(request.request_bytes > 0 && request.response_bytes > 0);
      assert.ok(request.service_ms >= request.last_chunk_ms && request.last_chunk_ms >= request.first_chunk_ms);
    }
    for (const reason of ['preload', 'before_forced_gc', 'after_forced_gc', 'exit']) {
      const sample = records.find(record => record.type === 'worker_sample' && record.reason === reason);
      assert.ok(sample?.memory.heapUsed > 0 && sample.memory.rss > 0, reason);
    }
    const profile = JSON.parse(await readFile(join(directory, 'worker.cpuprofile'), 'utf8'));
    assert.ok(profile.nodes.length > 0 && profile.endTime > profile.startTime);
    assert.equal(records.some(record => record.type === 'diagnostic_error'), false);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('diagnostic observer preserves tool outcomes when metrics storage fails', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'harness-diagnostic-full-'));
  try {
    await symlink('/dev/full', join(directory, 'worker-metrics.jsonl'));
    let failure;
    try {
      await execute(process.execPath, ['--import', './benchmarks/diagnostic-worker.mjs', '--input-type=module', '--eval', `
        import assert from 'node:assert/strict';
        import { readFile, writeFile } from 'node:fs/promises';
        import { setTimeout as delay } from 'node:timers/promises';
        import { NodeExecutionEnv } from '@earendil-works/pi-durable/env/node';
        import { BACKGROUND_CONTEXT as context } from '@earendil-works/chord/context';
        const directory = process.env.HARNESS_DIAGNOSTIC_DIRECTORY;
        const environment = new NodeExecutionEnv({ cwd: directory });
        assert.deepEqual(await environment.exec('exit 7', undefined, context), { ok: true, value: { exitCode: 7 } });
        const error = Error('original tool failure');
        await assert.rejects(environment.exec('true', undefined, { get abortSignal() { throw error; } }), value => value === error);
        await environment.cleanup(context);
        await writeFile(directory + '/diagnostic-control.json', JSON.stringify({ sequence: 1, operation: 'finish' }));
        let acknowledgment;
        for (let index = 0; index < 80 && !acknowledgment; index++) {
          await delay(50);
          try { acknowledgment = JSON.parse(await readFile(directory + '/diagnostic-ack.json')); } catch {}
        }
        assert.equal(acknowledgment?.sequence, 1);
        assert.equal(acknowledgment.error, 'Worker metrics write failed (ENOSPC)');
        console.log('Tool outcomes preserved; observer failure acknowledged.');
      `], { cwd: root, timeout: 10000, env: { ...process.env,
        HARNESS_DIAGNOSTIC_DIRECTORY: directory, HARNESS_DIAGNOSTIC_TOOL_TIMING: '1' } });
    } catch (error) { failure = error; }
    assert.equal(failure?.code, 1);
    assert.match(failure.stdout, /Tool outcomes preserved; observer failure acknowledged\./, failure.stderr);
    assert.match(failure.stderr, /Worker metrics write failed \(ENOSPC\)/);
  } finally { await rm(directory, { recursive: true, force: true }); }
});

test('diagnostic runners reject invalid evidence and clean resources on failure', async () => {
  await execute('python3', ['tests/benchmark_diagnostics.py'], { cwd: root, timeout: 15000 });
});

test('trial summaries preserve failed-capacity normal data and reject mixed profiles or images', async () => {
  const { stdout } = await execute('python3', ['-c', `
import copy, hashlib, importlib.util, json, pathlib, tempfile
spec = importlib.util.spec_from_file_location('summary', 'benchmarks/summarize-trials.py')
summary = importlib.util.module_from_spec(spec); spec.loader.exec_module(summary)
profile = json.loads(pathlib.Path('benchmarks/profile.json').read_text())
profile['concurrent_sessions'] = [1]
runner = summary.load_runner()
samples = []
for index, phase in enumerate(('idle', 'load-1', 'hidden-editor', 'capacity')):
    for offset in (0, 1):
        value = index * 2 + offset
        events = 1 if value == 7 else 0
        samples.append({'phase': phase, 'elapsed_seconds': value, 'cpu_usec': value * 100000,
            'memory_bytes': 1048576, 'memory_events': {'oom': events, 'oom_kill': events}})
base = {'completed': True, 'error': None, 'trial_label': 'test-1', 'profile': profile,
    'docker_limits': profile['resources'], 'docker_image_id': 'sha256:example',
    'measurements': samples, 'resources_by_phase': runner.resource_summary(samples),
    'stages': [{'phase': phase, 'completed_tasks': 10, 'p50_ms': 10, 'p95_ms': 20, 'p99_ms': 30}
        for phase in ('load-1', 'hidden-editor')], 'capacity_completed_sessions': 100,
    'exhaustion': {'observed': True, 'reason': 'memory_limit', 'phase': 'capacity', 'oom_delta': 1, 'oom_kill_delta': 1}}
with tempfile.TemporaryDirectory(prefix='harness-trial-summary-') as directory:
    first, second = [pathlib.Path(directory, name) for name in ('first.json', 'second.json')]
    first.write_text(json.dumps(base))
    failed = copy.deepcopy(base)
    failed.update(trial_label='test-2', completed=False, error='Capacity evidence absent')
    failed['stages'][0]['completed_tasks'] = 14
    failed['exhaustion']['observed'] = False
    second.write_text(json.dumps(failed))
    result = summary.summarize([first, second])['groups']['test']
    assert result['normal_phases']['load-1']['completed_tasks'] == {
        'count': 2, 'median': 12.0, 'minimum': 10, 'maximum': 14, 'range': 4}
    assert result['capacity_excluded_trials'] == ['test-2']
    assert result['verified_capacity_completed_sessions']['count'] == 1
    assert result['trials'][1]['sha256'] == hashlib.sha256(second.read_bytes()).hexdigest()
    for field in ('profile', 'docker_image_id'):
        changed = copy.deepcopy(failed)
        if field == 'profile': changed['profile']['load_seconds'] += 1
        else: changed[field] = 'sha256:different'
        second.write_text(json.dumps(changed))
        try: summary.summarize([first, second])
        except ValueError: pass
        else: raise AssertionError('Mixed ' + field + ' must fail')
    print(json.dumps({'normal_runs': 2, 'verified_capacity_runs': 1}))
  `], { cwd: root, timeout: 5000 });
  assert.deepEqual(JSON.parse(stdout), { normal_runs: 2, verified_capacity_runs: 1 });
});

async function containerResult(settings) {
  const program = `
import contextlib, importlib.util, io, json, pathlib, subprocess, sys, tempfile
from unittest.mock import patch
spec = importlib.util.spec_from_file_location('bench', 'scripts/bench.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
settings = json.loads(sys.argv[1])
profile = json.loads(pathlib.Path('benchmarks/profile.json').read_text())
profile.update(settings.get('profile', {}))
resources = profile['resources']
configuration = {'Image': 'sha256:' + 'a' * 64, 'HostConfig': {
    'NanoCpus': resources['cpus'] * 1000000000, 'Memory': resources['memory_bytes'],
    'MemorySwap': resources['memory_swap_bytes'], 'PidsLimit': resources['pids_limit'], 'NetworkMode': 'none'}}
configuration['HostConfig'].update(settings.get('configuration', {}))
final = {'State': {'OOMKilled': settings.get('oom', False), 'ExitCode': settings.get('exit_code', 137 if settings.get('oom') else 0)}}
commands = []
def docker(*arguments):
    commands.append(arguments)
    return 'synthetic-container'
class Process:
    def __init__(self, *arguments, **options):
        self.stdout = io.StringIO(''.join(json.dumps(record) + '\\n' for record in settings['records']))
        self.calls = 0
    def wait(self, timeout):
        self.calls += 1
        if settings.get('timeout') and self.calls == 1:
            raise subprocess.TimeoutExpired('docker start', timeout)
        return 0
with tempfile.TemporaryDirectory(prefix='harness-benchmark-runner-') as directory:
    with patch.object(bench, 'docker', docker), patch.object(bench, 'inspect_container', side_effect=[configuration, final]), patch.object(bench.subprocess, 'Popen', Process), contextlib.redirect_stdout(io.StringIO()):
        try:
            result = bench.run_container('synthetic-image', profile, pathlib.Path(directory), 'source')
        except RuntimeError as error:
            result = {'error': str(error)}
    assert commands[-1] == ('rm', '--force', 'synthetic-container')
    assert any(command[0] == 'kill' for command in commands) == settings.get('timeout', False)
    print(json.dumps(result))
`;
  const { stdout } = await execute('python3', ['-c', program, JSON.stringify(settings)], { cwd: root, timeout: 5000 });
  return JSON.parse(stdout);
}

const phases = [...profile.concurrent_sessions.map(count => `load-${count}`), 'hidden-editor'];
const stages = phases.map(phase => ({ type: 'stage_result', phase, completed_tasks: 1, p50_ms: 5, p95_ms: 8, p99_ms: 10 }));
const samples = [
  { type: 'sample', phase: 'idle', elapsed_seconds: 1, cpu_usec: 100, memory_bytes: 1024, memory_events: { oom: 5, oom_kill: 3 } },
  { type: 'sample', phase: 'capacity', elapsed_seconds: 2, cpu_usec: 200, memory_bytes: 2048, memory_events: { oom: 8, oom_kill: 5 } },
];

test('benchmark resource summaries measure CPU and memory within each sampled phase', async () => {
  const measurements = [
    { phase: 'startup', elapsed_seconds: 0, cpu_usec: 100, memory_bytes: 256 },
    { phase: 'idle', elapsed_seconds: 10, cpu_usec: 1000000, cpu_throttled_usec: 200000, memory_bytes: 1024, memory_peak_bytes: 8192 },
    { phase: 'idle', elapsed_seconds: 11, cpu_usec: 2000000, cpu_throttled_usec: 300000, memory_bytes: 2048, memory_peak_bytes: 8192 },
    { phase: 'idle', elapsed_seconds: 12.5, cpu_usec: 5500000, cpu_throttled_usec: 700000, memory_bytes: 1536, memory_peak_bytes: 8192 },
    { phase: 'load-1', elapsed_seconds: 20, cpu_usec: 6000000, cpu_throttled_usec: 700000, memory_bytes: 4096 },
    { phase: 'load-1', elapsed_seconds: 22, cpu_usec: 8000000, cpu_throttled_usec: 900000, memory_bytes: 8192 },
    { phase: 'capacity', elapsed_seconds: 23, cpu_usec: 8000000, memory_bytes: 4096 },
    { phase: 'capacity', elapsed_seconds: 23, cpu_usec: 8000000, memory_bytes: 4096 },
  ];
  const result = await containerResult({ records: [{ type: 'result', completed: true, measurements }] });
  assert.deepEqual(result.resources_by_phase, {
    idle: { sampled_seconds: 2.5, mean_cpu_cores: 1.8, cpu_throttled_seconds: 0.5, peak_sampled_memory_bytes: 2048 },
    'load-1': { sampled_seconds: 2, mean_cpu_cores: 1, cpu_throttled_seconds: 0.2, peak_sampled_memory_bytes: 8192 },
  });
  assert.deepEqual(result.measurements, measurements, 'Raw cgroup peaks remain available');
  const empty = await containerResult({ records: [{ type: 'result', completed: false, measurements: [] }] });
  assert.deepEqual(empty.resources_by_phase, {});
});

test('benchmark host accepts an observed capacity OOM after every load stage', async () => {
  const result = await containerResult({ oom: true, records: [
    ...stages, { type: 'phase', name: 'capacity' }, ...samples,
    { type: 'capacity', completed_sessions: 4 }, { type: 'capacity', completed_sessions: 8 },
  ] });
  assert.equal(result.completed, true);
  assert.equal(result.exhaustion.observed, true);
  assert.equal(result.exhaustion.oom_delta, 3);
  assert.equal(result.exhaustion.oom_kill_delta, 2);
  assert.deepEqual(result.docker_limits, profile.resources);
  assert.deepEqual(result.measurements, samples);
  assert.deepEqual(result.stages, stages);
  assert.equal(result.capacity_completed_sessions, 8);
  const changed = await containerResult({ oom: true, profile: { concurrent_sessions: [2, 4] }, records: [
    ...stages.slice(1), { type: 'phase', name: 'capacity' }, ...samples,
  ] });
  assert.equal(changed.completed, true, 'Required stages follow the selected profile');
});

test('benchmark host rejects early OOM, incomplete stages, and an exit without OOM', async () => {
  for (const [oom, completedStages, phase] of [
    [true, stages, 'load-4'], [true, stages.slice(1), 'capacity'], [false, stages, 'capacity'],
    [true, [stages[0], ...stages.slice(0, -1)], 'capacity'],
    [true, [...stages].reverse(), 'capacity'],
    [true, [...stages.slice(0, -1), { ...stages.at(-1), completed_tasks: 0 }], 'capacity'],
    [true, [...stages.slice(0, -1), { ...stages.at(-1), completed_tasks: true }], 'capacity'],
  ]) {
    const result = await containerResult({ oom, records: [
      ...completedStages, { type: 'phase', name: phase }, ...samples,
    ] });
    assert.equal(result.completed, false);
    assert.equal(result.exhaustion.observed, false);
  }
});

test('a Docker OOM report without sampled local memory exhaustion is incomplete', async () => {
  for (const observed of [
    [], [samples[1]],
    samples.map(({ memory_events, ...sample }) => sample),
    [samples[0], { ...samples[1], memory_events: { oom: 5, oom_kill: 3 } }],
    [samples[0], { ...samples[1], memory_events: { oom: 5, oom_kill: 5 } }],
    [samples[0], { ...samples[1], memory_events: { oom: 8, oom_kill: 3 } }],
    [samples[0], { ...samples[1], memory_events: { oom: true, oom_kill: 5 } }],
    [samples[0], { ...samples[1], memory_events: { oom: 4, oom_kill: 2 } }],
    [samples[0], { ...samples[1], phase: 'load-4' }, samples[1]],
  ]) {
    const result = await containerResult({ oom: true, records: [
      ...stages, { type: 'phase', name: 'capacity' }, ...observed,
    ] });
    assert.equal(result.completed, false);
    assert.equal(result.exhaustion.observed, false);
  }
});

test('reported benchmark success requires a successful Docker exit', async () => {
  const reported = { type: 'result', completed: true, stages, measurements: samples,
    capacity_completed_sessions: 8,
    exhaustion: { observed: true, reason: 'memory_limit', phase: 'capacity', oom_delta: 3, oom_kill_delta: 2 } };
  for (const exit_code of [0, 1, 137]) {
    const result = await containerResult({ exit_code, records: [reported] });
    assert.equal(result.completed, exit_code === 0);
    assert.deepEqual(result.measurements, samples);
    assert.equal(result.capacity_completed_sessions, 8);
    if (exit_code !== 0) assert.match(result.error, /Docker exited with status/);
  }
});

test('benchmark timeout cannot pass through a workload result or an OOM report', async () => {
  for (const records of [
    [...stages, { type: 'phase', name: 'capacity' }, ...samples],
    [{ type: 'result', completed: true, exhaustion: { observed: true } }],
  ]) {
    const result = await containerResult({ timeout: true, oom: true, records });
    assert.equal(result.completed, false);
    assert.match(result.error, /timed out/);
  }
});

test('benchmark host rejects unapplied resource and network limits', async () => {
  for (const configuration of [{ Memory: 1024 }, { NetworkMode: 'bridge' }]) {
    const result = await containerResult({ records: [], configuration });
    assert.match(result.error, /required resource and network limits/);
  }
});
