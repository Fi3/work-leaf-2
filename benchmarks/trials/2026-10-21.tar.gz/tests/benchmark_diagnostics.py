"""Check diagnostic failure boundaries without starting application workloads."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests/fixtures'))
sys.path.insert(0, str(ROOT / 'benchmarks'))


def load_module(path):
    spec = importlib.util.spec_from_file_location(Path(path).stem, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='harness-diagnostic-check-')
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)

    def test_worker_inputs_and_interrupt_cleanup(self):
        module = load_module('benchmarks/worker-trials.py')
        source = self.directory / 'benchmarks'
        source.mkdir()
        for name in ('import-probe.mjs', 'provider.mjs', 'profile.json'):
            (source / name).write_bytes((ROOT / 'benchmarks' / name).read_bytes())
        args = argparse.Namespace(output=self.directory / 'output', label='worker', repeats=1,
            image='image', kind='reuse', policies=['default'])
        launched, removed = [], []

        def docker(command, **options):
            if command[:2] == ['docker', 'run']:
                launched.append(command[command.index('--name') + 1])
                raise KeyboardInterrupt()
            self.assertEqual(command[:3], ['docker', 'rm', '--force'])
            removed.append(command[3])
            return argparse.Namespace(returncode=0)

        with patch.object(module, 'ROOT', self.directory), patch.object(module.subprocess, 'check_output', return_value='sha256:test'), \
                patch.object(module.subprocess, 'run', side_effect=docker), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(set(module.fixture_hashes()), {'import-probe.mjs', 'provider.mjs', 'profile.json'})
            with self.assertRaises(KeyboardInterrupt):
                module.run(args)
        self.assertEqual(removed, launched)
        self.assertEqual(len(removed), 1)

    def test_worker_rejects_fixture_changes_during_measurement(self):
        module = load_module('benchmarks/worker-trials.py')
        source = self.directory / 'benchmarks'
        source.mkdir()
        for name in ('import-probe.mjs', 'provider.mjs', 'profile.json'):
            (source / name).write_bytes((ROOT / 'benchmarks' / name).read_bytes())
        args = argparse.Namespace(output=self.directory / 'output', label='worker', repeats=1,
            image='image', kind='reuse', policies=['default'])

        def docker(command, **options):
            if command[:2] == ['docker', 'run']:
                (source / 'provider.mjs').write_text('changed fixture')
            return argparse.Namespace(returncode=0)

        with patch.object(module, 'ROOT', self.directory), patch.object(module.subprocess, 'check_output', return_value='sha256:test'), \
                patch.object(module.subprocess, 'run', side_effect=docker), contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError, 'changed during measurement'):
                module.run(args)
        self.assertFalse((args.output / 'worker-runs.json').exists())

    def test_comparison_checks_binaries_counts_and_interrupt_cleanup(self):
        module = load_module('benchmarks/trials/common/run.py')
        runtime = self.directory / 'runtime'
        runtime.mkdir()
        binary = runtime / 'peri'
        binary.write_bytes(b'pinned binary')
        release = {'name': 'peri', 'binaries': [{'path': 'peri', 'bytes': binary.stat().st_size,
            'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}]}
        for name in ('common.py', 'redirect.mjs'):
            (self.directory / name).write_text('fixture')
        (self.directory / 'releases.json').write_text(json.dumps({'releases': [release]}))
        args = argparse.Namespace(output=self.directory / 'output', runtime=runtime, image='image',
            label='comparison', rounds=1, tasks=1, only='peri')
        launched, removed = [], []

        def docker(command, **options):
            if command[:2] == ['docker', 'run']:
                launched.append(command[command.index('--name') + 1])
                raise KeyboardInterrupt()
            self.assertEqual(command[:3], ['docker', 'rm', '--force'])
            removed.append(command[3])
            return argparse.Namespace(returncode=0)

        with patch.object(module, 'HERE', self.directory), patch.object(module.subprocess, 'check_output', return_value=b'[{"Id":"sha256:test"}]'), \
                patch.object(module.subprocess, 'run', side_effect=docker) as run, contextlib.redirect_stdout(io.StringIO()):
            args.tasks = 0
            with self.assertRaisesRegex(ValueError, 'positive'):
                module.run(args)
            args.tasks = 1
            binary.write_bytes(b'other binary')
            with self.assertRaisesRegex(ValueError, 'pinned release'):
                module.run(args)
            run.assert_not_called()
            binary.write_bytes(b'pinned binary')
            with self.assertRaises(KeyboardInterrupt):
                module.run(args)
        self.assertEqual(removed, launched)
        self.assertEqual(len(removed), 1)

    def test_diagnostic_sample_failure_invalidates_result_and_cleans_children(self):
        module = load_module('benchmarks/diagnostic.py')
        profile = json.loads((ROOT / 'benchmarks/profile.json').read_text())
        with patch.object(module.workload, 'counters', return_value={}):
            monitor = module.Monitor(profile)
        monitor.thread = Mock()
        monitor.record_sample = Mock(side_effect=OSError('sample unavailable'))
        with self.assertRaises(OSError):
            monitor.sample()
        self.assertIn('sample unavailable', monitor.error)
        child = Mock()
        child.poll.return_value = None

        def run(args, profile, monitor, children):
            children.append(child)
            return [], {}

        with patch.object(module.workload, 'ROOT', ROOT), patch.object(module.workload, 'WORK', self.directory), \
                patch.object(module.workload, 'verify_limits'), patch.object(module.workload, 'emit') as emit, \
                patch.object(module, 'Monitor', return_value=monitor), patch.object(module, 'run', side_effect=run), \
                patch.object(sys, 'argv', ['diagnostic.py']):
            self.assertEqual(module.main(), 1)
        child.terminate.assert_called_once()
        child.wait.assert_called_once()
        self.assertFalse(emit.call_args.kwargs['completed'])
        self.assertIn('sample unavailable', emit.call_args.kwargs['error'])
        (self.directory / 'diagnostic-ack.json').write_text(json.dumps({'sequence': 1, 'error': 'observer unavailable'}))
        with patch.object(module.workload, 'WORK', self.directory):
            with self.assertRaisesRegex(RuntimeError, 'observer unavailable'):
                module.worker_command(1, 'finish')

    def test_common_sample_failure_invalidates_result_and_cleans_resources(self):
        module = load_module('benchmarks/trials/common/common.py')
        with patch.object(module, 'sample', side_effect=OSError('background sample unavailable')):
            module.monitor()
        self.assertEqual(len(module.monitor_errors), 1)
        child = Mock()
        child.poll.return_value = None
        server = Mock()
        output = self.directory / 'result.json'
        for name in ('cpu.max', 'memory.max', 'memory.swap.max', 'pids.max', 'harness.stderr'):
            (self.directory / name).write_text('0')

        def launch(which, port, children):
            children.append(child)
            module.records.extend([{'tool': 'bash'}, {'result_bytes': 1, 'result_contains_output': True}])
            return lambda index: None

        with patch.object(module, 'WORK', self.directory), patch.object(module, 'CGROUP', self.directory), \
                patch.object(module, 'launch', side_effect=launch), patch.object(module.http.server, 'ThreadingHTTPServer', return_value=server), \
                patch.object(module.threading, 'Thread'), patch.object(module.time, 'sleep'), \
                patch.object(module, 'sample', side_effect=[None, None, None, None, OSError('final sample unavailable')]), \
                patch.object(sys, 'argv', ['common.py', 'peri', '--tasks', '1', '--output', str(output)]), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(module.main(), 1)
        child.terminate.assert_called_once()
        child.wait.assert_called_once()
        server.shutdown.assert_called_once()
        server.server_close.assert_called_once()
        result = json.loads(output.read_text())
        self.assertEqual(result['tasks_completed'], 1)
        self.assertIn('Resource sampling failed', result['failure'])
        self.assertEqual(len(result['monitor_errors']), 2)


if __name__ == '__main__':
    unittest.main()
