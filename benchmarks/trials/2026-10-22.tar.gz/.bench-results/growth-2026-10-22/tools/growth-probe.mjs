// Worker-only diagnostic. Reuses the archived import-probe workload and provider.
// node growth-probe.mjs ROOT OPTIONS_JSON
// Default: large fixed histories at 1,4,16,64 sessions. profile: "small" uses
// 56-byte input and no extra instructions. history_steps with counts:[4] grows
// four small histories instead. idle_seconds are absolute from task completion.
import { mkdtemp, rm, mkdir } from 'node:fs/promises';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import { getHeapStatistics, getHeapSpaceStatistics } from 'node:v8';

const root = resolve(process.argv[2] ?? process.cwd());
const supplied = JSON.parse(process.argv[3] ?? '{}');
const options = { profile: 'large', counts: [1, 4, 16, 64], rounds: 2,
  idle_seconds: [2, 35], settle_seconds: 2, expected_cpus: '30,31',
  contextRetentionMs: 600000, documentRetentionMs: 600000, ...supplied };
if (!['large', 'small'].includes(options.profile)) throw Error('Unknown profile');
options.input_bytes ??= options.profile === 'large' ? 65536 : 56;
options.instructions_bytes ??= options.profile === 'large' ? 262144 : 0;
function increasing(values, minimum = 1) {
  return Array.isArray(values) && values.length > 0 && values.every((value, index) =>
    Number.isInteger(value) && value >= minimum && (index === 0 || value > values[index - 1]));
}
if (!increasing(options.counts) || options.counts.at(-1) > 64
  || !increasing(options.idle_seconds, 0) || !Number.isInteger(options.rounds) || options.rounds < 1
  || !Number.isFinite(options.settle_seconds) || options.settle_seconds < 0
  || !Number.isInteger(options.input_bytes) || options.input_bytes < 32
  || !Number.isInteger(options.instructions_bytes) || options.instructions_bytes < 0
  || !Number.isInteger(options.contextRetentionMs) || options.contextRetentionMs < 0
  || !Number.isInteger(options.documentRetentionMs) || options.documentRetentionMs < 0
  || (options.history_steps !== undefined && (!increasing(options.history_steps) || options.counts.length !== 1))) {
  throw Error('Invalid diagnostic options');
}
const rows = [], started = performance.now(), cgroup = '/sys/fs/cgroup';
const requests = { count: 0, body_bytes: 0, maximum_body_bytes: 0 };
let app, directory, callId = 0, notifications = 0, completedTasks = 0, watchId;
const read = path => readFileSync(path, 'utf8').trim();
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
function counters(path) {
  return Object.fromEntries(read(path).split('\n').filter(Boolean).map(line => {
    const [key, value] = line.split(/\s+/); return [key, Number(value)];
  }));
}
function cpus(value) {
  return value.split(',').flatMap(part => {
    const [first, last = first] = part.split('-').map(Number);
    if (!Number.isInteger(first) || !Number.isInteger(last) || last < first) throw Error('Invalid CPU list');
    return Array.from({ length: last - first + 1 }, (_, index) => first + index);
  }).sort((a, b) => a - b).join(',');
}
const cpuMax = read(join(cgroup, 'cpu.max')).split(/\s+/).map(Number);
const limits = { cpu_max: cpuMax, memory_max: Number(read(join(cgroup, 'memory.max'))),
  swap_max: Number(read(join(cgroup, 'memory.swap.max'))), cpuset: read(join(cgroup, 'cpuset.cpus.effective')),
  process_allowed_cpus: read('/proc/self/status').match(/^Cpus_allowed_list:\s*(.*)$/m)?.[1],
  network_interfaces: readdirSync('/sys/class/net').sort() };
if (cpuMax[0] / cpuMax[1] !== 2 || limits.memory_max !== 536870912 || limits.swap_max !== 0
  || cpus(limits.cpuset) !== cpus(options.expected_cpus)
  || cpus(limits.process_allowed_cpus) !== cpus(options.expected_cpus)
  || limits.network_interfaces.join(',') !== 'lo') throw Error('Diagnostic resource limits do not match');

function sources() {
  const paths = ['benchmarks/provider.mjs', 'benchmarks/profile.json', 'package-lock.json',
    ...readdirSync(join(root, 'adapter')).filter(name => name.endsWith('.mjs')).map(name => `adapter/${name}`)];
  return { files: Object.fromEntries(paths.sort().map(path => [path, sha256(readFileSync(join(root, path)))])),
    probe_sha256: sha256(readFileSync(fileURLToPath(import.meta.url))) };
}
const sourceHashes = sources();
function storageFiles() {
  if (!directory) return [];
  return readdirSync(directory).filter(name => name.startsWith('agent.sqlite')).sort()
    .map(name => ({ name, bytes: statSync(join(directory, name)).size }));
}
function sample() {
  const smaps = {};
  for (const line of read('/proc/self/smaps_rollup').split('\n')) {
    const match = line.match(/^([A-Za-z_]+):\s+(\d+)\s+kB$/);
    if (match) smaps[match[1]] = Number(match[2]) * 1024;
  }
  return { memory: process.memoryUsage(), smaps_bytes: smaps,
    heap: getHeapStatistics(), heap_spaces: getHeapSpaceStatistics(),
    cgroup: { memory_bytes: Number(read(join(cgroup, 'memory.current'))),
      memory_peak_bytes: Number(read(join(cgroup, 'memory.peak'))),
      memory_stat: counters(join(cgroup, 'memory.stat')), memory_events: counters(join(cgroup, 'memory.events')),
      cpu: counters(join(cgroup, 'cpu.stat')) },
    pi_document_cache: app?.harness.documentCacheSizes ?? null,
    adapter_counts: app ? { sessions: app.sessions.size, environments: app.environments.size,
      watches: app.watches.size } : null, storage_files: storageFiles() };
}
async function checkpoint(name, operation = async () => {}, extra = {}, settle = 0) {
  const cpu = process.cpuUsage(), begin = performance.now(), requestBefore = { ...requests };
  const tasksBefore = completedTasks;
  await operation();
  const finished = performance.now(), workWall = finished - begin, workCpu = process.cpuUsage(cpu);
  if (settle) await delay(settle * 1000);
  const beforeGc = sample();
  if (globalThis.gc) { globalThis.gc(); await delay(20); globalThis.gc(); }
  const row = { name, ...extra, elapsed_seconds: (performance.now() - started) / 1000,
    operation_finished_elapsed_seconds: (finished - started) / 1000,
    operation_wall_ms: workWall, operation_cpu_us: workCpu, settle_seconds: settle,
    completed_tasks: completedTasks, tasks_in_operation: completedTasks - tasksBefore,
    requests: { ...requests }, requests_in_operation: requests.count - requestBefore.count,
    request_bytes_in_operation: requests.body_bytes - requestBefore.body_bytes,
    notifications, before_gc: beforeGc, after_gc: globalThis.gc ? sample() : null };
  rows.push(row);
  process.stderr.write(`${JSON.stringify({ checkpoint: name, elapsed_seconds: row.elapsed_seconds,
    tasks: completedTasks, worker_pss_bytes: beforeGc.smaps_bytes.Pss })}\n`);
  return row;
}
function call(method, params) {
  return app.dispatch(method, params, String(++callId), () => { notifications++; });
}
async function createSessions(first, count) {
  for (let index = first; index < count; index++) {
    const session_id = `probe_${index}`;
    await call('session.create', { session_id, workspace: join(directory, 'project') });
    if (options.instructions_bytes) await call('session.configure', { session_id,
      instructions: `${session_id} ${'x'.repeat(options.instructions_bytes)}`.slice(0, options.instructions_bytes) });
  }
  if (watchId === undefined) {
    const watch = await call('session.watch', { session_id: 'probe_0' });
    watchId = watch.result.watch_id; watch.start();
  }
}
async function tasks(first, count, startRound, endRound) {
  for (let round = startRound; round < endRound; round++) {
    for (let offset = first; offset < count; offset += 4) {
      await Promise.all(Array.from({ length: Math.min(4, count - offset) }, async (_, index) => {
        const session_id = `probe_${offset + index}`, request_id = `task_${round}`;
        await call('input.submit', { session_id, request_id,
          text: `${session_id} ${request_id} ${'t'.repeat(options.input_bytes)}`.slice(0, options.input_bytes), context: [] });
        const result = await call('submission.wait', { session_id, request_id, timeout_ms: 30000 });
        if (result.status !== 'done') throw Error('Diagnostic task did not complete');
        completedTasks++;
      }));
    }
  }
}
async function loadApplication() {
  globalThis.fetch = async () => { throw Error('Diagnostic network access is disabled'); };
  const { openApplication } = await import(pathToFileURL(join(root, 'adapter/pi.mjs')));
  const { Harness } = await import('@earendil-works/pi-durable');
  await import(pathToFileURL(join(root, 'benchmarks/provider.mjs')));
  const provider = globalThis.fetch;
  globalThis.fetch = (input, init = {}) => {
    const bytes = Buffer.byteLength(init.body ?? '');
    requests.count++; requests.body_bytes += bytes;
    requests.maximum_body_bytes = Math.max(requests.maximum_body_bytes, bytes);
    return provider(input, init);
  };
  directory = await mkdtemp(join(tmpdir(), 'harness-growth-'));
  await mkdir(join(directory, 'project'));
  process.env.OPENAI_API_KEY = 'sk-benchmark-synthetic';
  const open = Harness.open;
  Harness.open = (storage, config, ...args) => open(storage, { ...config,
    settings: { ...config.settings, contextRetentionMs: options.contextRetentionMs,
      documentRetentionMs: options.documentRetentionMs } }, ...args);
  try { app = await openApplication({ state_dir: directory, provider: 'openai', model: 'gpt-5.6-luna', instructions: '' }); }
  finally { Harness.open = open; }
}

let error;
try {
  await checkpoint('node');
  await checkpoint('application_open', loadApplication, {}, options.settle_seconds);
  let previous = 0, lastTaskRow;
  for (const count of options.counts) {
    await checkpoint(`before_create_${count}`, undefined, { sessions: previous });
    await checkpoint(`created_${count}`, () => createSessions(previous, count), { sessions: count }, options.settle_seconds);
    if (options.history_steps) {
      let rounds = 0;
      for (const step of options.history_steps) {
        lastTaskRow = await checkpoint(`history_${step}`, () => tasks(0, count, rounds, step),
          { sessions: count, rounds_per_session: step }, options.settle_seconds);
        rounds = step;
      }
    } else lastTaskRow = await checkpoint(`tasks_${count}`, () => tasks(previous, count, 0, options.rounds),
      { sessions: count, rounds_per_session: options.rounds }, options.settle_seconds);
    previous = count;
  }
  const lastTaskEnd = started + lastTaskRow.operation_finished_elapsed_seconds * 1000;
  for (const seconds of options.idle_seconds) {
    await checkpoint(`idle_${seconds}s`, () => delay(Math.max(0, seconds * 1000 - (performance.now() - lastTaskEnd))),
      { seconds_since_task_completion: seconds });
  }
  await checkpoint('watch_released', async () => { await call('session.unwatch', { watch_id: watchId }); watchId = undefined; });
  const rounds = options.history_steps?.at(-1) ?? options.rounds;
  await checkpoint('resume', () => tasks(0, Math.min(4, options.counts.at(-1)), rounds, rounds + 1), {}, options.settle_seconds);
  await checkpoint('reload', async () => {
    for (let index = 0; index < Math.min(4, options.counts.at(-1)); index++) {
      const session_id = `probe_${index}`;
      await call('session.get', { session_id });
      const result = await call('submission.get', { session_id, request_id: 'task_0' });
      if (result.status !== 'done') throw Error('Stored outcome lost');
      const page = await call('transcript.list', { session_id, limit: 50 });
      if (!page.items.length) throw Error('Stored history lost');
    }
  });
  await checkpoint('application_closed', async () => { await app.close(); app = undefined; });
  if (JSON.stringify(sources()) !== JSON.stringify(sourceHashes)) throw Error('Measured source changed');
} catch (failure) { error = `${failure.name}: ${failure.message}`; process.exitCode = 1; }
finally {
  console.log(JSON.stringify({ schema: 1, kind: 'worker_growth_diagnostic', diagnostic_only: true,
    accepted_capacity_evidence: false, completed: !error, error: error ?? null,
    node: process.version, exec_argv: process.execArgv, node_options: process.env.NODE_OPTIONS ?? '',
    options, limits, source_sha256: sourceHashes,
    forced_gc: typeof globalThis.gc === 'function', rows, notes: [
      'Real Application/Pi/provider SDK/tools; direct dispatch excludes Rust, editor and external driver.',
      'The model provider is the unchanged standard benchmark synthetic fixture; no network is allowed.',
      'Worker PSS, V8 heap and cgroup totals are separate accounting measures.',
      'Cgroup totals include this diagnostic, tool processes, init, file cache and kernel memory.',
      'Process CPU excludes child tool CPU; cgroup CPU includes tools.',
      'Rows and source hashes are retained by this diagnostic; request bodies and prompts are not logged.',
      'Pi documentCacheSizes is a read-only upstream diagnostic interface, not application state.',
      'One selected session is watched during activity and idle; resume follows release of that watch.',
      'Incremental session stages have different idle ages; compare equal stages and report stage timing.',
      'Forced collection, when explicitly enabled, is supplementary and changes subsequent allocator state.'
    ] }, null, 2));
  await app?.close();
  if (directory) await rm(directory, { recursive: true, force: true });
}
