"""Preserve complete diagnostic evidence in one archive and one compact summary."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / '.bench-results/growth-2026-10-22'
PUBLIC = ROOT / 'benchmarks/trials'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def groups(name):
    report = json.loads((WORK / f'{name}-summary.json').read_text())
    metrics = ['worker_pss_mib', 'worker_heap_used_mib', 'cgroup_memory_mib',
        'cgroup_anon_mib', 'cgroup_file_mib', 'worker_operation_cpu_ms',
        'operation_wall_ms', 'worker_operation_cpu_ms_per_task', 'request_bytes_per_task',
        'requests_in_operation', 'tasks_in_operation', 'elapsed_seconds',
        'operation_finished_elapsed_seconds', 'pi_documents_cached', 'pi_documents_sweeps']
    result = []
    for group in report['groups']:
        entry = {key: group[key] for key in ['workload', 'policy', 'document_retention_ms',
            'image', 'source_sha256', 'n', 'comparison_available', 'totals',
            'operational_16_to_64_session_slopes']}
        entry['checkpoints'] = {name: {key: values[key] for key in metrics if key in values}
            for name, values in group['checkpoints'].items()
            if name == 'application_open' or name.startswith(('tasks_', 'history_', 'idle_'))
            or name in ('resume', 'reload')}
        entry['runs'] = [{'label': run['label'], 'sha256': run['result_sha256']}
            for run in group['runs']]
        result.append(entry)
    return result


gate_path = ROOT / 'tests/evidence/performance.json'
gate = json.loads(gate_path.read_text())
assert gate['exit_code'] == 0 and not gate['source_changed_during_check']
for name, expected in gate['source_sha256'].items():
    assert digest((ROOT / name).read_bytes()) == expected, name

summary = {'schema': 1, 'date': '2026-10-22', 'accepted_capacity_evidence': False,
    'kind': 'worker_session_and_history_growth',
    'method': {'cpu_affinity': [30, 31], 'distinct_physical_cores': True,
        'cpu_quota': 2, 'memory_bytes': 536870912, 'swap_bytes': 0, 'network': 'none',
        'v8_old_generation_mib': 1024, 'max_active_sessions': 4,
        'accounting': 'Worker PSS and V8 heap; separate cgroup memory, anonymous memory, and file cache.',
        'scope': 'Direct Application/Pi/provider SDK and actual tools; diagnostic and simulated provider share Node. No Rust server or editor.',
        'forced_gc': False, 'policies': {'default_documents_ms': 600000,
            'current_documents_ms': 30000, 'context_ms': 600000}},
    'scaling': groups('scaling'), 'history': groups('history'), 'expiry': groups('expiry'),
    'correctness': {'new_application_changes': False, 'prior_gate': 'tests/evidence/performance.json',
        'prior_gate_sha256': digest(gate_path.read_bytes()),
        'source_files_verified_unchanged': len(gate['source_sha256']),
        'verified_at_unix_seconds': time.time(),
        'trial_checks': 'All tasks completed; resume, saved receipt, stored history, limits, source identities, and no OOM verified.'},
    'decisions': [
        'Keep the existing 30-second document setting and 600-second context setting.',
        'The interleaved large-session comparison supports lower post-resume worker memory with a small measured resume CPU cost.',
        'No active-load or small-session benefit is established. No new application optimization was retained.',
        'Defer on-demand instruction metadata: broad changes to configuration, inheritance, recovery and watches for a workload-dependent saving.',
        'Defer more formatting changes until a whole-workload profile supports them.'
    ],
    'limits': [
        'These diagnostics do not replace the standard benchmark or establish comparable competitor session-growth rates.',
        'Three-run ranges are descriptive, not confidence intervals; CPU affinity does not reserve an exclusive host.',
        'Stages accumulate sessions; allocation, shared code and session idle age prevent a universal linear per-session charge.',
        'Cache expiry removes references; resident memory need not fall until later collection and allocation.',
        'CPU includes Pi, SDK serialization and the synthetic provider. Worker CPU excludes child tool CPU.',
        'Batch elapsed time divided by task count is inverse throughput, not individual task latency.',
        'History and expiry runs use only the current policy and do not prove a causal retention effect.',
        'The synthetic provider also supplies any compaction summary; these runs do not prove real-conversation summary quality or long-term stability.',
        'The 660-second expiry result is one observation, not a repeated estimate.'
    ]}

paths = {ROOT / name for name in gate['source_sha256']}
paths.update(ROOT / name for name in ['AGENTS.md', 'README.md', 'ARCHITECTURE.md', 'PERFORMANCE.md',
    'SPEC.md', 'rust-toolchain.toml', 'benchmarks/Dockerfile', 'tests/evidence/performance.json'])
paths.update(path for path in (ROOT / 'plugin').rglob('*') if path.is_file())
paths.update(path for path in (WORK / 'results').iterdir() if path.is_file())
paths.update(WORK / name for name in ['host.json', 'pilot.log', 'scaling.log', 'history.log',
    'expiry.log', 'scaling-summary.json', 'history-summary.json', 'expiry-summary.json'])
paths.update(WORK / 'tools' / name for name in ['growth-probe.mjs', 'run.py', 'run-pilot.py', 'summarize.py', 'pack.py'])
payload = {str(path.relative_to(ROOT)): path.read_bytes() for path in sorted(paths)}
manifest = {'schema': 1, 'diagnostic_only': True, 'accepted_capacity_evidence': False,
    'files': {name: {'bytes': len(data), 'sha256': digest(data),
        'mode': (ROOT / name).stat().st_mode & 0o777} for name, data in payload.items()}}
manifest_bytes = (json.dumps(manifest, indent=2)+'\n').encode()
archive = PUBLIC / '2026-10-22.tar.gz'
public_summary = PUBLIC / '2026-10-22.json'
assert not archive.exists() and not public_summary.exists()
with archive.open('xb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in {**payload, 'archive-manifest.json': manifest_bytes}.items():
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = manifest['files'].get(name, {}).get('mode', 0o644)
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getnames()) == len(payload)+1
    for name, expected in payload.items():
        assert tar.extractfile(name).read() == expected, name
summary['archive'] = {'path': str(archive.relative_to(ROOT)), 'sha256': digest(archive.read_bytes()),
    'bytes': archive.stat().st_size, 'file_count': len(payload),
    'manifest': 'archive-manifest.json', 'manifest_sha256': digest(manifest_bytes)}
public_summary.write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({'archive': summary['archive'], 'summary': str(public_summary.relative_to(ROOT))}))
