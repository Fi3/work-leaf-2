"""Run isolated worker diagnostics on CPUs 30 and 31; never publish a baseline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / '.bench-results/growth-2026-10-22'
TOOLS = OUT / 'tools'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args):
    os.sched_setaffinity(0, {30, 31})
    image = subprocess.check_output(['docker', 'image', 'inspect', 'harness-investigation:documents',
        '--format', '{{.Id}}'], text=True).strip()
    identities = {str(p.relative_to(ROOT)): digest(p) for p in [
        TOOLS / 'growth-probe.mjs', Path(__file__), ROOT / 'benchmarks/provider.mjs',
        ROOT / 'benchmarks/profile.json', ROOT / 'adapter/pi.mjs', ROOT / 'adapter/view.mjs']}
    matrix = []
    for repeat in range(1, args.repeats + 1):
        policies = ['default', 'documents'] if repeat % 2 else ['documents', 'default']
        policies = [policy for policy in policies if policy in args.policies]
        for size in args.profiles:
            for policy in policies:
                config = {'profile': size, 'contextRetentionMs': 600000,
                    'documentRetentionMs': 600000 if policy == 'default' else 30000,
                    'watch': True, 'idle_seconds': [2, 35]}
                if size == 'history':
                    config.update(profile='small', counts=[4], history_steps=[1, 10, 25, 50])
                if args.long_idle:
                    config['idle_seconds'] = [2, 35, 660]
                if args.pilot:
                    config.update(counts=[1, 4], idle_seconds=[2, 35])
                matrix.append((f'{args.label}-{size}-{policy}-{repeat}', config))
    record = {'schema': 1, 'diagnostic_only': True, 'accepted_capacity_evidence': False,
        'cpu_affinity': [30, 31], 'image': image, 'file_sha256': identities, 'runs': []}
    manifest = OUT / 'results' / f'{args.label}-runs.json'
    if manifest.exists():
        raise FileExistsError(manifest)
    for label, config in matrix:
        for path, expected in identities.items():
            assert digest(ROOT / path) == expected, path
        name = 'harness-growth-' + uuid.uuid4().hex[:12]
        command = ['docker', 'run', '--name', name, '--init', '--network', 'none',
            '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--cpuset-cpus', '30,31',
            '--cpus', '2', '--memory', '536870912', '--memory-swap', '536870912',
            '--pids-limit', '256', '--env', 'NODE_OPTIONS=--max-old-space-size=1024',
            '--mount', f'type=bind,src={TOOLS / "growth-probe.mjs"},dst=/app/benchmarks/growth-probe.mjs,readonly',
            '--entrypoint', 'node', image, '/app/benchmarks/growth-probe.mjs', '/app', json.dumps(config)]
        if args.force_gc:
            command.insert(command.index('/app/benchmarks/growth-probe.mjs'), '--expose-gc')
        stdout = OUT / 'results' / f'{label}.json'
        stderr = OUT / 'results' / f'{label}.stderr.log'
        entry = {'label': label, 'command': command, 'config': config, 'started_at': time.time(),
            'host_load_before': Path('/proc/loadavg').read_text().strip()}
        print('START', label, flush=True)
        status = None
        try:
            with stdout.open('x') as output, stderr.open('x') as errors:
                status = subprocess.run(command, stdout=output, stderr=errors, timeout=1000).returncode
            inspected = json.loads(subprocess.check_output(['docker', 'inspect', name], text=True))[0]
            entry['container'] = {key: inspected[key] for key in ['Id', 'Image', 'State', 'HostConfig']}
        finally:
            subprocess.run(['docker', 'rm', '--force', name], stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, check=False)
        entry.update(exit_code=status, elapsed_seconds=time.time()-entry['started_at'],
            sha256=digest(stdout), stderr_sha256=digest(stderr),
            host_load_after=Path('/proc/loadavg').read_text().strip())
        record['runs'].append(entry)
        manifest.write_text(json.dumps(record, indent=2)+'\n')
        print('END', label, status, round(entry['elapsed_seconds'], 2), flush=True)
        if status:
            raise RuntimeError('Diagnostic failed: '+label)
        data = json.loads(stdout.read_text())
        assert data['completed'] and data['error'] is None, label
        assert data['limits']['process_allowed_cpus'] == '30-31', label
        assert not entry['container']['State']['OOMKilled'], label
        assert entry['container']['HostConfig']['CpusetCpus'] == '30,31', label
        for path, expected in identities.items():
            assert digest(ROOT / path) == expected, path


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label', required=True)
    parser.add_argument('--profiles', nargs='+', choices=['small', 'large', 'history'], default=['small', 'large'])
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--policies', nargs='+', choices=['default', 'documents'], default=['default', 'documents'])
    parser.add_argument('--pilot', action='store_true')
    parser.add_argument('--long-idle', action='store_true')
    parser.add_argument('--force-gc', action='store_true')
    run(parser.parse_args())
