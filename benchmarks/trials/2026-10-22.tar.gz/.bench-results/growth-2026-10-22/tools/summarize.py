"""Summarize explicit worker-growth trial manifests; never accept pilot evidence."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
from statistics import median

MIB = 1024 * 1024


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cpu_set(value):
    result = set()
    for part in value.split(','):
        bounds = [int(item) for item in part.split('-')]
        first, last = bounds[0], bounds[-1]
        result.update(range(first, last + 1))
    return result


def distribution(values):
    values = [value for value in values if value is not None]
    return None if not values else {
        'n': len(values), 'median': median(values), 'minimum': min(values),
        'maximum': max(values), 'range': max(values) - min(values)}


def aggregate(records):
    keys = sorted({key for record in records for key in record})
    return {key: distribution([record.get(key) for record in records]) for key in keys}


def verify_run(manifest, entry, path, permit_forced_gc):
    data = json.loads(path.read_text())
    errors = []

    def require(condition, message):
        if not condition:
            errors.append(message)

    require('pilot' not in entry['label'].lower(), 'Pilot runs cannot enter the main summary')
    require(entry['exit_code'] == 0 and data['completed'] and data['error'] is None,
            'Run did not complete successfully')
    require(digest(path) == entry['sha256'], 'Result SHA-256 differs from manifest')
    stderr = path.with_suffix('.stderr.log')
    require(stderr.exists() and digest(stderr) == entry['stderr_sha256'], 'Stderr SHA-256 differs')
    require(data['diagnostic_only'] and not data['accepted_capacity_evidence'], 'Trial evidence flags differ')
    require(manifest['cpu_affinity'] == [30, 31], 'Runner affinity differs')
    limits, settings = data['limits'], data['options']
    require(cpu_set(limits['cpuset']) == {30, 31}, 'Container CPU set differs')
    require(cpu_set(limits['process_allowed_cpus']) == {30, 31}, 'Process CPU set differs')
    require(limits['cpu_max'][0] / limits['cpu_max'][1] == 2, 'CPU quota differs')
    require(limits['memory_max'] == 536870912 and limits['swap_max'] == 0, 'Memory/swap limits differ')
    require(limits['network_interfaces'] == ['lo'], 'Network interfaces differ')
    require(settings['contextRetentionMs'] == 600000, 'Context retention differs')
    require(settings['documentRetentionMs'] in (30000, 600000), 'Unknown document retention policy')
    require('--max-old-space-size=1024' in data['node_options'].split(), 'V8 heap option differs')
    require(permit_forced_gc or not data['forced_gc'], 'Forced-GC run requires --allow-forced-gc')
    inspected = entry['container']
    host = inspected['HostConfig']
    require(inspected['Image'] == manifest['image'], 'Container image differs from manifest')
    require(not inspected['State']['OOMKilled'] and inspected['State']['ExitCode'] == 0,
            'Container failed or was killed by OOM')
    require(cpu_set(host['CpusetCpus']) == {30, 31} and host['NanoCpus'] == 2000000000,
            'Docker CPU configuration differs')
    require(host['Memory'] == 536870912 and host['MemorySwap'] == 536870912,
            'Docker memory/swap configuration differs')
    require(host['NetworkMode'] == 'none' and host['PidsLimit'] == 256,
            'Docker network/process configuration differs')
    for key, expected in entry['config'].items():
        require(settings.get(key) == expected, f'Probe configuration differs: {key}')
    source = data['source_sha256']
    for key, expected in manifest['file_sha256'].items():
        if key.endswith('/growth-probe.mjs'):
            require(source['probe_sha256'] == expected, 'Probe SHA-256 differs')
        elif key in source['files']:
            require(source['files'][key] == expected, f'Source SHA-256 differs: {key}')
    names = [row['name'] for row in data['rows']]
    require(len(names) == len(set(names)), 'Duplicate checkpoint names')
    require(names and names[0] == 'node' and names[-1] == 'application_closed',
            'Initial or final checkpoint is missing')
    require(all(name in names for name in ['application_open', 'idle_35s', 'resume', 'reload']),
            'Required checkpoint is missing')
    last_cpu = 0
    for row in data['rows']:
        state = row['before_gc']['cgroup']
        require(all(state['memory_events'].get(key, 0) == 0 for key in ('oom', 'oom_kill', 'oom_group_kill')),
                f'OOM event at {row["name"]}')
        usage = state['cpu']['usage_usec']
        require(usage >= last_cpu, f'CPU counter decreased at {row["name"]}')
        last_cpu = usage
    counts = settings['counts']
    rounds = settings.get('history_steps', [settings['rounds']])[-1]
    expected_tasks = counts[-1] * rounds + min(4, counts[-1])
    require(data['rows'][-1]['completed_tasks'] == expected_tasks, 'Completed task count differs')
    require(sum(row['tasks_in_operation'] for row in data['rows']) == expected_tasks,
            'Task checkpoint counts do not sum to total')
    if errors:
        raise ValueError(f'{entry["label"]}: ' + '; '.join(errors))
    return data


def checkpoint_metrics(row, previous):
    state = row['before_gc']
    cgroup = state['cgroup']
    cpu_ms = sum(row['operation_cpu_us'].values()) / 1000
    tasks = row['tasks_in_operation']
    previous_cpu = previous['before_gc']['cgroup']['cpu']['usage_usec'] if previous else cgroup['cpu']['usage_usec']
    result = {
        'elapsed_seconds': row['elapsed_seconds'],
        'operation_finished_elapsed_seconds': row['operation_finished_elapsed_seconds'],
        'worker_pss_mib': state['smaps_bytes']['Pss'] / MIB,
        'worker_rss_mib': state['memory']['rss'] / MIB,
        'worker_heap_used_mib': state['memory']['heapUsed'] / MIB,
        'worker_heap_total_mib': state['memory']['heapTotal'] / MIB,
        'worker_external_mib': state['memory']['external'] / MIB,
        'cgroup_memory_mib': cgroup['memory_bytes'] / MIB,
        'cgroup_anon_mib': cgroup['memory_stat']['anon'] / MIB,
        'cgroup_file_mib': cgroup['memory_stat']['file'] / MIB,
        'cgroup_kernel_mib': cgroup['memory_stat'].get('kernel', 0) / MIB,
        'cgroup_lifetime_peak_mib': cgroup['memory_peak_bytes'] / MIB,
        'cgroup_cpu_ms_since_previous_checkpoint': (cgroup['cpu']['usage_usec'] - previous_cpu) / 1000,
        'cgroup_throttled_ms_cumulative': cgroup['cpu'].get('throttled_usec', 0) / 1000,
        'operation_wall_ms': row['operation_wall_ms'],
        'worker_operation_cpu_ms': cpu_ms,
        'completed_tasks': row['completed_tasks'],
        'tasks_in_operation': tasks,
        'requests_in_operation': row['requests_in_operation'],
        'request_bytes_in_operation': row['request_bytes_in_operation'],
        'request_maximum_body_bytes_so_far': row['requests']['maximum_body_bytes'],
        'worker_operation_cpu_ms_per_task': cpu_ms / tasks if tasks else None,
        'batch_elapsed_ms_per_completed_task': row['operation_wall_ms'] / tasks if tasks else None,
        'request_bytes_per_task': row['request_bytes_in_operation'] / tasks if tasks else None,
        'request_count_per_task': row['requests_in_operation'] / tasks if tasks else None,
        'storage_file_bytes': sum(item['bytes'] for item in state['storage_files']),
    }
    if tasks:
        result['cgroup_cpu_ms_per_task_since_previous_checkpoint'] = (
            result['cgroup_cpu_ms_since_previous_checkpoint'] / tasks)
    if state['pi_document_cache']:
        result.update({f'pi_documents_{key}': value for key, value in state['pi_document_cache'].items()})
    if row.get('after_gc'):
        result['forced_gc_worker_pss_mib'] = row['after_gc']['smaps_bytes']['Pss'] / MIB
        result['forced_gc_worker_heap_used_mib'] = row['after_gc']['memory']['heapUsed'] / MIB
    return result


def workload_identity(data):
    settings = data['options']
    profile = 'history' if settings.get('history_steps') else settings['profile']
    identity = {key: settings.get(key) for key in ('counts', 'rounds', 'input_bytes', 'instructions_bytes',
        'history_steps', 'idle_seconds', 'settle_seconds', 'contextRetentionMs')}
    return profile, {**identity, 'profile': profile, 'forced_gc': data['forced_gc']}


def summarize(paths, expected_repeats, permit_forced_gc, allow_single_policy=False):
    groups, seen, source_by_workload, image_by_workload = {}, set(), {}, {}
    manifests = []
    for path in paths:
        manifest = json.loads(path.read_text())
        if 'pilot' in path.name.lower():
            raise ValueError('Pilot manifests cannot enter the main summary')
        manifests.append({'path': str(path), 'sha256': digest(path), 'runs': len(manifest['runs'])})
        for entry in manifest['runs']:
            if entry['label'] in seen:
                raise ValueError('Repeated run label: ' + entry['label'])
            seen.add(entry['label'])
            result_path = path.parent / (entry['label'] + '.json')
            data = verify_run(manifest, entry, result_path, permit_forced_gc)
            profile, identity = workload_identity(data)
            workload_key = json.dumps(identity, sort_keys=True)
            sources = data['source_sha256']
            if workload_key in source_by_workload and source_by_workload[workload_key] != sources:
                raise ValueError('Source identity changed within workload ' + profile)
            if workload_key in image_by_workload and image_by_workload[workload_key] != manifest['image']:
                raise ValueError('Image identity changed within workload ' + profile)
            source_by_workload[workload_key], image_by_workload[workload_key] = sources, manifest['image']
            policy = 'default' if data['options']['documentRetentionMs'] == 600000 else 'documents'
            key = (workload_key, policy)
            group = groups.setdefault(key, {'workload': identity, 'policy': policy,
                'document_retention_ms': data['options']['documentRetentionMs'], 'image': manifest['image'],
                'source_sha256': sources, 'runs': [], 'checkpoint_records': defaultdict(list),
                'totals_records': [], 'slope_records': []})
            by_name, previous = {}, None
            for row in data['rows']:
                metrics = checkpoint_metrics(row, previous)
                group['checkpoint_records'][row['name']].append(metrics)
                by_name[row['name']] = metrics
                previous = row
            first, last = data['rows'][0], data['rows'][-1]
            task_rows = [row for row in data['rows'] if row['tasks_in_operation']]
            totals = {
                'completed_tasks': last['completed_tasks'],
                'elapsed_seconds': last['elapsed_seconds'],
                'cgroup_cpu_ms_since_node': (last['before_gc']['cgroup']['cpu']['usage_usec']
                    - first['before_gc']['cgroup']['cpu']['usage_usec']) / 1000,
                'worker_operation_cpu_ms_sum': sum(sum(row['operation_cpu_us'].values()) for row in data['rows']) / 1000,
                'worker_task_operation_cpu_ms_sum': sum(sum(row['operation_cpu_us'].values()) for row in task_rows) / 1000,
                'request_count': last['requests']['count'],
                'request_body_bytes': last['requests']['body_bytes'],
            }
            totals['worker_task_operation_cpu_ms_per_task'] = totals['worker_task_operation_cpu_ms_sum'] / totals['completed_tasks']
            group['totals_records'].append(totals)
            slopes = {}
            if 'tasks_16' in by_name and 'tasks_64' in by_name:
                for metric in ('worker_pss_mib', 'worker_heap_used_mib', 'cgroup_memory_mib', 'cgroup_anon_mib', 'cgroup_file_mib'):
                    slopes[metric + '_per_added_session'] = (by_name['tasks_64'][metric] - by_name['tasks_16'][metric]) / 48
                group['slope_records'].append(slopes)
            group['runs'].append({'label': entry['label'], 'result_path': str(result_path),
                'result_sha256': entry['sha256'], 'totals': totals,
                'operational_16_to_64_session_slopes': slopes, 'checkpoints': by_name})
    output = []
    for (workload_key, policy), group in groups.items():
        if expected_repeats and len(group['runs']) != expected_repeats:
            raise ValueError(f'{group["workload"]["profile"]}/{policy}: expected {expected_repeats} runs, found {len(group["runs"])}')
        other = 'documents' if policy == 'default' else 'default'
        if (workload_key, other) not in groups and not allow_single_policy:
            raise ValueError(f'Missing matching {other} policy for ' + group['workload']['profile'])
        group['comparison_available'] = (workload_key, other) in groups
        group['n'] = len(group['runs'])
        group['checkpoints'] = {name: aggregate(values) for name, values in group.pop('checkpoint_records').items()}
        group['totals'] = aggregate(group.pop('totals_records'))
        group['operational_16_to_64_session_slopes'] = aggregate(group.pop('slope_records'))
        output.append(group)
    return {'schema': 1, 'kind': 'worker_growth_trial_summary', 'diagnostic_only': True,
        'accepted_capacity_evidence': False, 'manifests': manifests, 'groups': output,
        'validation': {'all_runs_completed': True, 'all_hashes_valid': True,
            'same_sources_and_image_within_workload': True, 'no_oom': True,
            'cpu_affinity': [30, 31], 'cpu_quota': 2, 'memory_bytes': 536870912,
            'swap_bytes': 0, 'network': 'none', 'v8_old_space_mib': 1024,
            'single_policy_observations_allowed': allow_single_policy},
        'notes': [
            'Explicit manifests only. Pilot evidence is rejected; history, idle schedules and forced-GC runs remain separate.',
            'A group without a matching policy is a growth or expiry observation; it cannot establish the causal effect of retention settings.',
            'Median/minimum/maximum describe repeated runs, not a confidence interval.',
            'Worker PSS/heap and container memory/anon/file are separate accounting methods.',
            'Container totals include tools, diagnostic allocations, file cache and kernel memory; no Rust server or editor runs.',
            'Operation CPU is Node process CPU during each operation; it excludes child tool CPU and settlement intervals.',
            'Container CPU since the previous checkpoint includes the operation, settlement, tools and diagnostic overhead.',
            'batch_elapsed_ms_per_completed_task divides elapsed concurrent batch time by completed tasks; it is inverse throughput, not individual task latency or pure harness overhead.',
            'The 16-to-64-session slope is an operational difference across cumulative stages, not a pure per-session memory constant.',
            'Earlier sessions have different idle ages and can expire before later stages. Inspect phase timing and cache counts.',
            'Container memory peak is lifetime-wide, not a separate peak for each checkpoint.',
            'Request byte totals include repeated context serialization; no request bodies or prompt text are retained.',
            'Forced-GC measurements, if explicitly allowed, change allocator state and cannot prove natural memory savings.'
        ]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifests', nargs='+', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--expected-repeats', type=int, default=3)
    parser.add_argument('--allow-forced-gc', action='store_true')
    parser.add_argument('--allow-single-policy', action='store_true',
        help='Allow separately reported growth/expiry observations without a matching retention policy')
    args = parser.parse_args()
    if args.expected_repeats < 1:
        parser.error('--expected-repeats must be positive')
    result = summarize(args.manifests, args.expected_repeats, args.allow_forced_gc, args.allow_single_policy)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'groups': len(result['groups']),
        'runs': sum(group['n'] for group in result['groups'])}))


if __name__ == '__main__':
    main()
