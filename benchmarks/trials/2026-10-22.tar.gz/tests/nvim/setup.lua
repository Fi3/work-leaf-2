local feed_keys = dofile(vim.fn.getcwd() .. '/tests/nvim/helpers.lua').keys
vim.opt.runtimepath:append(vim.fn.getcwd())
vim.o.columns, vim.o.lines = 120, 40
local saved_environment = {}
for _, name in ipairs({ 'SSH_CONNECTION', 'SSH_TTY' }) do
  saved_environment[name] = vim.env[name]
  vim.env[name] = nil
end
local source, previous = vim.api.nvim_get_current_buf(), vim.api.nvim_get_current_win()
vim.api.nvim_buf_set_lines(source, 0, -1, false, { 'Unsent draft λ 世界' })
local tick = vim.api.nvim_buf_get_changedtick(source)
local directory = vim.fn.tempname()
vim.fn.mkdir(directory, 'p')
local url = 'https://login.example.test/auth?state=' .. string.rep('abc123', 100) .. '&redirect_uri=http%3A%2F%2F127.0.0.1%2Fcallback'
vim.fn.writefile(vim.split([[
import base64, os, sys, tty
tty.setraw(0)
def link(identity, value):
    action = '[ Copy link ]' if os.environ.get('SSH_CONNECTION') or os.environ.get('SSH_TTY') else '[ Open browser ]'
    label = action if identity == 'harness-login' and value.startswith('https:') else value
    os.write(1, ('\x1b]8;id='+identity+';'+value+'\x1b\\'+label+'\x1b]8;;\x1b\\\r\n').encode())
link('harness-login', sys.argv[1])
link('another-program', 'https://wrong.example.test')
link('harness-login', 'javascript:wrong')
os.write(1, b'Enter a value.\r\n')
while True:
    value = os.read(0, 1)
    if value == b'\x03': sys.exit(130)
    if value == b's': sys.exit(0)
    if value == b'c':
        link('harness-code-' + base64.b64encode(b'TEST-CODE').decode(), sys.argv[1])
        os.write(1, b'Device code ready.\r\n')
    if value == b'f':
        os.write(1, b'Login failed in test.\r\n')
        sys.exit(2)
]], '\n', { plain = true }), directory .. '/terminal.py')
local copied, opened, calls, result, messages, copy_failed = nil, nil, 0, nil, {}, false
local opens, browser_exit, browser_missing = {}, nil, false
local delay_connect, connected
vim.g.clipboard = { name = 'test clipboard', copy = { ['+'] = function(lines) if not copy_failed then copied = table.concat(lines, '\n') end end, ['*'] = function() end },
  paste = { ['+'] = function() return { {}, 'v' } end, ['*'] = function() return { {}, 'v' } end } }
local system = vim.system
vim.system = function(arguments, options, callback)
  assert(arguments[1] == 'xdg-open' and #arguments == 2, 'The browser receives one complete URL argument')
  assert(options.detach and options.stdout == false and options.stderr == false, 'The browser cannot write URLs into editor diagnostics')
  if browser_missing then error('No browser handler') end
  opened = arguments[2]
  opens[#opens + 1] = opened
  browser_exit = callback
  return {}
end
local setup = require('harness.setup').new({
  arguments = function() return { 'python3', '-u', directory .. '/terminal.py', url } end,
  connect = function(callback) if delay_connect then connected = callback else callback(true) end end,
}, function(message) messages[#messages + 1] = message end)
local function start_login(callback)
  setup.open({ id = 'test', name = 'Test provider' }, { id = 'oauth', name = 'Test account' }, callback)
end
local function wait(predicate, message) assert(vim.wait(3000, predicate, 5), message) end
local function keys(value)
  vim.cmd('stopinsert')
  feed_keys(value)
  vim.wait(10)
end
local window, buffer, channel
local function login_link(value)
  vim.api.nvim_exec_autocmds('TermRequest', { buffer = buffer, data = { sequence = '\027]8;id=harness-login;' .. value } })
end
local function open()
  calls, result = 0, nil
  local count = #opens
  start_login(function(focused, succeeded)
    calls = calls + 1
    result = { focused = focused, succeeded = succeeded }
  end)
  window, buffer = setup.window, setup.buffer
  channel = vim.bo[buffer].channel
  wait(function() return vim.wo[window].winbar:find('Copy', 1, true) end, 'A real terminal OSC8 link enables the visible controls')
  wait(function() return #opens == count + 1 and opened == url end, 'Selecting account login opens the complete URL once without copying or keyboard input')
  assert(not table.concat(vim.api.nvim_buf_get_lines(buffer, 0, -1, false), '\n'):find(url, 1, true),
    'The default terminal display does not expose a long address to an outer text detector')
end
local function closed()
  wait(function() return calls == 1 end, 'Login completion callback')
  assert(not vim.api.nvim_win_is_valid(window) and not vim.api.nvim_buf_is_valid(buffer), 'Login owns no window or terminal after closing')
  assert(vim.api.nvim_buf_get_changedtick(source) == tick, 'Login does not change the caller draft')
  vim.wait(20)
  assert(calls == 1, 'Closing and child exit cannot call completion twice')
end
open()
local controls = vim.api.nvim_eval_statusline(vim.wo[window].winbar, { winid = window, use_winbar = true }).str
assert(controls:find('Open browser', 1, true) < controls:find('Copy link', 1, true)
  and controls:find('Full link', 1, true) and controls:find('Cancel', 1, true),
  'The first visible action opens the browser; copying is optional')
assert(vim.inspect(vim.api.nvim_win_get_config(window).footer):find('Keep this window open', 1, true),
  'Browser login tells the user to keep the callback window open')
keys('<C-x>')
assert(copied == url and vim.api.nvim_get_current_buf() == buffer, 'Copy uses the complete fixed-id URL through the native clipboard')
keys('<C-o>')
assert(opened == url, 'Open passes the complete URL to the client browser handler')
assert(calls == 0 and vim.fn.jobwait({ channel }, 0)[1] == -1, 'Opening the browser keeps the same login process active')
local getmousepos = vim.fn.getmousepos
local function click(row, column, queued)
  opened = nil
  vim.fn.getmousepos = function() return { winid = window, winrow = row + 2, line = row, column = column } end
  if queued then vim.fn.maparg('<LeftRelease>', 'n', false, true).callback() else keys('<LeftRelease>') end
  vim.fn.getmousepos = getmousepos
end
local count = #opens
login_link(url)
vim.wait(20)
assert(#opens == count, 'A repeated terminal hyperlink does not open another browser tab')
for _, width in ipairs({ 76, 38, 26 }) do
  vim.api.nvim_win_set_width(window, width)
  vim.wait(20)
  assert(vim.api.nvim_buf_get_lines(buffer, 0, 1, false)[1] == '[ Open browser ]', 'The short browser control fits without wrapping')
  click(1, 2)
  assert(opened == url, 'The short control opens the complete retained URL at every width')
  click(2, 2)
  assert(opened == nil, 'A different printed URL cannot open the retained login link')
  click(1, #'[ Open browser ]' + 1)
  assert(opened == nil, 'Clicking after the control does not open it')
end
vim.api.nvim_win_set_width(window, 76)
copy_failed, copied = true, nil
keys('<C-x>')
assert(copied == nil and vim.inspect(vim.api.nvim_win_get_config(window).footer):find('Copy requested', 1, true),
  'An asynchronous clipboard failure must not be reported as a confirmed copy')
keys('<C-l>')
assert(vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == url and vim.fn.getreg() == url,
  'The complete selectable link stays available when a configured clipboard does not deliver')
assert(vim.wo[window].winbar:find('Open browser', 1, true) and vim.wo[window].winbar:find('Cancel', 1, true),
  'The selectable link retains the visible browser and cancellation controls')
keys('<CR>')
assert(vim.wo[window].winbar:find('Open browser', 1, true), 'Returning to terminal input retains the browser control')
keys('<C-l>')
vim.o.columns, vim.o.lines = 50, 16
vim.api.nvim_exec_autocmds('VimResized', {})
start_login(function() error('Login was replaced') end)
local reopened = vim.api.nvim_eval_statusline(vim.wo[window].winbar, { winid = window, use_winbar = true, maxwidth = 1000 }).str
assert(setup.window == window and vim.api.nvim_get_current_buf() == buffer and vim.bo[buffer].channel == channel,
  'Opening login again returns to the same private input, window and process')
assert(reopened:find('Open', 1, true) and reopened:find('Cancel', 1, true)
  and vim.fn.strdisplaywidth(reopened) <= vim.api.nvim_win_get_width(window),
  'Returning from a resized Full link view retains visible controls that fit')
copy_failed = false
for _, size in ipairs({ { 50, 16 }, { 30, 12 }, { 120, 40 } }) do
  vim.o.columns, vim.o.lines = size[1], size[2]
  vim.api.nvim_exec_autocmds('VimResized', {})
  local config = vim.api.nvim_win_get_config(window)
  assert(config.col + config.width + 2 <= size[1] and config.row + config.height + 2 <= size[2], 'Login fits the resized terminal')
  local bar = vim.api.nvim_eval_statusline(vim.wo[window].winbar, { winid = window, use_winbar = true, maxwidth = 1000 }).str
  assert(vim.fn.strdisplaywidth(bar) <= config.width and bar:find('Copy') and bar:find('Open')
    and (bar:find('Cancel') or bar:find('^C', 1, true)),
    'Copy, browser and cancellation controls remain visible on a narrow screen')
  assert(vim.inspect(config.footer):find('Keep', 1, true), 'The waiting instruction remains visible after resizing')
end
keys('v<Esc>')
assert(calls == 0 and vim.fn.jobwait({ channel }, 0)[1] == -1, 'Visual Escape keeps the login process active')
keys('<Esc>')
assert(calls == 0 and vim.fn.jobwait({ channel }, 0)[1] == -1, 'Normal Escape keeps the login process active')
keys('v<C-c>')
closed()
assert(result.focused and not result.succeeded and vim.api.nvim_get_current_win() == previous, 'Visual-mode Ctrl-C cancels back to the caller')
open()
vim.g.loaded_clipboard_provider = 0
local list_uis, ui_send, clipboard_request = vim.api.nvim_list_uis, vim.api.nvim_ui_send
vim.api.nvim_list_uis = function() return { {} } end
vim.api.nvim_ui_send = function(value) clipboard_request = value end
keys('<C-x>')
local encoded = assert(clipboard_request:match('^\027%]52;c;(.+)\027\\$'), 'A terminal UI receives a native clipboard request')
assert(vim.base64.decode(encoded) == url and vim.api.nvim_get_current_buf() == buffer,
  'The bundled clipboard provider sends the complete login link without user configuration')
clipboard_request = nil
vim.fn.chansend(channel, 'c')
wait(function()
  return table.concat(vim.api.nvim_buf_get_lines(buffer, 0, -1, false), '\n'):find('Device code ready.', 1, true)
end, 'The actual private terminal shows a device code')
assert(clipboard_request == nil, 'Showing a device code does not change the clipboard')
keys('<C-y>')
assert(vim.base64.decode(assert(clipboard_request:match('^\027%]52;c;(.+)\027\\$'))) == 'TEST-CODE',
  'A device code uses the bundled clipboard writer when no provider is configured')
for _, payload in ipairs({ 'not base64', 'A', string.rep('A', 1372), vim.base64.encode('control\ncode'), vim.base64.encode('\194\128') }) do
  vim.api.nvim_exec_autocmds('TermRequest', { buffer = buffer, data = { sequence = '\027]8;id=harness-code-' .. payload .. ';' .. url } })
end
vim.api.nvim_exec_autocmds('TermRequest', { buffer = buffer,
  data = { sequence = '\027]8;id=harness-code-' .. vim.base64.encode('WRONG-CODE') .. ';https://wrong.example.test' } })
keys('<C-y>')
assert(vim.base64.decode(assert(clipboard_request:match('^\027%]52;c;(.+)\027\\$'))) == 'TEST-CODE',
  'Invalid, oversized, control-bearing or unrelated code metadata cannot replace the displayed code')
vim.api.nvim_ui_send = function() error('Terminal UI unavailable') end
keys('<C-y>')
assert(vim.fn.getreg() == 'TEST-CODE' and vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == 'TEST-CODE',
  'A failed code copy leaves the complete device code available for native selection')
keys('<CR>')
vim.api.nvim_ui_send = function(value) clipboard_request = value end
clipboard_request = nil
login_link(url)
keys('<C-y>')
assert(clipboard_request == nil, 'A new login link clears the previous device code')
keys('<C-l>')
assert(vim.fn.getreg() == url and vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == url,
  'A terminal that denies clipboard access still has the complete selectable link')
keys('<CR>')
vim.api.nvim_ui_send = function() error('Terminal UI unavailable') end
keys('<C-x>')
assert(vim.api.nvim_buf_get_name(0) == 'harness://login-link', 'A native clipboard request failure opens the selectable link')
keys('<CR>')
vim.api.nvim_list_uis, vim.api.nvim_ui_send = list_uis, ui_send
keys('<C-x>')
local fallback = vim.api.nvim_get_current_buf()
assert(vim.api.nvim_buf_get_name(fallback) == 'harness://login-link', 'No clipboard opens the selectable link')
assert(vim.api.nvim_buf_get_lines(fallback, 0, 1, false)[1] == url and vim.fn.getreg() == url,
  'Fallback keeps one complete logical URL line and copies it to the Vim register')
assert(not vim.bo[fallback].modifiable and vim.bo[fallback].buftype == 'nofile', 'The link view cannot modify files')
keys('ggy$')
assert(vim.fn.getreg() == url, 'Native Vim yank copies the full link without hard wraps')
keys('<C-o>')
assert(opened == url, 'The fallback keeps the same browser action')
keys('<CR>')
assert(vim.api.nvim_get_current_buf() == buffer and vim.fn.jobwait({ channel }, 0)[1] == -1, 'Enter returns to the same live private terminal')
keys('<C-x><Esc>')
assert(vim.api.nvim_get_current_buf() == buffer and calls == 0 and vim.fn.jobwait({ channel }, 0)[1] == -1,
  'Escape from the full link returns to private input without cancelling login')
keys('<C-x><C-c>')
closed()
assert(not vim.api.nvim_buf_is_valid(fallback) and not result.succeeded, 'Cancelling the link view also removes its terminal')
open()
browser_missing = true
keys('<C-o>')
assert(vim.api.nvim_get_current_buf() == buffer and vim.inspect(vim.api.nvim_win_get_config(window).footer):find('Browser failed', 1, true),
  'An unavailable browser keeps the private login and reports the visible recovery action')
keys('<C-l>')
assert(vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == url, 'The complete selectable link remains available after browser failure')
browser_missing = false
keys('<CR><C-o>')
local old_exit, reports = browser_exit, #messages
keys('<C-o>')
old_exit({ code = 1, signal = 0 })
vim.wait(20)
assert(#messages == reports, 'An older browser failure cannot replace the result of a later retry')
local failed_exit = browser_exit
vim.api.nvim_set_current_win(previous)
failed_exit({ code = 0, signal = 15 })
vim.wait(20)
assert(vim.api.nvim_get_current_win() == previous and vim.api.nvim_buf_get_changedtick(source) == tick,
  'An asynchronous browser failure cannot take focus from a file or change its draft')
vim.api.nvim_set_current_win(window)
keys('<C-c>')
closed()
open()
keys('<C-l>')
vim.fn.chansend(channel, 'f')
wait(function() return vim.wo[window].winbar:find('Close', 1, true) end, 'Failed login remains visible for acknowledgment')
assert(vim.api.nvim_get_current_buf() == buffer, 'A failure in the full-link view shows the terminal error before acknowledgment')
assert(calls == 0, 'A failed login is not silently dismissed')
opened = nil
keys('<C-o>')
assert(opened == nil, 'A failed login cannot reopen its expired browser link')
click(1, 2)
assert(opened == nil and calls == 0, 'Clicking an expired link keeps the failure visible for acknowledgment')
keys('<C-l>')
assert(vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == url and vim.fn.getreg() == url,
  'A failed login keeps its complete link available for copying')
keys('<Esc>')
keys('<CR>')
closed()
assert(result.focused and not result.succeeded and #messages == 3, 'Acknowledging failure reports unsuccessful completion once')
open()
vim.api.nvim_set_current_win(previous)
vim.fn.chansend(channel, 's')
closed()
assert(result.succeeded and not result.focused and vim.api.nvim_get_current_win() == previous, 'Success after outside navigation keeps file focus')
open()
vim.v.errmsg = ''
browser_exit({ code = 1, signal = 0 })
login_link(url)
vim.api.nvim_win_close(window, true)
closed()
assert(not result.succeeded, 'Native window closure cancels without leaking a terminal')
assert(vim.v.errmsg == '', 'Closing before a queued browser failure does not access an invalid window')
open()
local before_close = #opens
login_link(url .. '&retry=1')
vim.api.nvim_win_close(window, true)
closed()
assert(#opens == before_close and vim.v.errmsg == '', 'Closing before the browser starts prevents a late browser tab')
open()
local before_change = #opens
click(1, 2, true)
login_link(url .. '&retry=1')
vim.wait(20)
assert(#opens == before_change + 1 and opened == url .. '&retry=1',
  'A queued click for an old link cannot open the replacement link a second time')
local before_repeat, before_reports = #opens, #messages
browser_exit({ code = 1, signal = 0 })
login_link(url)
login_link(url .. '&retry=1')
vim.wait(20)
assert(#messages == before_reports and #opens == before_repeat + 1,
  'A browser failure cannot apply after the login link changes away and back')
keys('<C-c>')
closed()
open()
delay_connect = true
vim.fn.chansend(channel, 's')
wait(function() return connected ~= nil end, 'Successful login waits for the connection result')
vim.api.nvim_win_close(window, true)
closed()
delay_connect = false
open()
local before_connection = #messages
connected(nil, 'Old connection failed')
vim.wait(20)
assert(#messages == before_connection and setup.window == window and calls == 0 and vim.api.nvim_get_current_win() == window,
  'A connection result after closure cannot report an old error or change the next login')
keys('<C-c>')
closed()
local local_opens = #opens
for _, name in ipairs({ 'SSH_CONNECTION', 'SSH_TTY' }) do
  vim.env[name] = 'test'
  calls, result, copied, clipboard_request = 0, nil, nil, nil
  local reports = #messages
  start_login(function(focused, succeeded)
    calls = calls + 1
    result = { focused = focused, succeeded = succeeded }
  end)
  window, buffer = setup.window, setup.buffer
  channel = vim.bo[buffer].channel
  wait(function() return vim.wo[window].winbar:find('Copy link', 1, true) end, 'SSH login offers a copy action without an error')
  local bar = vim.api.nvim_eval_statusline(vim.wo[window].winbar, { winid = window, use_winbar = true }).str
  assert(not bar:find('Open', 1, true) and bar:find('Full link', 1, true) and bar:find('Cancel', 1, true),
    'SSH login offers Copy link, Full link and Cancel without a misleading browser launch action')
  assert(vim.inspect(vim.api.nvim_win_get_config(window).footer):find('SSH: copy link to local browser.', 1, true),
    'SSH login identifies the remote connection and the local browser action')
  assert(#messages == reports and #opens == local_opens and copied == nil,
    'SSH login neither opens the remote browser nor copies a link before the user requests it')
  vim.api.nvim_list_uis = function() return { {} } end
  vim.api.nvim_ui_send = function(value) clipboard_request = value end
  for _, key in ipairs({ '<C-x>', '<C-o>' }) do
    clipboard_request = nil
    keys(key)
    assert(vim.base64.decode(assert(clipboard_request:match('^\027%]52;c;(.+)\027\\$'))) == url,
      'Both copy shortcuts send the complete URL to the local terminal clipboard under SSH')
    assert(copied == nil and vim.api.nvim_get_current_buf() == buffer,
      'SSH copy does not use the remote desktop clipboard or replace the login input')
  end
  clipboard_request = nil
  assert(vim.api.nvim_buf_get_lines(buffer, 0, 1, false)[1] == '[ Copy link ]', 'The SSH terminal labels its action as copy')
  click(1, 2)
  assert(vim.base64.decode(assert(clipboard_request:match('^\027%]52;c;(.+)\027\\$'))) == url,
    'Clicking the SSH terminal action copies the complete link')
  keys('<C-l>')
  assert(vim.fn.getreg() == url and vim.api.nvim_buf_get_lines(0, 0, 1, false)[1] == url,
    'SSH keeps the full address selectable without hard wraps')
  assert(vim.api.nvim_buf_get_lines(0, 2, 3, false)[1] == 'SSH: paste this link in your local browser.',
    'The full-link view states where the user must paste the address')
  keys('<CR>')
  assert(vim.api.nvim_get_current_buf() == buffer and calls == 0, 'Enter returns to the same login for the pasted reply')
  vim.api.nvim_ui_send = function() error('Clipboard unavailable') end
  keys('<C-x>')
  assert(vim.api.nvim_buf_get_name(0) == 'harness://login-link' and vim.fn.getreg() == url,
    'A terminal without clipboard support retains a complete selectable SSH link')
  keys('<Esc>')
  for _, size in ipairs({ { 50, 16 }, { 30, 12 }, { 120, 40 } }) do
    vim.o.columns, vim.o.lines = size[1], size[2]
    vim.api.nvim_exec_autocmds('VimResized', {})
    local config = vim.api.nvim_win_get_config(window)
    local controls = vim.api.nvim_eval_statusline(vim.wo[window].winbar, { winid = window, use_winbar = true, maxwidth = 1000 }).str
    assert(vim.fn.strdisplaywidth(controls) <= config.width and controls:find('Copy') and controls:find('Cancel'),
      'SSH copy and cancel actions remain visible after resizing')
    assert(vim.inspect(config.footer):find('SSH:', 1, true), 'SSH instructions remain visible after resizing')
  end
  vim.api.nvim_list_uis, vim.api.nvim_ui_send = list_uis, ui_send
  keys('<C-c>')
  closed()
  assert(result.focused and not result.succeeded, 'SSH cancellation returns to the unchanged draft')
  vim.env[name] = nil
end
assert(#opens == local_opens, 'SSH login never invokes the remote desktop browser')
vim.env.SSH_CONNECTION, vim.env.SSH_TTY = '', ''
open()
assert(#opens == local_opens + 1, 'Empty SSH environment values do not disable the local desktop browser')
keys('<C-c>')
closed()
open()
local removed_window, removed_buffer = window, buffer
vim.api.nvim_win_close(window, true)
local reopened_calls = 0
start_login(function() reopened_calls = reopened_calls + 1 end)
window, buffer = setup.window, setup.buffer
wait(function() return vim.wo[window].winbar:find('Copy', 1, true) end, 'A new login opens while native close cleanup is pending')
assert(calls == 1 and reopened_calls == 0 and setup.window == window and setup.buffer == buffer
  and not vim.api.nvim_win_is_valid(removed_window) and not vim.api.nvim_buf_is_valid(removed_buffer),
  'Cleanup from the old login cannot remove the new terminal or its public handles')
keys('<C-c>')
wait(function() return reopened_calls == 1 end, 'The replacement login completes once')
assert(not vim.api.nvim_win_is_valid(window) and not vim.api.nvim_buf_is_valid(buffer)
  and vim.api.nvim_get_current_win() == previous and vim.api.nvim_buf_get_changedtick(source) == tick,
  'The replacement login releases its terminal and restores the unchanged caller')
for _, name in ipairs({ 'SSH_CONNECTION', 'SSH_TTY' }) do vim.env[name] = saved_environment[name] end
vim.system = system
vim.fn.delete(directory, 'rf')
print('Neovim login checks passed: exact links, SSH copy controls, failures, clipboard, resize and focus.')
vim.cmd('noautocmd qa!')
