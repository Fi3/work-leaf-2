local feed_keys = dofile(vim.fn.getcwd() .. '/tests/nvim/helpers.lua').keys
vim.opt.runtimepath:append(vim.fn.getcwd())
vim.o.columns, vim.o.lines = 100, 30
vim.o.mouse = ''
local select = require('harness.select').select
local source, previous = vim.api.nvim_get_current_buf(), vim.api.nvim_get_current_win()
vim.api.nvim_buf_set_lines(source, 0, -1, false, { 'Unsent draft λ 世界', 'Second line' })
local tick = vim.api.nvim_buf_get_changedtick(source)
local items = {}
for index = 1, 47 do items[index] = { name = 'Model ' .. index .. ' λ', id = index } end
local result, calls, window, buffer
local function keys(value)
  feed_keys(value)
  vim.wait(10)
end
local function open(selected)
  calls, result = 0, nil
  select(items, { prompt = 'Model for this chat:', selected = selected, format_item = function(item) return item.name end }, function(item, index)
    calls = calls + 1
    result = { item = item, index = index }
  end)
  window, buffer = vim.api.nvim_get_current_win(), vim.api.nvim_get_current_buf()
  assert(vim.api.nvim_buf_get_name(buffer) == 'harness://select')
  assert(not vim.bo[buffer].modifiable and not vim.bo[buffer].buflisted)
  assert(vim.api.nvim_buf_line_count(buffer) == #items, 'Every option is retained in the native buffer')
  assert(vim.api.nvim_win_get_height(window) < #items, 'The list must scroll when choices exceed its height')
  assert(vim.o.mouse == 'a', 'Mouse input is enabled while the picker is open')
end
local function closed()
  assert(calls == 1, 'The callback fires exactly once')
  assert(not vim.api.nvim_win_is_valid(window) and not vim.api.nvim_buf_is_valid(buffer), 'Picker windows and buffers are removed')
  assert(vim.o.mouse == '', 'The original mouse option is restored')
  assert(vim.api.nvim_buf_get_changedtick(source) == tick, 'The caller draft is unchanged')
end
open(nil)
assert(vim.api.nvim_win_get_cursor(window)[1] == 1, 'An unset model starts at the first choice')
assert(not table.concat(vim.api.nvim_buf_get_lines(buffer, 0, -1, false), '\n'):find('[current]', 1, true), 'An unset model is not shown as configured')
local footer = vim.api.nvim_win_get_config(window).footer
local footer_text = table.concat(vim.tbl_map(function(chunk) return chunk[1] end, footer))
for _, label in ipairs({ '↑↓', '/search', 'Enter', 'Esc' }) do
  assert(footer_text:find(label, 1, true), 'A narrow picker must show movement, search, selection, and cancellation')
end
assert(vim.fn.strdisplaywidth(footer_text) <= vim.api.nvim_win_get_width(window), 'The narrow picker controls must fit')
keys('jkj<Esc>')
closed()
assert(result.item == nil, 'Native motion alone does not choose a model')
open(30)
assert(vim.api.nvim_win_get_cursor(window)[1] == 30, 'The current model is selected initially')
assert(vim.api.nvim_get_current_line():find('[current]', 1, true), 'The current setting is marked')
assert(vim.fn.line('w0') <= 30 and vim.fn.line('w$') >= 30, 'The current model is visible initially')
keys('<PageDown>')
assert(vim.api.nvim_win_get_cursor(window)[1] > 30, 'PageDown reaches options beyond the first view')
keys('<PageUp>')
assert(vim.api.nvim_win_get_cursor(window)[1] < 47, 'PageUp returns to earlier choices')
keys('G<CR>')
closed()
assert(result.item == items[47] and result.index == 47, 'The last option is selectable')
assert(vim.api.nvim_get_current_win() == previous, 'Selection restores the caller window')
open(1)
keys('/Model 42<CR>')
assert(vim.api.nvim_win_get_cursor(window)[1] == 42 and calls == 0, 'Native search reaches a hidden choice without selecting it')
keys('<CR>')
closed()
assert(result.index == 42)
open(1)
keys('<Down><Down><Up>')
assert(vim.api.nvim_win_get_cursor(window)[1] == 2, 'Arrow keys move between choices')
keys('<Esc>')
closed()
assert(result.item == nil and result.index == nil, 'Escape cancels without a selection')
open(47)
for _, size in ipairs({ { 60, 20 }, { 30, 12 }, { 120, 40 } }) do
  vim.o.columns, vim.o.lines = size[1], size[2]
  vim.api.nvim_exec_autocmds('VimResized', {})
  local config = vim.api.nvim_win_get_config(window)
  assert(config.width + 2 <= size[1] and config.height + 2 <= size[2], 'The picker stays within the resized screen')
  assert(vim.api.nvim_win_get_cursor(window)[1] == 47, 'Resizing preserves the selected item')
end
keys('q')
closed()
assert(result.item == nil)
open(1)
vim.api.nvim_win_close(window, true)
vim.wait(20)
closed()
assert(result.item == nil, 'Closing the native window cancels')
open(1)
vim.api.nvim_set_current_win(previous)
vim.wait(20)
closed()
assert(vim.api.nvim_get_current_win() == previous and result.item == nil, 'Outside focus cancels and stays outside')
open(1)
vim.cmd('tabnew')
local other_tab = vim.api.nvim_get_current_tabpage()
vim.wait(20)
closed()
assert(vim.api.nvim_get_current_tabpage() == other_tab and result.item == nil, 'Changing tabs cancels without changing the selected tab')
local empty_calls = 0
select({}, {}, function(item, index) empty_calls = empty_calls + 1; assert(item == nil and index == nil) end)
assert(empty_calls == 1 and vim.fn.bufnr('harness://select') == -1, 'An empty list cancels without a window')
print('Neovim selection checks passed: native scrolling, search, selection, resize, focus, draft preservation and cleanup.')
vim.cmd('noautocmd qa!')
