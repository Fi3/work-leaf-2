import importlib.util
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path('/home/user/src/work-leaf-2')
DIRECTORY = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('bench', ROOT / 'scripts/bench.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
profile = json.loads((ROOT / 'benchmarks/profile.json').read_text())
original_docker, original_collect = bench.docker, bench.collect
scope = None

def docker(*arguments):
    global scope
    result = original_docker(*arguments)
    if arguments[0] == 'create':
        scope = Path('/sys/fs/cgroup/system.slice') / f'docker-{result}.scope'
    return result

def collect(output, path, records):
    done = threading.Event()
    def observe():
        with path.with_suffix('.memory-stat.jsonl').open('w') as target:
            while not done.is_set():
                try:
                    stat = {key: int(value) for key, value in
                            (line.split() for line in (scope / 'memory.stat').read_text().splitlines())}
                    recent = next((item for item in reversed(records) if item.get('type') == 'sample'), {})
                    sample = {'time': time.time(), 'phase': recent.get('phase', 'startup'),
                              'elapsed_seconds': recent.get('elapsed_seconds'),
                              'memory_bytes': int((scope / 'memory.current').read_text()), 'memory_stat': stat}
                    target.write(json.dumps(sample) + '\n')
                    target.flush()
                except FileNotFoundError:
                    pass
                done.wait(.5)
    monitor = threading.Thread(target=observe)
    monitor.start()
    try:
        original_collect(output, path, records)
    finally:
        done.set()
        monitor.join()

bench.docker, bench.collect = docker, collect
for argument in sys.argv[1:]:
    label, image = argument.split('=', 1)
    destination = DIRECTORY / f'{label}.json'
    assert not destination.exists(), destination
    started = time.time()
    result = bench.run_container(image, profile, DIRECTORY, label, '30,31')
    result.update(trial_label=label, profile=profile, started_at=started)
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'trial': label, 'completed': result['completed'],
                     'capacity': result['capacity_completed_sessions'],
                     'resources': result['resources_by_phase']}), flush=True)
